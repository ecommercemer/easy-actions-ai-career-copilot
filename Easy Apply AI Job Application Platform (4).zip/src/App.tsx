import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import LandingPage from "./components/LandingPage";
import AuthPage from "./components/AuthPage";
import Dashboard from "./components/Dashboard";
import DocumentsHub from "./components/DocumentsHub";
import ApplicationProcess from "./components/ApplicationProcess";
import ApplicationTracker from "./components/ApplicationTracker";
import EmailCenter from "./components/EmailCenter";
import Settings from "./components/Settings";
import PricingPage from "./components/PricingPage";
import SmartDocumentUpload from "./components/SmartDocumentUpload";
import Layout from "./components/Layout";
import FloatingHelp from "./components/FloatingHelp";
import {
  AuthProvider,
  useAuth,
} from "./components/AuthContext";

function ProtectedRoute({
  children,
}: {
  children: React.ReactNode;
}) {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? (
    <Layout>{children}</Layout>
  ) : (
    <Navigate to="/auth" />
  );
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/auth" element={<AuthPage />} />
      <Route path="/pricing" element={<PricingPage />} />
      <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        }
      />
      <Route
        path="/smart-upload"
        element={
          <ProtectedRoute>
            <SmartDocumentUpload />
          </ProtectedRoute>
        }
      />
      <Route
        path="/documents"
        element={
          <ProtectedRoute>
            <DocumentsHub />
          </ProtectedRoute>
        }
      />
      <Route
        path="/apply/:jobId"
        element={
          <ProtectedRoute>
            <ApplicationProcess />
          </ProtectedRoute>
        }
      />
      <Route
        path="/tracker"
        element={
          <ProtectedRoute>
            <ApplicationTracker />
          </ProtectedRoute>
        }
      />
      <Route
        path="/email"
        element={
          <ProtectedRoute>
            <EmailCenter />
          </ProtectedRoute>
        }
      />
      <Route
        path="/settings"
        element={
          <ProtectedRoute>
            <Settings />
          </ProtectedRoute>
        }
      />
      {/* Catch-all route for unmatched URLs */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen relative">
          {/* Global vibrant orange-yellow gradient background */}
          <div className="fixed inset-0 -z-20">
            <div className="absolute inset-0 bg-gradient-to-br from-[#fff7ed] via-[#fed7aa] to-[#fb923c]" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(234,88,12,0.1),transparent_50%)]" />
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(251,191,36,0.1),transparent_50%)]" />
          </div>

          {/* Animated background elements with new orange colors */}
          <div className="fixed inset-0 -z-10 overflow-hidden">
            <div className="absolute -top-40 -right-40 w-80 h-80 bg-[#ea580c]/20 rounded-full blur-3xl animate-pulse" />
            <div
              className="absolute -bottom-40 -left-40 w-80 h-80 bg-[#fbbf24]/20 rounded-full blur-3xl animate-pulse"
              style={{ animationDelay: "2s" }}
            />
            <div
              className="absolute top-1/2 left-1/2 w-60 h-60 bg-[#f97316]/10 rounded-full blur-3xl animate-pulse"
              style={{ animationDelay: "4s" }}
            />
          </div>

          <AppRoutes />

          {/* Global Floating Help Component */}
          <FloatingHelp />
        </div>
      </Router>
    </AuthProvider>
  );
}