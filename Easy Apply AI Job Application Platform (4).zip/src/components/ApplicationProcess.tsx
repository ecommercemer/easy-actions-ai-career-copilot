import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Checkbox } from './ui/checkbox';
import JobyMascot from './JobyMascot';
import {
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Building,
  MapPin,
  DollarSign,
  FileText,
  Send,
  Edit
} from 'lucide-react';
import { useAuth } from './AuthContext';

export default function ApplicationProcess() {
  const { jobId } = useParams();
  const [currentStep, setCurrentStep] = useState(1);
  const [isApplying, setIsApplying] = useState(false);
  const [selectedJobs, setSelectedJobs] = useState<string[]>([]);
  const { user, useApplication } = useAuth();
  const navigate = useNavigate();
  
  const [coverLetter, setCoverLetter] = useState(`Dear Hiring Manager,

I am writing to express my strong interest in the Senior Frontend Developer position at TechCorp. With my extensive experience in React, TypeScript, and modern web development practices, I believe I would be an excellent fit for your team.

In my previous role, I successfully led the development of a complex e-commerce platform that increased user engagement by 40%. My expertise in responsive design and performance optimization aligns perfectly with the requirements outlined in your job posting.

I am particularly excited about TechCorp's commitment to innovation and would love the opportunity to contribute to your cutting-edge projects.

Thank you for considering my application. I look forward to discussing how my skills can contribute to your team's success.

Best regards,
John Doe`);

  const mockJobs = [
    {
      id: '1',
      title: 'Senior Frontend Developer',
      company: 'TechCorp',
      location: 'Berlin, Germany',
      salary: '€70,000 - €90,000',
      platform: 'LinkedIn',
      match: 95
    },
    {
      id: '2',
      title: 'React Developer',
      company: 'StartupXYZ',
      location: 'Munich, Germany',
      salary: '€65,000 - €85,000',
      platform: 'Xing',
      match: 88
    },
    {
      id: '3',
      title: 'Full Stack Engineer',
      company: 'Digital Agency',
      location: 'Hamburg, Germany',
      salary: '€60,000 - €75,000',
      platform: 'StepStone',
      match: 82
    },
    {
      id: '4',
      title: 'JavaScript Developer',
      company: 'FinTech Co',
      location: 'Frankfurt, Germany',
      salary: '€75,000 - €95,000',
      platform: 'Indeed',
      match: 90
    },
    {
      id: '5',
      title: 'Frontend Specialist',
      company: 'E-commerce Giant',
      location: 'Cologne, Germany',
      salary: '€68,000 - €88,000',
      platform: 'LinkedIn',
      match: 85
    }
  ];

  const steps = [
    { number: 1, title: 'Select Jobs', description: 'Choose jobs to apply for' },
    { number: 2, title: 'Final Confirmation', description: 'Review and confirm applications' }
  ];

  const canApply = user?.plan !== 'free' || (user?.applicationsUsed + selectedJobs.length <= user?.applicationsLimit);

  const handleJobToggle = (jobId: string) => {
    setSelectedJobs(prev => 
      prev.includes(jobId) 
        ? prev.filter(id => id !== jobId)
        : [...prev, jobId]
    );
  };

  const handleNext = () => {
    if (currentStep < 2) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = () => {
    if (!canApply) return;
    
    setIsApplying(true);
    
    // Use applications
    for (let i = 0; i < selectedJobs.length; i++) {
      useApplication();
    }
    
    // Simulate application process
    setTimeout(() => {
      setIsApplying(false);
      navigate('/tracker');
    }, 3000);
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <Card className="rounded-xl border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Building className="w-6 h-6 mr-3 text-blue-600" />
                  Select Jobs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <p className="text-gray-600 mb-4">
                    AI has found {mockJobs.length} relevant jobs for you. Select the ones you want to apply for:
                  </p>
                  <div className="space-y-3">
                    {mockJobs.map((job) => (
                      <div key={job.id} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors">
                        <Checkbox
                          id={job.id}
                          checked={selectedJobs.includes(job.id)}
                          onCheckedChange={() => handleJobToggle(job.id)}
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <div>
                              <h4 className="font-medium text-gray-900">{job.title}</h4>
                              <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                                <span className="flex items-center">
                                  <Building className="w-4 h-4 mr-1" />
                                  {job.company}
                                </span>
                                <span className="flex items-center">
                                  <MapPin className="w-4 h-4 mr-1" />
                                  {job.location}
                                </span>
                                <span className="flex items-center">
                                  <DollarSign className="w-4 h-4 mr-1" />
                                  {job.salary}
                                </span>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge variant="secondary" className="bg-green-100 text-green-800">
                                {job.match}% match
                              </Badge>
                              <Badge variant="outline" className="text-blue-600">
                                {job.platform}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {selectedJobs.length > 0 && (
                    <div className="mt-6 p-4 bg-blue-50 rounded-xl border border-blue-200">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-blue-900">
                            {selectedJobs.length} job{selectedJobs.length > 1 ? 's' : ''} selected
                          </p>
                          <p className="text-sm text-blue-700">
                            {user?.plan === 'free' && user?.applicationsUsed && user?.applicationsLimit
                              ? `This will use ${selectedJobs.length} of your ${user.applicationsLimit - user.applicationsUsed} remaining applications`
                              : 'Ready to apply!'
                            }
                          </p>
                        </div>
                        {!canApply && (
                          <Button variant="outline" className="rounded-full border-yellow-500 text-yellow-700 hover:bg-yellow-50">
                            Upgrade to Apply
                          </Button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <Card className="rounded-xl border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Send className="w-6 h-6 mr-3 text-green-600" />
                  Final Confirmation
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="bg-green-50 border border-green-200 rounded-xl p-6 text-center">
                    <CheckCircle className="w-16 h-16 text-green-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-green-900 mb-2">Ready to Apply!</h3>
                    <p className="text-green-800">
                      Your application for {selectedJobs.length} job(s) is ready to be sent.
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                    <div className="p-4 bg-blue-50 rounded-xl">
                      <FileText className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-blue-900">Custom Cover Letter</p>
                      <p className="text-xs text-blue-700">AI-optimized for this role</p>
                    </div>
                    <div className="p-4 bg-purple-50 rounded-xl">
                      <CheckCircle className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-purple-900">3 Documents Attached</p>
                      <p className="text-xs text-purple-700">Resume + certificates</p>
                    </div>
                    <div className="p-4 bg-orange-50 rounded-xl">
                      <Send className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-orange-900">Auto-filled Forms</p>
                      <p className="text-xs text-orange-700">All fields completed</p>
                    </div>
                  </div>

                  {!isApplying ? (
                    <Button 
                      onClick={handleSubmit}
                      className="w-full py-6 rounded-xl bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-lg hover:shadow-xl transition-all duration-300"
                    >
                      <Send className="w-5 h-5 mr-2" />
                      CONFIRM & SEND APPLICATION
                    </Button>
                  ) : (
                    <div className="text-center space-y-4">
                      <JobyMascot size="large" animation="fly" />
                      <p className="text-lg font-medium text-gray-900">Joby is sending your application...</p>
                      <Progress value={66} className="h-3" />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Apply to Job</h1>
          <p className="text-gray-600 mt-2">Let Joby handle your application process</p>
        </div>
        <Link to="/tracker">
          <Button variant="outline" className="rounded-full">
            Back to Tracker
          </Button>
        </Link>
      </div>

      {/* Progress Steps */}
      <Card className="rounded-xl border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-900">Application Progress</h3>
            <span className="text-sm text-gray-600">Step {currentStep} of 2</span>
          </div>
          <Progress value={(currentStep / 2) * 100} className="h-2 mb-6" />
          <div className="grid grid-cols-2 gap-4">
            {steps.map((step) => (
              <div key={step.number} className="text-center">
                <div className={`w-8 h-8 rounded-full mx-auto mb-2 flex items-center justify-center text-sm font-medium ${
                  step.number <= currentStep 
                    ? 'bg-green-600 text-white' 
                    : 'bg-gray-200 text-gray-600'
                }`}>
                  {step.number}
                </div>
                <p className="text-xs font-medium text-gray-900">{step.title}</p>
                <p className="text-xs text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Step Content */}
      <motion.div
        key={currentStep}
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.3 }}
      >
        {renderStepContent()}
      </motion.div>

      {/* Navigation */}
      {!isApplying && (
        <div className="flex justify-between">
          <Button 
            variant="outline" 
            onClick={handlePrevious}
            disabled={currentStep === 1}
            className="rounded-full"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>
          
          {currentStep < 2 && (
            <Button 
              onClick={handleNext}
              className="rounded-full bg-blue-600 hover:bg-blue-700"
            >
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>
      )}
    </div>
  );
}