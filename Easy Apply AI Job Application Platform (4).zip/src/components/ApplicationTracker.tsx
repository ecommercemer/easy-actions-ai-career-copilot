import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import EasyActionsLogo from './EasyActionsLogo';
import {
  Building,
  MapPin,
  Calendar,
  DollarSign,
  Eye,
  ExternalLink,
  MoreVertical,
  TrendingUp,
  Users,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Briefcase,
  Star,
  Filter,
  RefreshCw,
  Download,
  BarChart3,
  Search,
  Plus,
  Target,
  Sparkles
} from 'lucide-react';

interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  appliedDate: string;
  status: string;
  platform: string;
  logo?: string;
}

export default function ApplicationTracker() {
  const [jobs] = useState<Job[]>([
    {
      id: '1',
      title: 'Senior Frontend Developer',
      company: 'TechCorp',
      location: 'Berlin, Germany',
      salary: '€70,000 - €90,000',
      appliedDate: '2024-08-05',
      status: 'applied',
      platform: 'LinkedIn'
    },
    {
      id: '2',
      title: 'Full Stack Engineer',
      company: 'StartupXYZ',
      location: 'Munich, Germany',
      salary: '€65,000 - €85,000',
      appliedDate: '2024-08-04',
      status: 'interviewing',
      platform: 'Xing'
    },
    {
      id: '3',
      title: 'React Developer',
      company: 'Digital Agency',
      location: 'Hamburg, Germany',
      salary: '€60,000 - €75,000',
      appliedDate: '2024-08-03',
      status: 'responded',
      platform: 'StepStone'
    },
    {
      id: '4',
      title: 'Software Engineer',
      company: 'Enterprise Co',
      location: 'Frankfurt, Germany',
      salary: '€80,000 - €100,000',
      appliedDate: '2024-08-02',
      status: 'offer',
      platform: 'Indeed'
    },
    {
      id: '5',
      title: 'Frontend Specialist',
      company: 'Design Studio',
      location: 'Cologne, Germany',
      salary: '€55,000 - €70,000',
      appliedDate: '2024-08-01',
      status: 'rejected',
      platform: 'LinkedIn'
    },
    {
      id: '6',
      title: 'Web Developer',
      company: 'E-commerce Giant',
      location: 'Düsseldorf, Germany',
      salary: '€65,000 - €80,000',
      appliedDate: '2024-07-31',
      status: 'review',
      platform: 'Xing'
    },
    {
      id: '7',
      title: 'JavaScript Developer',
      company: 'FinTech Startup',
      location: 'Stuttgart, Germany',
      salary: '€70,000 - €85,000',
      appliedDate: '2024-07-30',
      status: 'applying',
      platform: 'StepStone'
    }
  ]);

  const columns = [
    { id: 'review', title: 'Jobs to Review', color: 'bg-gray-100', count: jobs.filter(j => j.status === 'review').length },
    { id: 'applying', title: 'AI Applying', color: 'bg-blue-100', count: jobs.filter(j => j.status === 'applying').length },
    { id: 'applied', title: 'Applied', color: 'bg-yellow-100', count: jobs.filter(j => j.status === 'applied').length },
    { id: 'responded', title: 'Employer Responded', color: 'bg-green-100', count: jobs.filter(j => j.status === 'responded').length },
    { id: 'interviewing', title: 'Interviewing', color: 'bg-purple-100', count: jobs.filter(j => j.status === 'interviewing').length },
    { id: 'offer', title: 'Offer', color: 'bg-emerald-100', count: jobs.filter(j => j.status === 'offer').length },
    { id: 'rejected', title: 'Rejected', color: 'bg-red-100', count: jobs.filter(j => j.status === 'rejected').length }
  ];

  const getStatusBadgeColor = (status: string) => {
    const colors: { [key: string]: string } = {
      review: 'bg-gray-100 text-gray-800',
      applying: 'bg-blue-100 text-blue-800',
      applied: 'bg-yellow-100 text-yellow-800',
      responded: 'bg-green-100 text-green-800',
      interviewing: 'bg-purple-100 text-purple-800',
      offer: 'bg-emerald-100 text-emerald-800',
      rejected: 'bg-red-100 text-red-800'
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  const getPlatformColor = (platform: string) => {
    const colors: { [key: string]: string } = {
      LinkedIn: 'text-blue-600',
      Xing: 'text-green-600',
      StepStone: 'text-purple-600',
      Indeed: 'text-orange-600'
    };
    return colors[platform] || 'text-gray-600';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 p-4 md:p-6 pt-0">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Enhanced Header with Logo and Robot */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8 space-y-4 lg:space-y-0"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <EasyActionsLogo size="lg" showText={true} className="hidden sm:flex" />
            
            {/* Mobile: Logo stacked */}
            <div className="flex flex-col sm:hidden space-y-2">
              <EasyActionsLogo size="md" showText={true} />
            </div>
            
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold gradient-text drop-shadow-sm leading-tight">
                <span className="block sm:inline">Job Application</span>
                <span className="block sm:inline"> </span>
                <span className="block sm:inline">Tracker 📊</span>
              </h1>
              <p className="text-slate-600 mt-2 text-sm sm:text-base leading-relaxed">
                Track your AI-powered job applications across all platforms in real-time
              </p>
            </div>
          </div>
          
          {/* AI Assistant Robot with Message */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative self-center lg:self-auto"
          >
            <motion.div
              animate={{
                y: [0, -10, 0],
                rotate: [0, 3, -3, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="relative"
            >
              <ImageWithFallback
                src={robotImage}
                alt="AI Assistant Robot"
                className="w-16 h-16 md:w-20 md:h-20 rounded-full shadow-lg border-2 border-white/80 robot-bounce"
              />
              
              {/* Speech bubble */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5 }}
                className="absolute -top-16 -left-20 md:-left-32 bg-white rounded-2xl p-3 shadow-lg border border-orange-200/30 max-w-48"
              >
                <p className="text-xs font-medium text-slate-700">
                  Great progress! You have {jobs.filter(j => j.status === 'interviewing').length} interviews scheduled! 🎉
                </p>
                <div className="absolute bottom-0 left-8 w-3 h-3 bg-white transform rotate-45 translate-y-1/2 border-r border-b border-orange-200/30" />
              </motion.div>
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Enhanced Stats Cards */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-8"
        >
          {[
            { 
              label: 'Total Applications', 
              value: jobs.length, 
              icon: Briefcase, 
              color: 'from-[#ea580c] to-[#f97316]',
              bgColor: 'bg-orange-50',
              borderColor: 'border-orange-200/30'
            },
            { 
              label: 'Active Interviews', 
              value: jobs.filter(j => j.status === 'interviewing').length, 
              icon: Users, 
              color: 'from-[#f97316] to-[#fbbf24]',
              bgColor: 'bg-amber-50',
              borderColor: 'border-amber-200/30'
            },
            { 
              label: 'Job Offers', 
              value: jobs.filter(j => j.status === 'offer').length, 
              icon: Star, 
              color: 'from-[#fbbf24] to-[#fde047]',
              bgColor: 'bg-yellow-50',
              borderColor: 'border-yellow-200/30'
            },
            { 
              label: 'Response Rate', 
              value: `${Math.round((jobs.filter(j => j.status === 'responded').length / jobs.filter(j => j.status !== 'review' && j.status !== 'applying').length) * 100)}%`, 
              icon: TrendingUp, 
              color: 'from-[#fde047] to-[#facc15]',
              bgColor: 'bg-lime-50',
              borderColor: 'border-lime-200/30'
            },
          ].map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
                whileHover={{ scale: 1.02, y: -2 }}
              >
                <Card className={`glass glow-orange shadow-lg hover:shadow-xl transition-all duration-300 ${stat.borderColor} ${stat.bgColor}/30`}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-slate-600 mb-1 font-medium">{stat.label}</p>
                        <p className="text-2xl md:text-3xl font-bold gradient-text">
                          {stat.value}
                        </p>
                      </div>
                      <div className={`w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-r ${stat.color} flex items-center justify-center shadow-lg`}>
                        <Icon className="w-6 h-6 md:w-7 md:h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Action Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6"
        >
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
            <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
            <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
            <Button className="gradient-button glow-orange text-white btn-hover-lift" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Add Job
            </Button>
          </div>
        </motion.div>

        {/* Enhanced Kanban Board */}
        <div className="overflow-x-auto">
          <div className="flex space-x-4 md:space-x-6 min-w-max pb-4">
            {columns.map((column, columnIndex) => {
              const columnColors = {
                review: { bg: 'from-slate-100 to-slate-50', header: 'bg-slate-200/50', icon: AlertCircle },
                applying: { bg: 'from-blue-100 to-blue-50', header: 'bg-blue-200/50', icon: Clock },
                applied: { bg: 'from-yellow-100 to-yellow-50', header: 'bg-yellow-200/50', icon: Target },
                responded: { bg: 'from-green-100 to-green-50', header: 'bg-green-200/50', icon: CheckCircle },
                interviewing: { bg: 'from-purple-100 to-purple-50', header: 'bg-purple-200/50', icon: Users },
                offer: { bg: 'from-emerald-100 to-emerald-50', header: 'bg-emerald-200/50', icon: Star },
                rejected: { bg: 'from-red-100 to-red-50', header: 'bg-red-200/50', icon: XCircle }
              };
              
              const columnStyle = columnColors[column.id as keyof typeof columnColors];
              const Icon = columnStyle.icon;
              
              return (
                <motion.div
                  key={column.id}
                  className="w-80 flex-shrink-0"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.5 + columnIndex * 0.1 }}
                >
                  <Card className={`glass shadow-xl border-orange-200/20 bg-gradient-to-b ${columnStyle.bg} min-h-[600px] hover:shadow-2xl transition-all duration-300`}>
                    <CardHeader className={`pb-4 ${columnStyle.header} rounded-t-lg`}>
                      <CardTitle className="text-sm font-semibold flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Icon className="w-4 h-4" />
                          <span>{column.title}</span>
                        </div>
                        <Badge variant="secondary" className="bg-white/80 text-slate-700 shadow-sm">
                          {column.count}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3 p-4">
                      {jobs.filter(job => job.status === column.id).map((job, jobIndex) => (
                        <motion.div
                          key={job.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.6 + columnIndex * 0.1 + jobIndex * 0.05 }}
                          className="bg-white/90 backdrop-blur-sm rounded-xl p-4 shadow-sm border border-white/50 cursor-pointer hover:shadow-lg hover:bg-white/95 transition-all duration-200 group"
                          whileHover={{ scale: 1.02, y: -2 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <div className="space-y-3">
                            {/* Header */}
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <h3 className="font-semibold text-slate-900 text-sm leading-tight group-hover:text-orange-600 transition-colors">
                                  {job.title}
                                </h3>
                                <p className="text-slate-600 text-sm flex items-center mt-1">
                                  <Building className="w-3 h-3 mr-1" />
                                  {job.company}
                                </p>
                              </div>
                              <Button size="sm" variant="ghost" className="p-1 h-auto opacity-0 group-hover:opacity-100 transition-opacity">
                                <MoreVertical className="w-4 h-4" />
                              </Button>
                            </div>

                            {/* Details */}
                            <div className="space-y-2">
                              <div className="flex items-center text-xs text-slate-600">
                                <MapPin className="w-3 h-3 mr-1 text-orange-500" />
                                {job.location}
                              </div>
                              <div className="flex items-center text-xs text-slate-600">
                                <DollarSign className="w-3 h-3 mr-1 text-green-500" />
                                {job.salary}
                              </div>
                              <div className="flex items-center text-xs text-slate-600">
                                <Calendar className="w-3 h-3 mr-1 text-blue-500" />
                                Applied {new Date(job.appliedDate).toLocaleDateString()}
                              </div>
                            </div>

                            {/* Footer */}
                            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                              <Badge variant="outline" className={`${getPlatformColor(job.platform)} border-0 bg-white/60`}>
                                {job.platform}
                              </Badge>
                              <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <Button size="sm" variant="ghost" className="p-1 h-auto hover:bg-orange-100">
                                  <Eye className="w-3 h-3" />
                                </Button>
                                <Button size="sm" variant="ghost" className="p-1 h-auto hover:bg-orange-100">
                                  <ExternalLink className="w-3 h-3" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}

                      {/* Add new job placeholder for review column */}
                      {column.id === 'review' && (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: 1 }}
                          className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-orange-400 hover:bg-orange-50/50 transition-all duration-200 cursor-pointer group"
                        >
                          <Plus className="w-6 h-6 mx-auto mb-2 text-slate-400 group-hover:text-orange-500 transition-colors" />
                          <p className="text-sm text-slate-500 group-hover:text-orange-600 transition-colors font-medium">Add new job to review</p>
                        </motion.div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* AI Insights Footer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 }}
          className="mt-8"
        >
          <Card className="glass glow-orange shadow-xl border-orange-200/30 bg-gradient-to-r from-orange-50/50 to-yellow-50/50">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-4 md:space-y-0">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center shadow-lg">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">AI Performance Insights interview</h3>
                    <p className="text-sm text-slate-600">Your application success rate is above average! Keep it up!</p>
                  </div>
                </div>
                <Button className="gradient-button glow-orange text-white btn-hover-lift">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  View Analytics
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}