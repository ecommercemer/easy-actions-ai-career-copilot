import React, { createContext, useContext, useState } from 'react';

interface AuthContextType {
  isAuthenticated: boolean;
  user: { 
    name: string; 
    email: string; 
    plan: 'free' | 'pro' | 'premium';
    applicationsUsed: number;
    applicationsLimit: number;
  } | null;
  login: (userData: { name: string; email: string; plan: 'free' | 'pro' | 'premium' }) => void;
  logout: () => void;
  signup: (name: string, email: string, password: string) => void;
  useApplication: () => boolean;
  upgradeplan: (plan: 'pro' | 'premium') => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<{ 
    name: string; 
    email: string; 
    plan: 'free' | 'pro' | 'premium';
    applicationsUsed: number;
    applicationsLimit: number;
  } | null>(null);

  const login = (userData: { name: string; email: string; plan: 'free' | 'pro' | 'premium' }) => {
    // Mock authentication - in real app this would call an API
    setIsAuthenticated(true);
    setUser({
      ...userData,
      applicationsUsed: 0,
      applicationsLimit: userData.plan === 'free' ? 5 : 999
    });
  };

  const signup = (name: string, email: string, password: string) => {
    // Mock signup - in real app this would call an API
    setIsAuthenticated(true);
    setUser({ 
      name, 
      email,
      plan: 'free',
      applicationsUsed: 0,
      applicationsLimit: 5
    });
  };

  const logout = () => {
    setIsAuthenticated(false);
    setUser(null);
  };

  const useApplication = () => {
    if (!user) return false;
    if (user.applicationsUsed >= user.applicationsLimit && user.plan === 'free') {
      return false; // Cannot use more applications
    }
    
    setUser(prev => prev ? {
      ...prev,
      applicationsUsed: prev.applicationsUsed + 1
    } : null);
    return true;
  };

  const upgradeplan = (plan: 'pro' | 'premium') => {
    setUser(prevUser => {
      if (prevUser) {
        return { 
          ...prevUser, 
          plan,
          applicationsLimit: plan === 'pro' ? 999 : 999 // Unlimited for paid plans
        };
      }
      return null;
    });
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, user, login, logout, signup, useApplication, upgradeplan }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}