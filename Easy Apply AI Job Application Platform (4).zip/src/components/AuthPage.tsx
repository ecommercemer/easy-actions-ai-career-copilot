import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Separator } from './ui/separator';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useAuth } from './AuthContext';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import { 
  Mail, 
  Lock, 
  User, 
  ArrowLeft, 
  Eye, 
  EyeOff,
  Chrome,
  Smartphone,
  CheckCircle,
  Zap
} from 'lucide-react';

const AuthPage: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock successful login/signup
    login({
      name: isLogin ? 'Demo User' : formData.name,
      email: formData.email,
      plan: 'free'
    });
    
    navigate('/dashboard');
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const handleSocialLogin = (provider: string) => {
    setIsLoading(true);
    // Simulate social login
    setTimeout(() => {
      login({
        name: `${provider} User`,
        email: `user@${provider.toLowerCase()}.com`,
        plan: 'free'
      });
      navigate('/dashboard');
    }, 1500);
  };

  return (
    <div className="h-screen bg-gradient-to-br from-[#fff7ed] via-[#fed7aa] to-[#fb923c] relative overflow-hidden">
      {/* Enhanced animated background */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(234,88,12,0.2),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(251,191,36,0.2),transparent_50%)]" />
      </div>

      {/* Back Button - Fixed Position */}
      <div className="fixed top-3 left-3 z-50">
        <Button
          variant="ghost"
          onClick={() => navigate('/')}
          className="glass border border-[#ea580c]/30 hover:bg-[#ea580c]/10 btn-hover-lift"
          size="sm"
        >
          <ArrowLeft className="w-4 h-4 mr-1" />
          <span className="hidden sm:inline text-sm">Back</span>
        </Button>
      </div>

      {/* Logo - Fixed Position Top Right */}
      <div className="fixed top-3 right-3 z-50 hidden sm:flex items-center space-x-2">
        <ImageWithFallback
          src={robotImage}
          alt="AI Assistant Robot"
          className="w-7 h-7 rounded-lg shadow-sm robot-bounce"
        />
        <div>
          <span className="font-bold gradient-text text-sm">Easy Actions</span>
          <p className="text-xs text-[#ea580c]">AI Co-pilot</p>
        </div>
      </div>

      {/* Main Content - Optimized for single screen view */}
      <div className="h-full flex items-center justify-center p-3 py-6">
        <div className="w-full max-w-md">
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.6, type: "spring" }}
          >
            <Card className="glass glow-orange shadow-2xl border-orange-200/30 bg-white/95 backdrop-blur-xl">
              <CardHeader className="text-center space-y-3 pb-4">
                {/* Robot Avatar with animation */}
                <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                  className="mx-auto"
                >
                  <ImageWithFallback
                    src={robotImage}
                    alt="AI Assistant Robot"
                    className="w-12 h-12 rounded-full shadow-lg glow-orange border-3 border-white/80 robot-bounce"
                  />
                </motion.div>

                <div>
                  <CardTitle className="text-lg gradient-text mb-1">
                    {isLogin ? 'Welcome Back!' : 'Join Easy Actions'}
                  </CardTitle>
                  <CardDescription className="text-slate-600 text-sm">
                    {isLogin 
                      ? 'Sign in to continue your automated job search'
                      : 'Create your account and let AI find your dream job'
                    }
                  </CardDescription>
                </div>
              </CardHeader>

              <CardContent className="space-y-4 pb-4">
                {/* Social Login Buttons */}
                <div className="space-y-2">
                  <Button
                    onClick={() => handleSocialLogin('Google')}
                    disabled={isLoading}
                    className="w-full bg-white hover:bg-gray-50 text-gray-700 border border-gray-300 shadow-sm btn-hover-lift py-2"
                    size="sm"
                  >
                    <Chrome className="w-4 h-4 mr-2 text-blue-500" />
                    <span className="text-sm">{isLogin ? 'Sign in with Google' : 'Sign up with Google'}</span>
                  </Button>

                  <Button
                    onClick={() => handleSocialLogin('LinkedIn')}
                    disabled={isLoading}
                    className="w-full bg-[#0077b5] hover:bg-[#005885] text-white btn-hover-lift py-2"
                    size="sm"
                  >
                    <div className="w-4 h-4 mr-2 bg-white rounded text-[#0077b5] flex items-center justify-center text-xs font-bold">
                      in
                    </div>
                    <span className="text-sm">{isLogin ? 'Sign in with LinkedIn' : 'Sign up with LinkedIn'}</span>
                  </Button>
                </div>

                <div className="relative my-3">
                  <div className="absolute inset-0 flex items-center">
                    <Separator className="w-full bg-orange-200/50" />
                  </div>
                  <div className="relative flex justify-center text-xs">
                    <span className="px-2 bg-white text-slate-500">or continue with email</span>
                  </div>
                </div>

                {/* Email Form - Compact */}
                <form onSubmit={handleSubmit} className="space-y-3">
                  {!isLogin && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Label htmlFor="name" className="text-slate-700 text-sm">Full Name</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <Input
                          id="name"
                          name="name"
                          type="text"
                          placeholder="Enter your full name"
                          value={formData.name}
                          onChange={handleInputChange}
                          className="pl-10 bg-white/80 border-orange-200/50 focus:border-orange-400 py-2 h-9"
                          required={!isLogin}
                        />
                      </div>
                    </motion.div>
                  )}

                  <div>
                    <Label htmlFor="email" className="text-slate-700 text-sm">Email Address</Label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <Input
                        id="email"
                        name="email"
                        type="email"
                        placeholder="Enter your email"
                        value={formData.email}
                        onChange={handleInputChange}
                        className="pl-10 bg-white/80 border-orange-200/50 focus:border-orange-400 py-2 h-9"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="password" className="text-slate-700 text-sm">Password</Label>
                    <div className="relative">
                      <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <Input
                        id="password"
                        name="password"
                        type={showPassword ? 'text' : 'password'}
                        placeholder="Enter your password"
                        value={formData.password}
                        onChange={handleInputChange}
                        className="pl-10 pr-10 bg-white/80 border-orange-200/50 focus:border-orange-400 py-2 h-9"
                        required
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 transform -translate-y-1/2"
                      >
                        {showPassword ? (
                          <EyeOff className="w-4 h-4 text-slate-400" />
                        ) : (
                          <Eye className="w-4 h-4 text-slate-400" />
                        )}
                      </button>
                    </div>
                  </div>

                  {!isLogin && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Label htmlFor="confirmPassword" className="text-slate-700 text-sm">Confirm Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <Input
                          id="confirmPassword"
                          name="confirmPassword"
                          type="password"
                          placeholder="Confirm your password"
                          value={formData.confirmPassword}
                          onChange={handleInputChange}
                          className="pl-10 bg-white/80 border-orange-200/50 focus:border-orange-400 py-2 h-9"
                          required={!isLogin}
                        />
                      </div>
                    </motion.div>
                  )}

                  <Button
                    type="submit"
                    disabled={isLoading}
                    className="w-full gradient-button glow-orange text-white py-2.5 btn-hover-lift mt-4"
                  >
                    {isLoading ? (
                      <div className="flex items-center justify-center">
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                          className="w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"
                        />
                        <span className="text-sm">{isLogin ? 'Signing In...' : 'Creating Account...'}</span>
                      </div>
                    ) : (
                      <div className="flex items-center justify-center">
                        <Zap className="w-4 h-4 mr-2" />
                        <span className="text-sm">{isLogin ? 'Sign In' : 'Create Account'}</span>
                      </div>
                    )}
                  </Button>
                </form>

                {/* Toggle Login/Signup */}
                <div className="text-center pt-2">
                  <p className="text-slate-600 text-sm">
                    {isLogin ? "Don't have an account?" : "Already have an account?"}
                    <button
                      onClick={() => setIsLogin(!isLogin)}
                      className="ml-2 text-orange-600 hover:text-orange-700 font-semibold transition-colors"
                    >
                      {isLogin ? 'Sign up' : 'Sign in'}
                    </button>
                  </p>
                </div>

                {/* Compact Features Preview for Signup */}
                {!isLogin && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.3, duration: 0.5 }}
                    className="pt-3 border-t border-orange-200/30"
                  >
                    <p className="text-xs text-slate-600 text-center font-medium mb-2">What you get:</p>
                    <div className="grid grid-cols-1 gap-1">
                      {[
                        'AI-powered job matching',
                        'Automatic application sending',
                        '5 free applications to start'
                      ].map((feature, index) => (
                        <div key={index} className="flex items-center text-xs text-slate-600">
                          <CheckCircle className="w-3 h-3 text-orange-500 mr-2 flex-shrink-0" />
                          {feature}
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>

            {/* Compact Extension CTA */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6, duration: 0.5 }}
              className="mt-3 text-center"
            >
              <div className="glass border-orange-200/20 shadow-md bg-white/90 backdrop-blur-sm rounded-lg p-2">
                <p className="text-xs text-slate-600 mb-1">Get the browser extension</p>
                <div className="flex gap-2 justify-center">
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-orange-200 hover:border-orange-300 bg-white/80 btn-hover-lift text-xs px-3 py-1 h-7"
                  >
                    <Chrome className="w-3 h-3 mr-1" />
                    Chrome
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-orange-200 hover:border-orange-300 bg-white/80 btn-hover-lift text-xs px-3 py-1 h-7"
                  >
                    <Smartphone className="w-3 h-3 mr-1" />
                    Mobile
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;