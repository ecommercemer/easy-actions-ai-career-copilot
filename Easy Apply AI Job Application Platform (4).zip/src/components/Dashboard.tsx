import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ImageWithFallback } from './figma/ImageWithFallback';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import { useAuth } from './AuthContext';
import EasyActionsLogo from './EasyActionsLogo';
import {
  Upload,
  Search,
  Send,
  CheckCircle,
  TrendingUp,
  Calendar,
  FileText,
  Mail,
  Settings,
  Target,
  Zap,
  Plus,
  Eye,
  ArrowRight,
  Clock,
  Briefcase,
  Star,
  DollarSign,
  Users,
  Activity,
  AlertCircle,
  Filter,
  Download,
  BarChart,
  PieChart,
  LineChart,
  RefreshCw,
  Bell,
  Sparkles,
  PlayCircle,
  PauseCircle
} from 'lucide-react';

interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  type: string;
  posted: string;
  match: number;
  status: 'queued' | 'applied' | 'reviewing' | 'pending';
  platform: string;
}

interface TodayStats {
  applicationsToday: number;
  coverLettersCreated: number;
  jobsFound: number;
  responsesReceived: number;
}

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [refreshing, setRefreshing] = useState(false);
  const [aiRunning, setAiRunning] = useState(true);
  const [hasUploaded, setHasUploaded] = useState(false);

  // Mock data - Today's performance
  const todayStats: TodayStats = {
    applicationsToday: 12,
    coverLettersCreated: 12,
    jobsFound: 47,
    responsesReceived: 3
  };

  // AI-found jobs queue
  const aiJobQueue: Job[] = [
    { 
      id: '1', 
      title: 'Senior Frontend Developer', 
      company: 'TechCorp', 
      location: 'Munich', 
      salary: '€70,000-€85,000', 
      type: 'Full-time', 
      posted: '2h ago', 
      match: 95, 
      status: 'queued', 
      platform: 'LinkedIn' 
    },
    { 
      id: '2', 
      title: 'React Developer', 
      company: 'StartupXYZ', 
      location: 'Berlin', 
      salary: '€60,000-€75,000', 
      type: 'Full-time', 
      posted: '4h ago', 
      match: 92, 
      status: 'applied', 
      platform: 'StepStone' 
    },
    { 
      id: '3', 
      title: 'Full Stack Engineer', 
      company: 'WebSolutions', 
      location: 'Frankfurt', 
      salary: '€65,000-€80,000', 
      type: 'Full-time', 
      posted: '6h ago', 
      match: 88, 
      status: 'reviewing', 
      platform: 'Indeed' 
    },
    { 
      id: '4', 
      title: 'JavaScript Developer', 
      company: 'InnovateLab', 
      location: 'Hamburg', 
      salary: '€55,000-€70,000', 
      type: 'Full-time', 
      posted: '8h ago', 
      match: 85, 
      status: 'queued', 
      platform: 'Xing' 
    },
  ];

  // Email notifications
  const notifications = [
    { id: '1', type: 'response', message: 'TechCorp wants to schedule an interview', time: '2h ago', urgent: true },
    { id: '2', type: 'applied', message: 'Application sent to StartupXYZ', time: '4h ago', urgent: false },
    { id: '3', type: 'found', message: '12 new matching jobs found', time: '6h ago', urgent: false },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'queued': return 'bg-blue-100 text-blue-700';
      case 'applied': return 'bg-orange-100 text-orange-700';
      case 'reviewing': return 'bg-purple-100 text-purple-700';
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'linkedin': return '💼';
      case 'stepstone': return '🪜';
      case 'indeed': return '🔍';
      case 'xing': return '🌐';
      default: return '🌍';
    }
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setRefreshing(false);
  };

  const handleUploadResume = () => {
    setHasUploaded(true);
    navigate('/smart-upload');
  };

  const toggleAI = () => {
    setAiRunning(!aiRunning);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 p-4 md:p-6 pt-0">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Welcome Header with Logo and Enhanced CTA */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8 space-y-4 lg:space-y-0"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <EasyActionsLogo size="lg" showText={true} className="hidden sm:flex" />
            
            {/* Mobile: Logo and text stacked */}
            <div className="flex flex-col sm:hidden space-y-2">
              <EasyActionsLogo size="md" showText={true} />
            </div>
            
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl sm:text-3xl font-bold gradient-text drop-shadow-sm leading-tight">
                <span className="block sm:inline">Upload your resume</span>
                <span className="block sm:inline"> </span>
                <span className="block sm:inline">now and start! ⚡</span>
              </h1>
              <p className="text-slate-600 mt-2 font-medium text-sm sm:text-base max-w-none sm:max-w-2xl leading-relaxed">
                Your AI co-pilot is {aiRunning ? 'actively working' : 'paused'}. Let's find your dream job together.
              </p>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3 w-full sm:w-auto">
            <Button
              onClick={toggleAI}
              variant={aiRunning ? "outline" : "default"}
              className={`w-full sm:w-auto ${aiRunning ? "border-orange-200 text-orange-600 hover:bg-orange-50" : "gradient-button glow-orange text-white"}`} 
              size="sm"
            >
              {aiRunning ? <PauseCircle className="w-4 h-4 mr-2" /> : <PlayCircle className="w-4 h-4 mr-2" />}
              {aiRunning ? 'Pause AI' : 'Start AI'}
            </Button>
            <Button
              onClick={handleRefresh}
              disabled={refreshing}
              variant="outline"
              size="sm"
              className="w-full sm:w-auto border-orange-200 hover:bg-orange-50 btn-hover-lift"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </motion.div>

        {!hasUploaded ? (
          /* Enhanced "Let's Get Started!" Section */
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="text-center py-16 relative"
          >
            {/* Decorative background elements */}
            <div className="absolute inset-0 overflow-hidden rounded-3xl">
              <div className="absolute -top-20 -left-20 w-40 h-40 bg-gradient-to-br from-orange-300/30 to-yellow-300/30 rounded-full blur-2xl animate-pulse" />
              <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-gradient-to-br from-yellow-300/30 to-orange-300/30 rounded-full blur-2xl animate-pulse" style={{animationDelay: '2s'}} />
              <div className="absolute top-10 right-10 w-20 h-20 bg-gradient-to-br from-orange-400/20 to-yellow-400/20 rounded-full blur-xl animate-pulse" style={{animationDelay: '4s'}} />
            </div>

            <Card className="max-w-4xl mx-auto glass glow-orange shadow-2xl border-orange-200/30 relative overflow-hidden">
              {/* Animated background pattern */}
              <div className="absolute inset-0 bg-gradient-to-br from-orange-50/50 via-yellow-50/30 to-orange-100/50" />
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(234,88,12,0.1),transparent_50%)] animate-pulse" />
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_80%,rgba(251,191,36,0.1),transparent_50%)] animate-pulse" style={{animationDelay: '3s'}} />
              
              <CardContent className="p-12 md:p-16 relative z-10">
                {/* Animated Robot with Enhanced Styling */}
                <motion.div
                  animate={{
                    y: [0, -15, 0],
                    rotate: [0, 5, -5, 0],
                    scale: [1, 1.05, 1]
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="relative mb-8"
                >
                  <div className="w-32 h-32 mx-auto relative">
                    {/* Glowing ring around robot */}
                    <div className="absolute inset-0 rounded-full bg-gradient-to-r from-orange-400 to-yellow-400 opacity-30 blur-lg animate-pulse" />
                    <div className="absolute inset-2 rounded-full bg-gradient-to-r from-orange-300 to-yellow-300 opacity-40 blur-md animate-pulse" style={{animationDelay: '1s'}} />
                    
                    <ImageWithFallback
                      src={robotImage}
                      alt="AI Assistant Robot"
                      className="w-full h-full rounded-full shadow-2xl border-4 border-white/80 relative z-10 robot-bounce"
                    />
                    
                    {/* Floating particles around robot */}
                    <motion.div
                      animate={{
                        y: [0, -20, 0],
                        x: [0, 10, 0],
                        opacity: [0.6, 1, 0.6]
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                      className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-br from-orange-400 to-yellow-400 rounded-full shadow-lg"
                    />
                    <motion.div
                      animate={{
                        y: [0, -15, 0],
                        x: [0, -8, 0],
                        opacity: [0.4, 0.8, 0.4]
                      }}
                      transition={{
                        duration: 4,
                        repeat: Infinity,
                        ease: "easeInOut",
                        delay: 1
                      }}
                      className="absolute -bottom-2 -left-2 w-4 h-4 bg-gradient-to-br from-yellow-400 to-orange-400 rounded-full shadow-lg"
                    />
                    <motion.div
                      animate={{
                        y: [0, -10, 0],
                        x: [0, 5, 0],
                        opacity: [0.5, 0.9, 0.5]
                      }}
                      transition={{
                        duration: 2.5,
                        repeat: Infinity,
                        ease: "easeInOut",
                        delay: 2
                      }}
                      className="absolute top-8 -left-4 w-3 h-3 bg-gradient-to-br from-orange-300 to-yellow-300 rounded-full shadow-lg"
                    />
                  </div>
                </motion.div>

                {/* Enhanced Title with Gradient Animation */}
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3, duration: 0.8 }}
                  className="mb-8"
                >
                  <h2 className="text-4xl md:text-6xl font-bold mb-4 relative">
                    <span className="bg-gradient-to-r from-orange-600 via-orange-500 to-yellow-500 bg-clip-text text-transparent drop-shadow-lg">
                      Let's Get Started!
                    </span>
                    
                    {/* Animated underline */}
                    <motion.div
                      animate={{
                        scaleX: [0, 1, 0],
                        opacity: [0, 1, 0]
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                      className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 h-1 w-32 bg-gradient-to-r from-orange-400 to-yellow-400 rounded-full"
                    />
                  </h2>
                  
                  {/* Subtitle with enhanced styling */}
                  <p className="text-xl md:text-2xl text-slate-700 font-medium leading-relaxed max-w-3xl mx-auto">
                    Upload your resume and documents. Our AI will analyze them and start finding 
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-yellow-600 font-semibold"> perfect job matches </span>
                    across LinkedIn, Xing, StepStone, and Indeed.
                  </p>
                </motion.div>
                
                {/* Enhanced Process Steps */}
                <motion.div 
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6, duration: 0.8 }}
                  className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-12"
                >
                  {[
                    { emoji: "📄", text: "Upload Resume", color: "from-orange-500 to-orange-400" },
                    { emoji: "🤖", text: "AI Analysis", color: "from-orange-400 to-yellow-500" },
                    { emoji: "🎯", text: "Job Matching", color: "from-yellow-500 to-yellow-400" },
                    { emoji: "✉️", text: "Custom Applications", color: "from-yellow-400 to-orange-400" },
                    { emoji: "🚀", text: "Auto Send", color: "from-orange-400 to-orange-500" }
                  ].map((step, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, scale: 0.8, y: 20 }}
                      animate={{ opacity: 1, scale: 1, y: 0 }}
                      transition={{ delay: 0.8 + index * 0.1, duration: 0.6 }}
                      whileHover={{ 
                        scale: 1.05, 
                        y: -5,
                        transition: { duration: 0.2 }
                      }}
                      className="flex flex-col items-center p-6 rounded-2xl bg-white/60 backdrop-blur-sm border border-orange-200/30 shadow-lg hover:shadow-xl transition-all duration-300 group cursor-pointer"
                    >
                      <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${step.color} flex items-center justify-center shadow-lg mb-4 group-hover:shadow-xl transition-shadow duration-300`}>
                        <span className="text-2xl group-hover:scale-110 transition-transform duration-300">{step.emoji}</span>
                      </div>
                      <span className="font-semibold text-slate-800 text-center group-hover:text-orange-600 transition-colors duration-300">{step.text}</span>
                    </motion.div>
                  ))}
                </motion.div>

                {/* Enhanced CTA Button */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 1.3, duration: 0.8 }}
                >
                  <Button
                    onClick={handleUploadResume}
                    className="relative overflow-hidden gradient-button glow-orange text-white px-6 sm:px-12 py-4 sm:py-6 text-base sm:text-xl font-bold rounded-2xl shadow-2xl hover:shadow-3xl transition-all duration-300 group w-full sm:w-auto"
                    size="lg"
                  >
                    {/* Button background effects */}
                    <div className="absolute inset-0 bg-gradient-to-r from-orange-600 via-orange-500 to-yellow-500 opacity-90 group-hover:opacity-100 transition-opacity duration-300" />
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                    
                    {/* Button content */}
                    <div className="relative flex items-center justify-center space-x-2 sm:space-x-3">
                      <Upload className="w-5 h-5 sm:w-6 sm:h-6 group-hover:scale-110 transition-transform duration-300" />
                      <span className="group-hover:tracking-wide transition-all duration-300 text-center leading-tight">
                        <span className="block sm:inline">Upload Resume</span>
                        <span className="hidden sm:inline"> & </span>
                        <span className="block sm:inline">Start AI</span>
                      </span>
                      <motion.div
                        animate={{
                          rotate: [0, 360]
                        }}
                        transition={{
                          duration: 3,
                          repeat: Infinity,
                          ease: "linear"
                        }}
                        className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-white/20 flex items-center justify-center"
                      >
                        <Sparkles className="w-3 h-3 sm:w-4 sm:h-4" />
                      </motion.div>
                    </div>
                    
                    {/* Pulsing glow effect */}
                    <motion.div
                      animate={{
                        scale: [1, 1.05, 1],
                        opacity: [0.5, 0.8, 0.5]
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                      className="absolute inset-0 rounded-2xl bg-gradient-to-r from-orange-400 to-yellow-400 blur-lg -z-10"
                    />
                  </Button>
                </motion.div>

                {/* Trust indicators */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.6, duration: 0.8 }}
                  className="mt-12 flex flex-wrap justify-center items-center gap-8 text-sm text-slate-600"
                >
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-green-500 animate-pulse" />
                    <span>AI-Powered</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-blue-500 animate-pulse" style={{animationDelay: '0.5s'}} />
                    <span>Secure & Private</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-purple-500 animate-pulse" style={{animationDelay: '1s'}} />
                    <span>24/7 Automated</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-orange-500 animate-pulse" style={{animationDelay: '1.5s'}} />
                    <span>Multi-Platform</span>
                  </div>
                </motion.div>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          /* Main Dashboard */
          <>
            {/* Today's Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              {[
                { label: 'Applications Today', value: todayStats.applicationsToday, icon: Send, color: 'from-[#ea580c] to-[#f97316]', suffix: '' },
                { label: 'Cover Letters', value: todayStats.coverLettersCreated, icon: FileText, color: 'from-[#f97316] to-[#fbbf24]', suffix: ' created' },
                { label: 'Jobs Found', value: todayStats.jobsFound, icon: Search, color: 'from-[#fbbf24] to-[#fde047]', suffix: ' new' },
                { label: 'Responses', value: todayStats.responsesReceived, icon: Mail, color: 'from-[#fde047] to-[#facc15]', suffix: ' received' },
              ].map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1, duration: 0.5 }}
                  >
                    <Card className="glass glow-orange shadow-lg hover:shadow-xl transition-all duration-300 border-orange-200/30">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-sm text-slate-600 mb-1">{stat.label}</p>
                            <p className="text-2xl font-bold gradient-text">
                              {stat.value}
                            </p>
                            <p className="text-xs text-slate-500">{stat.suffix}</p>
                          </div>
                          <div className={`w-12 h-12 rounded-full bg-gradient-to-r ${stat.color} flex items-center justify-center shadow-lg`}>
                            <Icon className="w-6 h-6 text-white" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
              
              {/* AI Job Queue */}
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
                className="xl:col-span-2"
              >
                <Card className="glass glow-orange shadow-xl border-orange-200/30">
                  <CardHeader className="flex flex-row items-center justify-between">
                    <div>
                      <CardTitle className="gradient-text flex items-center">
                        <Target className="w-5 h-5 mr-2" />
                        AI Job Queue
                      </CardTitle>
                      <CardDescription>Jobs found by AI - filtered and ready for application</CardDescription>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={`${aiRunning ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {aiRunning ? 'AI Active' : 'AI Paused'}
                      </Badge>
                      <Button
                        onClick={() => navigate('/tracker')}
                        variant="outline"
                        size="sm"
                        className="border-orange-200 hover:bg-orange-50 btn-hover-lift"
                      >
                        View All
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {aiJobQueue.map((job, index) => (
                        <motion.div
                          key={job.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.1, duration: 0.5 }}
                          className="flex items-center justify-between p-4 rounded-xl bg-white/60 border border-orange-100 hover:bg-white/80 transition-all duration-200 group"
                        >
                          <div className="flex items-center space-x-4 flex-1">
                            <div className="text-2xl">{getPlatformIcon(job.platform)}</div>
                            <div className="flex-1">
                              <h4 className="font-semibold text-slate-800 group-hover:text-orange-600 transition-colors">
                                {job.title}
                              </h4>
                              <p className="text-sm text-slate-600">{job.company} • {job.location}</p>
                              <p className="text-xs text-slate-500">{job.salary} • {job.posted}</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <Badge className={`${job.match >= 90 ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                              {job.match}% match
                            </Badge>
                            <Badge className={`${getStatusColor(job.status)} border-0`}>
                              {job.status}
                            </Badge>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                    
                    <div className="mt-6 p-4 rounded-xl bg-gradient-to-r from-orange-50 to-yellow-50 border border-orange-100">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-semibold text-orange-800">AI Filtering Options</p>
                          <p className="text-sm text-orange-600">Salary: €50k+, Location: Germany, Type: Full-time</p>
                        </div>
                        <Button
                          onClick={() => navigate('/tracker')}
                          variant="outline"
                          size="sm"
                          className="border-orange-300 text-orange-600 hover:bg-orange-100"
                        >
                          <Filter className="w-4 h-4 mr-2" />
                          Adjust Filters
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Email Notifications */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6 }}
              >
                <Card className="glass glow-orange shadow-xl border-orange-200/30 h-fit">
                  <CardHeader>
                    <CardTitle className="gradient-text flex items-center">
                      <Bell className="w-5 h-5 mr-2" />
                      Email Center
                    </CardTitle>
                    <CardDescription>Latest notifications and responses</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {notifications.map((notif, index) => (
                        <motion.div
                          key={notif.id}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1, duration: 0.5 }}
                          className={`p-4 rounded-xl border transition-all duration-200 hover:shadow-md ${
                            notif.urgent 
                              ? 'bg-gradient-to-r from-red-50 to-orange-50 border-red-100' 
                              : 'bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-100'
                          }`}
                        >
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center mb-1">
                                {notif.urgent && <AlertCircle className="w-4 h-4 text-red-500 mr-2" />}
                                <span className={`text-sm ${notif.urgent ? 'text-red-600' : 'text-blue-600'}`}>
                                  {notif.type === 'response' ? '📧 Response' : 
                                   notif.type === 'applied' ? '✅ Applied' : '🔍 Found'}
                                </span>
                              </div>
                              <p className="font-medium text-slate-800">{notif.message}</p>
                              <p className="text-xs text-slate-500 mt-1">{notif.time}</p>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                    
                    <Button 
                      className="w-full mt-4 gradient-button glow-orange text-white btn-hover-lift"
                      onClick={() => navigate('/email')}
                    >
                      <Mail className="w-4 h-4 mr-2" />
                      Open Email Center
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>

              {/* Quick Actions */}
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="lg:col-span-2 xl:col-span-1"
              >
                <Card className="glass glow-orange shadow-xl border-orange-200/30">
                  <CardHeader>
                    <CardTitle className="gradient-text flex items-center">
                      <Zap className="w-5 h-5 mr-2" />
                      Quick Actions
                    </CardTitle>
                    <CardDescription>Manage your job search</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {[
                      { label: 'Upload New Resume', icon: Upload, path: '/documents', color: 'from-[#ea580c] to-[#f97316]' },
                      { label: 'View Applications', icon: Briefcase, path: '/tracker', color: 'from-[#f97316] to-[#fbbf24]' },
                      { label: 'Email Responses', icon: Mail, path: '/email', color: 'from-[#fbbf24] to-[#fde047]' },
                      { label: 'AI Settings', icon: Settings, path: '/settings', color: 'from-[#fde047] to-[#facc15]' },
                    ].map((action, index) => {
                      const Icon = action.icon;
                      return (
                        <Button
                          key={index}
                          onClick={() => navigate(action.path)}
                          variant="ghost"
                          className="w-full justify-start p-4 h-auto hover:bg-orange-50 btn-hover-lift group"
                        >
                          <div className={`w-10 h-10 rounded-lg bg-gradient-to-r ${action.color} flex items-center justify-center mr-3 shadow-md group-hover:shadow-lg transition-shadow`}>
                            <Icon className="w-5 h-5 text-white" />
                          </div>
                          <span className="font-medium">{action.label}</span>
                          <ArrowRight className="w-4 h-4 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
                        </Button>
                      );
                    })}
                  </CardContent>
                </Card>
              </motion.div>

              {/* AI Performance Summary */}
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                <Card className="glass glow-orange shadow-xl border-orange-200/30">
                  <CardHeader>
                    <CardTitle className="gradient-text flex items-center">
                      <TrendingUp className="w-5 h-5 mr-2" />
                      AI Performance
                    </CardTitle>
                    <CardDescription>Your AI's success metrics</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-slate-600">Success Rate</span>
                        <span className="text-sm font-semibold text-green-600">89%</span>
                      </div>
                      <Progress value={89} className="h-2 bg-orange-100" />
                    </div>
                    
                    <div>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm text-slate-600">Response Rate</span>
                        <span className="text-sm font-semibold text-blue-600">67%</span>
                      </div>
                      <Progress value={67} className="h-2 bg-orange-100" />
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-green-50 to-emerald-50 border border-green-100">
                        <div className="flex items-center">
                          <Sparkles className="w-5 h-5 text-green-500 mr-2" />
                          <span className="text-sm text-green-700">AI Optimizations</span>
                        </div>
                        <Badge className="bg-green-100 text-green-700">ACTIVE</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between p-3 rounded-lg bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-100">
                        <div className="flex items-center">
                          <Clock className="w-5 h-5 text-blue-500 mr-2" />
                          <span className="text-sm text-blue-700">Auto-Apply Schedule</span>
                        </div>
                        <Badge className="bg-blue-100 text-blue-700">24/7</Badge>
                      </div>
                    </div>

                    <Button 
                      className="w-full gradient-button glow-orange text-white btn-hover-lift"
                      onClick={() => navigate('/settings')}
                    >
                      <Settings className="w-4 h-4 mr-2" />
                      AI Settings
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default Dashboard;