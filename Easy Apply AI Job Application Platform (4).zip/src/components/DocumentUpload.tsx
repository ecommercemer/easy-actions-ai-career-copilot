import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ImageWithFallback } from './figma/ImageWithFallback';
import EasyActionsLogo from './EasyActionsLogo';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import {
  Upload,
  FileText,
  CheckCircle,
  X,
  ArrowRight,
  Sparkles,
  Target,
  Send,
  Clock,
  FileCheck,
  AlertCircle,
  Download,
  Eye,
  Trash2,
  ArrowLeft
} from 'lucide-react';

interface DocumentUploadProps {
  onBack?: () => void;
  onComplete?: () => void;
}

interface UploadedFile {
  id: string;
  name: string;
  type: string;
  size: number;
  status: 'uploading' | 'analyzing' | 'complete' | 'error';
  progress: number;
  analysis?: {
    score: number;
    suggestions: string[];
    keywords: number;
    experience: string;
  };
}

export default function DocumentUpload({ onBack, onComplete }: DocumentUploadProps) {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [currentStep, setCurrentStep] = useState(1); // 1: Upload, 2: Analysis, 3: Results
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (files: FileList | null) => {
    if (!files) return;

    Array.from(files).forEach((file, index) => {
      const fileId = Date.now().toString() + index;
      const newFile: UploadedFile = {
        id: fileId,
        name: file.name,
        type: file.type,
        size: file.size,
        status: 'uploading',
        progress: 0
      };

      setUploadedFiles(prev => [...prev, newFile]);
      simulateFileProcessing(fileId);
    });
  };

  const simulateFileProcessing = async (fileId: string) => {
    setIsProcessing(true);

    // Upload simulation
    for (let progress = 0; progress <= 100; progress += 10) {
      await new Promise(resolve => setTimeout(resolve, 100));
      setUploadedFiles(prev => prev.map(file => 
        file.id === fileId 
          ? { ...file, progress, status: progress === 100 ? 'analyzing' : 'uploading' }
          : file
      ));
    }

    // Analysis simulation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockAnalysis = {
      score: 75 + Math.floor(Math.random() * 20),
      suggestions: [
        'Add more industry-specific keywords',
        'Include quantifiable achievements',
        'Optimize for ATS compatibility',
        'Highlight technical skills more prominently'
      ],
      keywords: 12 + Math.floor(Math.random() * 8),
      experience: ['Entry Level', 'Mid Level', 'Senior Level'][Math.floor(Math.random() * 3)]
    };

    setUploadedFiles(prev => prev.map(file => 
      file.id === fileId 
        ? { ...file, status: 'complete', analysis: mockAnalysis }
        : file
    ));

    setIsProcessing(false);
    
    // Auto-advance to results step
    setTimeout(() => {
      setCurrentStep(3);
    }, 1000);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    handleFileUpload(e.dataTransfer.files);
  };

  const removeFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(file => file.id !== fileId));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getStatusIcon = (status: UploadedFile['status']) => {
    switch (status) {
      case 'uploading':
        return <Upload className="w-5 h-5 text-blue-500" />;
      case 'analyzing':
        return <Sparkles className="w-5 h-5 text-orange-500 animate-spin" />;
      case 'complete':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
    }
  };

  const completedFiles = uploadedFiles.filter(file => file.status === 'complete');

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#fff7ed] via-[#fed7aa] to-[#fb923c] p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.header 
          className="flex items-center justify-between mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center space-x-4">
            {onBack && (
              <Button
                variant="outline"
                size="sm"
                onClick={onBack}
                className="border-orange-200 hover:bg-orange-50"
              >
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            )}
            <EasyActionsLogo size="sm" showText={true} />
          </div>
          <div className="flex items-center space-x-4">
            <ImageWithFallback
              src={robotImage}
              alt="AI Assistant Robot"
              className="w-12 h-12 rounded-full shadow-lg border-2 border-white/50 robot-bounce"
            />
            <div>
              <h2 className="text-lg font-bold gradient-text">Jobby AI Assistant</h2>
              <p className="text-sm text-orange-600">Analyzing your documents...</p>
            </div>
          </div>
        </motion.header>

        {/* Progress Steps */}
        <motion.div 
          className="flex justify-center mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center space-x-8">
            {[
              { step: 1, title: 'Upload', icon: Upload },
              { step: 2, title: 'Analysis', icon: Sparkles },
              { step: 3, title: 'Results', icon: Target }
            ].map(({ step, title, icon: Icon }, index) => (
              <div key={step} className="flex items-center">
                <div className={`flex flex-col items-center ${
                  currentStep >= step ? 'text-orange-600' : 'text-gray-400'
                }`}>
                  <div className={`w-12 h-12 rounded-full border-2 flex items-center justify-center mb-2 transition-all duration-500 ${
                    currentStep >= step 
                      ? 'border-orange-500 bg-orange-500 text-white shadow-lg' 
                      : 'border-gray-300 bg-white text-gray-400'
                  }`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-medium">{title}</span>
                </div>
                {index < 2 && (
                  <div className={`w-16 h-0.5 mx-4 transition-all duration-500 ${
                    currentStep > step ? 'bg-orange-500' : 'bg-gray-300'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Step 1: Upload */}
          {currentStep === 1 && (
            <motion.div
              key="upload"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-6"
            >
              <div className="text-center">
                <h1 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
                  Upload Your Documents
                </h1>
                <p className="text-lg text-slate-600 mb-8">
                  Upload your resume, cover letter, and certificates. Our AI will analyze and optimize them for maximum impact.
                </p>
              </div>

              {/* Upload Area */}
              <Card className="glass glow-orange shadow-2xl">
                <CardContent className="p-8">
                  <div
                    className={`border-2 border-dashed rounded-xl p-12 text-center transition-all duration-300 cursor-pointer ${
                      isDragging
                        ? 'border-orange-500 bg-orange-50 scale-105'
                        : 'border-orange-300 hover:border-orange-500 hover:bg-orange-50/50'
                    }`}
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <motion.div
                      animate={isDragging ? { scale: 1.1, rotate: 5 } : { scale: 1, rotate: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      <Upload className="w-16 h-16 text-orange-500 mx-auto mb-4" />
                    </motion.div>
                    <h3 className="text-xl font-semibold text-slate-800 mb-2">
                      {isDragging ? 'Drop your files here' : 'Drag & drop your documents'}
                    </h3>
                    <p className="text-slate-600 mb-4">
                      or <span className="text-orange-600 font-medium">browse files</span>
                    </p>
                    <div className="flex justify-center flex-wrap gap-2">
                      {['PDF', 'DOC', 'DOCX', 'TXT'].map(format => (
                        <Badge key={format} variant="secondary" className="bg-orange-100 text-orange-800">
                          {format}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    multiple
                    accept=".pdf,.doc,.docx,.txt"
                    onChange={(e) => handleFileUpload(e.target.files)}
                    className="hidden"
                  />

                  {uploadedFiles.length > 0 && (
                    <div className="mt-6 space-y-3">
                      {uploadedFiles.map(file => (
                        <motion.div
                          key={file.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="flex items-center justify-between p-4 rounded-lg bg-white/60 border border-orange-200"
                        >
                          <div className="flex items-center space-x-3">
                            {getStatusIcon(file.status)}
                            <div>
                              <p className="font-medium text-slate-800">{file.name}</p>
                              <p className="text-sm text-slate-500">{formatFileSize(file.size)}</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-4">
                            {file.status === 'uploading' && (
                              <div className="w-24">
                                <Progress value={file.progress} className="h-2" />
                              </div>
                            )}
                            {file.status === 'analyzing' && (
                              <div className="flex items-center text-orange-600">
                                <Sparkles className="w-4 h-4 animate-pulse mr-2" />
                                <span className="text-sm">Analyzing...</span>
                              </div>
                            )}
                            {file.status === 'complete' && (
                              <Badge className="bg-green-100 text-green-800">Complete</Badge>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => removeFile(file.id)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>

              {uploadedFiles.length > 0 && (
                <div className="flex justify-center">
                  <Button
                    onClick={() => setCurrentStep(2)}
                    className="gradient-button text-white px-8 py-3 text-lg font-semibold btn-hover-lift"
                    disabled={!uploadedFiles.some(file => file.status === 'complete')}
                  >
                    Continue Analysis
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </div>
              )}
            </motion.div>
          )}

          {/* Step 3: Results */}
          {currentStep === 3 && completedFiles.length > 0 && (
            <motion.div
              key="results"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="space-y-6"
            >
              <div className="text-center">
                <h1 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
                  Analysis Complete! 🎉
                </h1>
                <p className="text-lg text-slate-600 mb-8">
                  Your documents have been analyzed and optimized. Here's what we found:
                </p>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                {completedFiles.map(file => (
                  <motion.div
                    key={file.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <Card className="glass glow-orange shadow-xl hover:shadow-2xl transition-all duration-300">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="gradient-text">{file.name}</CardTitle>
                          <Badge 
                            className={`${
                              file.analysis!.score >= 80 ? 'bg-green-100 text-green-800' :
                              file.analysis!.score >= 60 ? 'bg-yellow-100 text-yellow-800' :
                              'bg-red-100 text-red-800'
                            }`}
                          >
                            Score: {file.analysis!.score}/100
                          </Badge>
                        </div>
                      </CardHeader>
                      
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="text-center p-3 rounded-lg bg-orange-50 border border-orange-200">
                            <p className="text-2xl font-bold text-orange-600">{file.analysis!.keywords}</p>
                            <p className="text-sm text-slate-600">Keywords Found</p>
                          </div>
                          <div className="text-center p-3 rounded-lg bg-orange-50 border border-orange-200">
                            <p className="text-sm font-medium text-orange-600">{file.analysis!.experience}</p>
                            <p className="text-sm text-slate-600">Experience Level</p>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2 text-slate-800">Improvement Suggestions:</h4>
                          <ul className="space-y-1">
                            {file.analysis!.suggestions.map((suggestion, index) => (
                              <li key={index} className="flex items-center text-sm text-slate-700">
                                <Sparkles className="w-3 h-3 text-orange-500 mr-2" />
                                {suggestion}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" className="flex-1 border-orange-200 hover:bg-orange-50">
                            <Eye className="w-4 h-4 mr-2" />
                            Preview
                          </Button>
                          <Button variant="outline" size="sm" className="flex-1 border-orange-200 hover:bg-orange-50">
                            <Download className="w-4 h-4 mr-2" />
                            Download
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              {/* Action Buttons */}
              <motion.div 
                className="text-center space-y-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <div className="bg-white/60 rounded-2xl p-6 glass">
                  <h3 className="text-xl font-bold gradient-text mb-3">Next Steps</h3>
                  <p className="text-slate-600 mb-6">
                    Your documents are optimized! Now let's find perfect job matches and start applying automatically.
                  </p>
                  
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button
                      onClick={onComplete}
                      className="gradient-button text-white px-8 py-3 text-lg font-semibold glow-orange btn-hover-lift"
                    >
                      <Target className="w-5 h-5 mr-2" />
                      Find Job Matches
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setCurrentStep(1)}
                      className="border-orange-200 hover:bg-orange-50"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Upload More Documents
                    </Button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}