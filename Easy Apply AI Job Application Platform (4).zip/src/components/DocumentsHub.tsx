import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import EasyActionsLogo from './EasyActionsLogo';
import {
  Upload,
  FileText,
  Download,
  Edit,
  CheckCircle,
  AlertCircle,
  Trash2,
  Eye,
  Sparkles,
  Zap,
  Star,
  Target,
  Brain,
  Shield,
  RefreshCw,
  Plus,
  Archive,
  BookOpen,
  Award,
  FilePlus,
  Search,
  Filter,
  Grid,
  List
} from 'lucide-react';

export default function DocumentsHub() {
  const [coverLetter, setCoverLetter] = useState(`Dear Hiring Manager,

I am writing to express my strong interest in the position at your company. With my background in software development and passion for creating innovative solutions, I believe I would be a valuable addition to your team.

Throughout my career, I have demonstrated proficiency in modern web technologies and have consistently delivered high-quality projects. I am particularly excited about the opportunity to contribute to your company's mission and grow alongside your talented team.

I look forward to the opportunity to discuss how my skills and enthusiasm can contribute to your organization's success.

Best regards,
[Your Name]`);

  const documents = [
    { id: 1, name: 'Software_Developer_Resume.pdf', type: 'Resume', status: 'optimized', size: '245 KB' },
    { id: 2, name: 'React_Certification.pdf', type: 'Certificate', status: 'uploaded', size: '180 KB' },
    { id: 3, name: 'AWS_Cloud_Practitioner.pdf', type: 'Certificate', status: 'uploaded', size: '200 KB' },
  ];

  const aiRecommendations = [
    "Consider adding more quantifiable achievements to your resume",
    "Your technical skills section could be more prominent",
    "Add a brief summary section at the top of your resume",
    "Consider including links to your portfolio projects"
  ];

  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 p-4 md:p-6 pt-0">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Enhanced Header with Logo and Robot */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8 space-y-4 lg:space-y-0"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <EasyActionsLogo size="lg" showText={true} className="hidden sm:flex" />
            
            {/* Mobile: Logo stacked */}
            <div className="flex flex-col sm:hidden space-y-2">
              <EasyActionsLogo size="md" showText={true} />
            </div>
            
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold gradient-text drop-shadow-sm leading-tight">
                <span className="block sm:inline">Document</span>
                <span className="block sm:inline"> </span>
                <span className="block sm:inline">Hub 📁</span>
              </h1>
              <p className="text-slate-600 mt-2 text-sm sm:text-base leading-relaxed">
                Manage your AI-optimized resume, cover letters, and certificates
              </p>
            </div>
          </div>
          
          {/* AI Assistant Robot with Enhanced Positioning */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative self-center lg:self-auto"
          >
            <motion.div
              animate={{
                y: [0, -10, 0],
                rotate: [0, 3, -3, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="relative"
            >
              <ImageWithFallback
                src={robotImage}
                alt="AI Assistant Robot"
                className="w-16 h-16 md:w-20 md:h-20 rounded-full shadow-lg border-2 border-white/80 robot-bounce"
              />
              
              {/* Speech bubble with dynamic content */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5 }}
                className="absolute -top-16 -left-24 md:-left-36 bg-white rounded-2xl p-3 shadow-lg border border-orange-200/30 max-w-52"
              >
                <p className="text-xs font-medium text-slate-700">
                  Your documents are {Math.round((documents.filter(d => d.status === 'optimized').length / documents.length) * 100)}% optimized! 
                  Ready to impress employers! ✨
                </p>
                <div className="absolute bottom-0 left-10 w-3 h-3 bg-white transform rotate-45 translate-y-1/2 border-r border-b border-orange-200/30" />
              </motion.div>
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Document Stats & Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-8"
        >
          {[
            { 
              label: 'Documents', 
              value: documents.length, 
              icon: FileText, 
              color: 'from-[#ea580c] to-[#f97316]',
              bgColor: 'bg-orange-50' 
            },
            { 
              label: 'AI Optimized', 
              value: documents.filter(d => d.status === 'optimized').length, 
              icon: Brain, 
              color: 'from-[#f97316] to-[#fbbf24]',
              bgColor: 'bg-amber-50' 
            },
            { 
              label: 'Certificates', 
              value: documents.filter(d => d.type === 'Certificate').length, 
              icon: Award, 
              color: 'from-[#fbbf24] to-[#fde047]',
              bgColor: 'bg-yellow-50' 
            },
            { 
              label: 'Templates', 
              value: 1, 
              icon: BookOpen, 
              color: 'from-[#fde047] to-[#facc15]',
              bgColor: 'bg-lime-50' 
            }
          ].map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
                whileHover={{ scale: 1.02, y: -2 }}
              >
                <Card className={`glass glow-orange shadow-lg hover:shadow-xl transition-all duration-300 border-orange-200/30 ${stat.bgColor}/30`}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-slate-600 mb-1 font-medium">{stat.label}</p>
                        <p className="text-2xl md:text-3xl font-bold gradient-text">{stat.value}</p>
                      </div>
                      <div className={`w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-r ${stat.color} flex items-center justify-center shadow-lg`}>
                        <Icon className="w-6 h-6 md:w-7 md:h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Action Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6"
        >
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
            <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
              className="border-orange-200 hover:bg-orange-50 btn-hover-lift"
            >
              {viewMode === 'grid' ? <List className="w-4 h-4 mr-2" /> : <Grid className="w-4 h-4 mr-2" />}
              {viewMode === 'grid' ? 'List' : 'Grid'}
            </Button>
          </div>
          
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
              <RefreshCw className="w-4 h-4 mr-2" />
              Sync
            </Button>
            <Button className="gradient-button glow-orange text-white btn-hover-lift" size="sm">
              <Upload className="w-4 h-4 mr-2" />
              Upload
            </Button>
          </div>
        </motion.div>

        {/* Enhanced Resume Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
        >
          <Card className="glass glow-orange shadow-xl border-orange-200/30">
            <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50 rounded-t-lg">
              <CardTitle className="gradient-text flex items-center text-xl">
                <FileText className="w-6 h-6 mr-3" />
                AI-Powered Resume Optimization
              </CardTitle>
              <p className="text-slate-600 text-sm">Upload your resume and let AI enhance it for maximum impact</p>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Enhanced Upload Area */}
                <div className="lg:col-span-1">
                  <div className="relative border-2 border-dashed border-orange-300 rounded-xl p-6 text-center hover:border-orange-400 hover:bg-orange-50/50 transition-all duration-200 group cursor-pointer">
                    <motion.div
                      animate={{ y: [0, -5, 0] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    >
                      <Upload className="w-12 h-12 text-orange-400 mx-auto mb-4 group-hover:text-orange-500 transition-colors" />
                    </motion.div>
                    <p className="text-slate-600 mb-3 font-medium">Drop your resume here or</p>
                    <Button className="gradient-button glow-orange text-white btn-hover-lift">
                      <FilePlus className="w-4 h-4 mr-2" />
                      Choose File
                    </Button>
                    <p className="text-xs text-slate-500 mt-3">PDF, DOC, DOCX up to 5MB</p>
                    
                    {/* Floating particles */}
                    <motion.div
                      animate={{
                        y: [0, -20, 0],
                        x: [0, 10, 0],
                        opacity: [0.6, 1, 0.6]
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                      className="absolute top-4 right-4 w-3 h-3 bg-gradient-to-br from-orange-400 to-yellow-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    />
                  </div>
                  
                  {/* Current Resume with Enhanced Styling */}
                  {documents.find(doc => doc.type === 'Resume') && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.6 }}
                      className="mt-4 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200 shadow-lg"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center">
                          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center mr-3 shadow-lg">
                            <FileText className="w-5 h-5 text-white" />
                          </div>
                          <div>
                            <p className="font-semibold text-green-800">Software_Developer_Resume.pdf</p>
                            <p className="text-sm text-green-600">245 KB • Last optimized 2 hours ago</p>
                          </div>
                        </div>
                        <Badge className="bg-green-100 text-green-800 border-green-200">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          AI Optimized
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <Button size="sm" variant="outline" className="border-green-200 hover:bg-green-100 btn-hover-lift">
                          <Eye className="w-4 h-4 mr-1" />
                          Preview
                        </Button>
                        <Button size="sm" variant="outline" className="border-green-200 hover:bg-green-100 btn-hover-lift">
                          <Download className="w-4 h-4 mr-1" />
                          Download
                        </Button>
                        <Button size="sm" variant="outline" className="border-green-200 hover:bg-green-100 btn-hover-lift">
                          <Sparkles className="w-4 h-4 mr-1" />
                          Re-optimize
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </div>

                {/* Enhanced AI Feedback */}
                <div className="lg:col-span-2">
                  <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl p-6 border border-blue-200 shadow-lg h-full">
                    <div className="flex items-start justify-between mb-4">
                      <h3 className="text-lg font-semibold text-blue-900 flex items-center">
                        <Brain className="w-5 h-5 mr-2" />
                        AI Analysis & Recommendations
                      </h3>
                      <Badge className="bg-blue-100 text-blue-700 border-blue-200">
                        <Target className="w-3 h-3 mr-1" />
                        95% Match Score
                      </Badge>
                    </div>
                    
                    <div className="space-y-4 mb-6">
                      {aiRecommendations.map((recommendation, index) => (
                        <motion.div 
                          key={index}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.6 + index * 0.1 }}
                          className="flex items-start p-3 bg-white/60 rounded-lg border border-blue-100"
                        >
                          <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center mr-3 mt-0.5 flex-shrink-0">
                            <span className="text-white text-xs font-bold">{index + 1}</span>
                          </div>
                          <p className="text-blue-800 font-medium text-sm">{recommendation}</p>
                        </motion.div>
                      ))}
                    </div>
                    
                    <div className="flex flex-wrap gap-3">
                      <Button className="gradient-button glow-orange text-white btn-hover-lift">
                        <Zap className="w-4 h-4 mr-2" />
                        Apply AI Suggestions
                      </Button>
                      <Button variant="outline" className="border-blue-200 hover:bg-blue-50 btn-hover-lift">
                        <Star className="w-4 h-4 mr-2" />
                        Save as Template
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Enhanced Cover Letter Template */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <Card className="glass glow-orange shadow-xl border-orange-200/30">
            <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-t-lg">
              <CardTitle className="gradient-text flex items-center justify-between text-xl">
                <div className="flex items-center">
                  <Edit className="w-6 h-6 mr-3" />
                  Smart Cover Letter Template
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" className="border-green-200 hover:bg-green-50 btn-hover-lift">
                    <Shield className="w-4 h-4 mr-2" />
                    Auto-Save: On
                  </Button>
                  <Button size="sm" className="gradient-button glow-orange text-white btn-hover-lift">
                    Save Changes
                  </Button>
                </div>
              </CardTitle>
              <p className="text-slate-600 text-sm">Create your base template - AI will personalize it for each application</p>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <Card className="p-4 bg-gradient-to-br from-orange-50 to-yellow-50 border border-orange-200">
                    <div className="flex items-center mb-2">
                      <Sparkles className="w-4 h-4 text-orange-500 mr-2" />
                      <span className="font-medium text-slate-700">AI Personalization</span>
                    </div>
                    <p className="text-xs text-slate-600">Automatically adapts for each job</p>
                  </Card>
                  <Card className="p-4 bg-gradient-to-br from-blue-50 to-cyan-50 border border-blue-200">
                    <div className="flex items-center mb-2">
                      <Target className="w-4 h-4 text-blue-500 mr-2" />
                      <span className="font-medium text-slate-700">Keyword Matching</span>
                    </div>
                    <p className="text-xs text-slate-600">Optimized for ATS systems</p>
                  </Card>
                  <Card className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 border border-green-200">
                    <div className="flex items-center mb-2">
                      <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                      <span className="font-medium text-slate-700">Success Rate</span>
                    </div>
                    <p className="text-xs text-slate-600">87% higher response rate</p>
                  </Card>
                </div>
                
                <Textarea
                  value={coverLetter}
                  onChange={(e) => setCoverLetter(e.target.value)}
                  className="min-h-[300px] rounded-xl border-orange-200 focus:border-orange-400 focus:ring-orange-400 bg-white/60"
                  placeholder="Write your cover letter template here..."
                />
                
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div className="flex items-center space-x-4 text-sm text-slate-600">
                    <span className="flex items-center">
                      <Archive className="w-4 h-4 mr-1" />
                      {coverLetter.length} characters
                    </span>
                    <span className="flex items-center">
                      <Brain className="w-4 h-4 mr-1" />
                      AI will personalize for each job
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
                      <Eye className="w-4 h-4 mr-2" />
                      Preview
                    </Button>
                    <Button className="gradient-button glow-orange text-white btn-hover-lift">
                      <Sparkles className="w-4 h-4 mr-2" />
                      Test AI Customization
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Enhanced Certificates & Documents */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.7 }}
        >
          <Card className="glass glow-orange shadow-xl border-orange-200/30">
            <CardHeader className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-t-lg">
              <CardTitle className="gradient-text flex items-center justify-between text-xl">
                <div className="flex items-center">
                  <Award className="w-6 h-6 mr-3" />
                  Certificates & Supporting Documents
                </div>
                <Button className="gradient-button glow-orange text-white btn-hover-lift">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Document
                </Button>
              </CardTitle>
              <p className="text-slate-600 text-sm">Showcase your achievements and qualifications</p>
            </CardHeader>
            <CardContent className="p-6">
              <div className={`space-y-4 ${viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 gap-4' : ''}`}>
                {documents.filter(doc => doc.type === 'Certificate').map((doc, index) => (
                  <motion.div 
                    key={doc.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.8 + index * 0.1 }}
                    className="flex items-center justify-between p-4 bg-gradient-to-r from-white/80 to-purple-50/50 rounded-xl border border-purple-200 shadow-lg hover:shadow-xl transition-all duration-200 group"
                  >
                    <div className="flex items-center">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 to-indigo-500 flex items-center justify-center mr-4 shadow-lg">
                        <Award className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900 group-hover:text-purple-600 transition-colors">{doc.name}</p>
                        <p className="text-sm text-slate-600">{doc.type} • {doc.size}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Verified
                      </Badge>
                      <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button size="sm" variant="outline" className="border-purple-200 hover:bg-purple-50">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="border-purple-200 hover:bg-purple-50">
                          <Download className="w-4 h-4" />
                        </Button>
                        <Button size="sm" variant="outline" className="border-red-200 hover:bg-red-50 text-red-600">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Enhanced Upload Area */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="mt-8 relative border-2 border-dashed border-purple-300 rounded-xl p-8 text-center hover:border-purple-400 hover:bg-purple-50/50 transition-all duration-200 group cursor-pointer"
              >
                <motion.div
                  animate={{ 
                    scale: [1, 1.05, 1],
                    rotate: [0, 5, -5, 0]
                  }}
                  transition={{ duration: 4, repeat: Infinity }}
                >
                  <Plus className="w-8 h-8 text-purple-400 mx-auto mb-3 group-hover:text-purple-500 transition-colors" />
                </motion.div>
                <p className="text-slate-600 mb-2 font-medium">Add certificates, portfolios, or references</p>
                <p className="text-sm text-slate-500">PDF, DOC, DOCX, JPG, PNG up to 10MB each</p>
                
                {/* Floating elements */}
                <motion.div
                  animate={{
                    y: [0, -15, 0],
                    opacity: [0.6, 1, 0.6]
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                  className="absolute top-6 right-6 w-4 h-4 bg-gradient-to-br from-purple-400 to-indigo-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                />
                <motion.div
                  animate={{
                    y: [0, -10, 0],
                    opacity: [0.4, 0.8, 0.4]
                  }}
                  transition={{
                    duration: 2.5,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: 1
                  }}
                  className="absolute bottom-6 left-6 w-3 h-3 bg-gradient-to-br from-indigo-400 to-purple-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                />
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>

        {/* AI Performance Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 }}
          className="mt-8"
        >
          <Card className="glass glow-orange shadow-xl border-orange-200/30 bg-gradient-to-r from-orange-50/50 to-yellow-50/50">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-4 md:space-y-0">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center shadow-lg">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">Document Performance Insights</h3>
                    <p className="text-sm text-slate-600">Your optimized documents have a 87% higher success rate!</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
                    <Archive className="w-4 h-4 mr-2" />
                    Export All
                  </Button>
                  <Button className="gradient-button glow-orange text-white btn-hover-lift">
                    <Brain className="w-4 h-4 mr-2" />
                    AI Analysis Report
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}