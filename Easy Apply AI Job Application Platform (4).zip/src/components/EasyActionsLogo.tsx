import React from 'react';
import { motion } from 'motion/react';

interface EasyActionsLogoProps {
  className?: string;
  showText?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export default function EasyActionsLogo({ 
  className = '', 
  showText = true, 
  size = 'md' 
}: EasyActionsLogoProps) {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-20 h-20'
  };

  const textSizeClasses = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl',
    xl: 'text-3xl'
  };

  return (
    <motion.div 
      className={`flex items-center gap-3 ${className}`}
      whileHover={{ scale: 1.05 }}
      transition={{ type: "spring", stiffness: 400, damping: 10 }}
    >
      {/* Modern geometric logo with gradient */}
      <motion.div 
        className={`relative ${sizeClasses[size]} flex-shrink-0`}
        whileHover={{ rotate: 360 }}
        transition={{ duration: 0.8, ease: "easeInOut" }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-[#ea580c] via-[#f97316] to-[#fbbf24] rounded-xl shadow-lg"></div>
        <div className="absolute inset-1 bg-white rounded-lg flex items-center justify-center">
          {/* Stylized "EA" monogram */}
          <svg
            viewBox="0 0 40 40"
            className="w-full h-full p-1.5"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ea580c" />
                <stop offset="50%" stopColor="#f97316" />
                <stop offset="100%" stopColor="#fbbf24" />
              </linearGradient>
            </defs>
            
            {/* Letter "E" */}
            <path
              d="M8 10 L8 30 L20 30 M8 10 L18 10 M8 20 L16 20"
              stroke="url(#logoGradient)"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            
            {/* Letter "A" */}
            <path
              d="M24 30 L28 15 L32 30 M26 25 L30 25"
              stroke="url(#logoGradient)"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
            
            {/* Connecting arc/swoosh */}
            <path
              d="M20 15 Q22 12 24 15"
              stroke="url(#logoGradient)"
              strokeWidth="1.5"
              strokeLinecap="round"
              fill="none"
            />
            
            {/* Small decorative dots */}
            <circle cx="12" cy="8" r="1" fill="url(#logoGradient)" />
            <circle cx="28" cy="8" r="1" fill="url(#logoGradient)" />
          </svg>
        </div>
        
        {/* Subtle glow effect */}
        <div className="absolute -inset-1 bg-gradient-to-br from-[#ea580c]/20 via-[#f97316]/20 to-[#fbbf24]/20 rounded-xl blur opacity-75"></div>
      </motion.div>

      {showText && (
        <motion.div 
          className="flex flex-col"
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <motion.span 
            className={`font-bold gradient-text ${textSizeClasses[size]} leading-tight`}
            whileHover={{ scale: 1.02 }}
          >
            Easy Actions
          </motion.span>
          <motion.span 
            className="text-xs text-muted-foreground font-medium tracking-wider"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            Your AI career co-pilot
          </motion.span>
        </motion.div>
      )}
    </motion.div>
  );
}