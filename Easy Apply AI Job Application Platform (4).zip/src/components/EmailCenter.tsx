import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { ScrollArea } from './ui/scroll-area';
import { Separator } from './ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import EasyActionsLogo from './EasyActionsLogo';
import {
  Mail,
  Send,
  Inbox,
  Archive,
  Trash2,
  Star,
  Reply,
  Forward,
  MoreVertical,
  Search,
  Filter,
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle,
  User,
  Building,
  Briefcase,
  Eye,
  EyeOff,
  ArrowLeft,
  Bell,
  Sparkles,
  Zap,
  TrendingUp,
  RefreshCw,
  Plus,
  Settings,
  Download,
  Upload
} from 'lucide-react';

interface Email {
  id: string;
  from: string;
  company: string;
  subject: string;
  preview: string;
  timestamp: string;
  read: boolean;
  starred: boolean;
  category: 'response' | 'interview' | 'rejection' | 'automated' | 'follow-up';
  jobTitle?: string;
  platform?: string;
}

interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  type: 'thank-you' | 'follow-up' | 'interview-request' | 'custom';
}

const EmailCenter: React.FC = () => {
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [activeTab, setActiveTab] = useState('inbox');
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Mock emails data
  const emails: Email[] = [
    {
      id: '1',
      from: 'Sarah Johnson',
      company: 'TechCorp',
      subject: 'Re: Frontend Developer Position - Interview Invitation',
      preview: 'Thank you for your application. We would like to invite you for an interview next Tuesday at 2 PM...',
      timestamp: '2 hours ago',
      read: false,
      starred: true,
      category: 'interview',
      jobTitle: 'Frontend Developer',
      platform: 'LinkedIn'
    },
    {
      id: '2',
      from: 'HR Department',
      company: 'StartupXYZ',
      subject: 'Application Received - React Developer',
      preview: 'We have received your application for the React Developer position. We will review your application and get back to you...',
      timestamp: '4 hours ago',
      read: true,
      starred: false,
      category: 'response',
      jobTitle: 'React Developer',
      platform: 'StepStone'
    },
    {
      id: '3',
      from: 'Michael Chen',
      company: 'InnovateLab',
      subject: 'Thank you for your interest - JavaScript Developer',
      preview: 'Thank you for applying for the JavaScript Developer position. Unfortunately, we have decided to move forward with other candidates...',
      timestamp: '1 day ago',
      read: true,
      starred: false,
      category: 'rejection',
      jobTitle: 'JavaScript Developer',
      platform: 'Indeed'
    },
    {
      id: '4',
      from: 'Easy Actions AI',
      company: 'System',
      subject: 'Application Follow-up Sent - Senior Developer Role',
      preview: 'AI has automatically sent a follow-up email for the Senior Developer position at WebSolutions. Response rate increased by 23%...',
      timestamp: '2 days ago',
      read: true,
      starred: false,
      category: 'automated',
      jobTitle: 'Senior Developer',
      platform: 'Xing'
    },
  ];

  // Email templates
  const templates: EmailTemplate[] = [
    {
      id: '1',
      name: 'Interview Thank You',
      subject: 'Thank you for the interview opportunity',
      content: 'Dear [Interviewer Name],\n\nThank you for taking the time to interview me for the [Position] role at [Company]. I enjoyed our conversation about [specific topic discussed].\n\nI am very excited about the opportunity to contribute to [Company] and look forward to hearing from you soon.\n\nBest regards,\n[Your Name]',
      type: 'thank-you'
    },
    {
      id: '2',
      name: 'Application Follow-up',
      subject: 'Following up on my application - [Position]',
      content: 'Dear Hiring Manager,\n\nI wanted to follow up on my application for the [Position] role that I submitted [timeframe]. I remain very interested in this opportunity and would appreciate any updates on the hiring process.\n\nThank you for your consideration.\n\nBest regards,\n[Your Name]',
      type: 'follow-up'
    }
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'interview': return 'bg-green-100 text-green-700';
      case 'response': return 'bg-blue-100 text-blue-700';
      case 'rejection': return 'bg-red-100 text-red-700';
      case 'automated': return 'bg-purple-100 text-purple-700';
      case 'follow-up': return 'bg-orange-100 text-orange-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'interview': return Calendar;
      case 'response': return Mail;
      case 'rejection': return AlertCircle;
      case 'automated': return Zap;
      case 'follow-up': return TrendingUp;
      default: return Mail;
    }
  };

  const getPlatformIcon = (platform?: string) => {
    switch (platform?.toLowerCase()) {
      case 'linkedin': return '💼';
      case 'stepstone': return '🪜';
      case 'indeed': return '🔍';
      case 'xing': return '🌐';
      default: return '📧';
    }
  };

  const filteredEmails = emails.filter(email => {
    const matchesSearch = email.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         email.from.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         email.company.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterCategory === 'all' || email.category === filterCategory;
    
    if (activeTab === 'starred') return email.starred && matchesSearch && matchesFilter;
    if (activeTab === 'unread') return !email.read && matchesSearch && matchesFilter;
    
    return matchesSearch && matchesFilter;
  });

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsRefreshing(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 p-4 md:p-6 pt-0">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Enhanced Header with Logo and Robot */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8 space-y-4 lg:space-y-0"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <EasyActionsLogo size="lg" showText={true} className="hidden sm:flex" />
            
            {/* Mobile: Logo stacked */}
            <div className="flex flex-col sm:hidden space-y-2">
              <EasyActionsLogo size="md" showText={true} />
            </div>
            
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold gradient-text drop-shadow-sm leading-tight">
                <span className="block sm:inline">Email</span>
                <span className="block sm:inline"> </span>
                <span className="block sm:inline">Center ✉️</span>
              </h1>
              <p className="text-slate-600 mt-2 text-sm sm:text-base leading-relaxed">
                AI-powered email management and automated responses
              </p>
            </div>
          </div>
          
          {/* AI Assistant Robot with Enhanced Speech Bubble */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative self-center lg:self-auto"
          >
            <motion.div
              animate={{
                y: [0, -10, 0],
                rotate: [0, 3, -3, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="relative"
            >
              <ImageWithFallback
                src={robotImage}
                alt="AI Assistant Robot"
                className="w-16 h-16 md:w-20 md:h-20 rounded-full shadow-lg border-2 border-white/80 robot-bounce"
              />
              
              {/* Dynamic Speech bubble */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5 }}
                className="absolute -top-16 -left-24 md:-left-36 bg-white rounded-2xl p-3 shadow-lg border border-orange-200/30 max-w-52"
              >
                <p className="text-xs font-medium text-slate-700">
                  You have {emails.filter(e => !e.read).length} unread emails! 
                  I've automated {emails.filter(e => e.category === 'automated').length} responses today! 🚀
                </p>
                <div className="absolute bottom-0 left-10 w-3 h-3 bg-white transform rotate-45 translate-y-1/2 border-r border-b border-orange-200/30" />
              </motion.div>
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Enhanced Email Statistics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-8"
        >
          {[
            { 
              label: 'Total Emails', 
              value: emails.length, 
              icon: Mail, 
              color: 'from-[#ea580c] to-[#f97316]',
              bgColor: 'bg-orange-50',
              description: 'All time'
            },
            { 
              label: 'Interview Invites', 
              value: emails.filter(e => e.category === 'interview').length, 
              icon: Calendar, 
              color: 'from-[#f97316] to-[#fbbf24]',
              bgColor: 'bg-amber-50',
              description: 'Pending'
            },
            { 
              label: 'Response Rate', 
              value: '67%', 
              icon: TrendingUp, 
              color: 'from-[#fbbf24] to-[#fde047]',
              bgColor: 'bg-yellow-50',
              description: 'Last 30 days'
            },
            { 
              label: 'AI Automated', 
              value: emails.filter(e => e.category === 'automated').length, 
              icon: Zap, 
              color: 'from-[#fde047] to-[#facc15]',
              bgColor: 'bg-lime-50',
              description: 'This week'
            },
          ].map((stat, index) => {
            const Icon = stat.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
                whileHover={{ scale: 1.02, y: -2 }}
              >
                <Card className={`glass glow-orange shadow-lg hover:shadow-xl transition-all duration-300 border-orange-200/30 ${stat.bgColor}/30`}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-slate-600 mb-1 font-medium">{stat.label}</p>
                        <p className="text-2xl md:text-3xl font-bold gradient-text">{stat.value}</p>
                        <p className="text-xs text-slate-500 mt-1">{stat.description}</p>
                      </div>
                      <div className={`w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-r ${stat.color} flex items-center justify-center shadow-lg`}>
                        <Icon className="w-6 h-6 md:w-7 md:h-7 text-white" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Action Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6"
        >
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
            <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
              <Filter className="w-4 h-4 mr-2" />
              Filter
            </Button>
            <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
              <Archive className="w-4 h-4 mr-2" />
              Archive
            </Button>
          </div>
          
          <div className="flex gap-2">
            <Button 
              onClick={handleRefresh}
              disabled={isRefreshing}
              variant="outline" 
              size="sm" 
              className="border-orange-200 hover:bg-orange-50 btn-hover-lift"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
            <Button className="gradient-button glow-orange text-white btn-hover-lift" size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Compose
            </Button>
          </div>
        </motion.div>

        {/* Enhanced Main Email Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Enhanced Email List */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.5 }}
            className="lg:col-span-5 xl:col-span-4"
          >
            <Card className="glass glow-orange shadow-xl border-orange-200/30 h-[calc(100vh-400px)] min-h-[600px]">
              <CardHeader className="pb-4 bg-gradient-to-r from-orange-50 to-amber-50 rounded-t-lg">
                <div className="flex items-center justify-between mb-4">
                  <CardTitle className="gradient-text flex items-center text-xl">
                    <Inbox className="w-5 h-5 mr-2" />
                    Inbox
                  </CardTitle>
                  <div className="flex items-center space-x-2">
                    <Badge className="bg-orange-100 text-orange-700 border-orange-200">
                      {filteredEmails.filter(e => !e.read).length} unread
                    </Badge>
                  </div>
                </div>

                {/* Enhanced Search and Filter */}
                <div className="space-y-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <Input
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search emails..."
                      className="pl-10 bg-white/80 border-orange-200/50 focus:border-orange-400 focus:ring-orange-400"
                    />
                  </div>

                  <Tabs value={activeTab} onValueChange={setActiveTab}>
                    <TabsList className="grid grid-cols-3 w-full bg-white/60">
                      <TabsTrigger value="inbox" className="text-xs">All ({emails.length})</TabsTrigger>
                      <TabsTrigger value="unread" className="text-xs">Unread ({emails.filter(e => !e.read).length})</TabsTrigger>
                      <TabsTrigger value="starred" className="text-xs">Starred ({emails.filter(e => e.starred).length})</TabsTrigger>
                    </TabsList>
                  </Tabs>

                  {/* Category Filters */}
                  <div className="flex flex-wrap gap-1">
                    {['all', 'interview', 'response', 'rejection', 'automated'].map((category) => (
                      <Button
                        key={category}
                        onClick={() => setFilterCategory(category)}
                        variant={filterCategory === category ? "default" : "outline"}
                        size="sm"
                        className={`text-xs ${filterCategory === category ? 'bg-orange-500 text-white' : 'hover:bg-orange-50 border-orange-200'}`}
                      >
                        {category === 'all' ? 'All' : category.charAt(0).toUpperCase() + category.slice(1)}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardHeader>

              <CardContent className="p-0 flex-1">
                <ScrollArea className="h-[calc(100%-220px)]">
                  <div className="space-y-2 p-4">
                    {filteredEmails.map((email, index) => {
                      const CategoryIcon = getCategoryIcon(email.category);
                      return (
                        <motion.div
                          key={email.id}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.6 + index * 0.1 }}
                          onClick={() => setSelectedEmail(email)}
                          className={`p-4 rounded-xl border transition-all duration-200 cursor-pointer group hover:shadow-md ${
                            selectedEmail?.id === email.id
                              ? 'bg-orange-100 border-orange-300 shadow-lg'
                              : email.read
                              ? 'bg-white/60 border-slate-200 hover:bg-white/80'
                              : 'bg-white border-orange-200 hover:bg-orange-50/80 shadow-sm'
                          }`}
                        >
                          <div className="flex items-start space-x-3">
                            <div className={`w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-yellow-400 flex items-center justify-center flex-shrink-0 shadow-lg ${!email.read ? 'ring-2 ring-orange-300' : ''}`}>
                              <User className="w-5 h-5 text-white" />
                            </div>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-2">
                                <div className="flex items-center space-x-2">
                                  <h4 className={`font-semibold truncate ${!email.read ? 'text-slate-900' : 'text-slate-700'} group-hover:text-orange-600 transition-colors`}>
                                    {email.from}
                                  </h4>
                                  {email.starred && <Star className="w-4 h-4 text-yellow-500 fill-current" />}
                                </div>
                                <div className="flex items-center space-x-2">
                                  <span className="text-sm text-orange-600">{getPlatformIcon(email.platform)}</span>
                                  <Badge className={`text-xs ${getCategoryColor(email.category)} border-0`}>
                                    <CategoryIcon className="w-3 h-3 mr-1" />
                                    {email.category}
                                  </Badge>
                                </div>
                              </div>
                              
                              <p className={`text-sm mb-2 truncate ${!email.read ? 'font-semibold text-slate-800' : 'text-slate-600'}`}>
                                {email.subject}
                              </p>
                              
                              <div className="flex items-center justify-between">
                                <p className="text-xs text-slate-500 truncate flex-1 mr-2 leading-relaxed">
                                  {email.preview}
                                </p>
                                <span className="text-xs text-slate-400 flex-shrink-0 font-medium">{email.timestamp}</span>
                              </div>
                              
                              {email.jobTitle && (
                                <div className="flex items-center mt-2 pt-2 border-t border-slate-100">
                                  <Briefcase className="w-3 h-3 text-orange-500 mr-1" />
                                  <span className="text-xs text-orange-600 font-medium">{email.jobTitle} at {email.company}</span>
                                </div>
                              )}
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </motion.div>

          {/* Enhanced Email Content / Templates */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="lg:col-span-7 xl:col-span-8"
          >
            <Tabs value={selectedEmail ? "email" : "templates"} className="h-full">
              <div className="flex items-center justify-between mb-4">
                <TabsList className="bg-white/60">
                  <TabsTrigger value="email" disabled={!selectedEmail}>Email Content</TabsTrigger>
                  <TabsTrigger value="templates">AI Templates</TabsTrigger>
                </TabsList>
                
                {selectedEmail && (
                  <div className="flex items-center space-x-2">
                    <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
                      <Reply className="w-4 h-4 mr-2" />
                      Reply
                    </Button>
                    <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
                      <Forward className="w-4 h-4 mr-2" />
                      Forward
                    </Button>
                  </div>
                )}
              </div>

              <TabsContent value="email" className="m-0">
                {selectedEmail ? (
                  <Card className="glass glow-orange shadow-xl border-orange-200/30 h-[calc(100vh-400px)] min-h-[600px]">
                    <CardHeader className="pb-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-t-lg">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4">
                          <div className="w-14 h-14 rounded-full bg-gradient-to-br from-orange-400 to-yellow-400 flex items-center justify-center shadow-lg">
                            <User className="w-7 h-7 text-white" />
                          </div>
                          <div>
                            <h3 className="text-lg font-bold text-slate-900">{selectedEmail.from}</h3>
                            <p className="text-sm text-slate-600">{selectedEmail.company}</p>
                            <div className="flex items-center space-x-2 mt-2">
                              <Badge className={getCategoryColor(selectedEmail.category)}>
                                {selectedEmail.category}
                              </Badge>
                              <span className="text-xs text-slate-500">{selectedEmail.timestamp}</span>
                            </div>
                          </div>
                        </div>
                        <Button variant="ghost" size="icon" className="hover:bg-white/60">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardHeader>

                    <CardContent className="p-6">
                      <div className="mb-6">
                        <h2 className="text-xl font-semibold text-slate-900 mb-2">{selectedEmail.subject}</h2>
                        <Separator className="bg-orange-200" />
                      </div>

                      <ScrollArea className="h-[calc(100%-180px)]">
                        <div className="prose prose-sm max-w-none">
                          <p className="text-slate-700 leading-relaxed mb-6">
                            {selectedEmail.preview}
                          </p>
                          
                          {/* Enhanced Mock email content based on category */}
                          {selectedEmail.category === 'interview' && (
                            <motion.div
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="mt-6 p-6 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-xl shadow-lg"
                            >
                              <h4 className="font-semibold text-green-800 mb-3 flex items-center">
                                <Calendar className="w-5 h-5 mr-2" />
                                Interview Details
                              </h4>
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                                <div className="space-y-2">
                                  <p className="text-green-700"><strong>Date:</strong> Tuesday, December 19, 2024</p>
                                  <p className="text-green-700"><strong>Time:</strong> 2:00 PM - 3:00 PM</p>
                                </div>
                                <div className="space-y-2">
                                  <p className="text-green-700"><strong>Location:</strong> Virtual (Zoom)</p>
                                  <p className="text-green-700"><strong>Interviewer:</strong> Sarah Johnson, Technical Lead</p>
                                </div>
                              </div>
                            </motion.div>
                          )}

                          {selectedEmail.category === 'automated' && (
                            <motion.div
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="mt-6 p-6 bg-gradient-to-r from-purple-50 to-indigo-50 border border-purple-200 rounded-xl shadow-lg"
                            >
                              <h4 className="font-semibold text-purple-800 mb-3 flex items-center">
                                <Zap className="w-5 h-5 mr-2" />
                                AI Action Summary
                              </h4>
                              <div className="space-y-2 text-sm text-purple-700">
                                <p>• Follow-up email sent automatically after 5 days</p>
                                <p>• Personalized content based on job requirements</p>
                                <p>• Optimal sending time: Tuesday 9:30 AM</p>
                                <p>• Response rate for similar follow-ups: 23%</p>
                              </div>
                            </motion.div>
                          )}
                        </div>
                      </ScrollArea>

                      {/* Enhanced Quick Reply Section */}
                      {selectedEmail.category === 'interview' && (
                        <div className="mt-6 pt-4 border-t border-orange-200">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <Button className="gradient-button text-white btn-hover-lift">
                              <CheckCircle className="w-4 h-4 mr-2" />
                              Confirm Interview
                            </Button>
                            <Button variant="outline" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
                              <Calendar className="w-4 h-4 mr-2" />
                              Request Reschedule
                            </Button>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ) : (
                  <Card className="glass glow-orange shadow-xl border-orange-200/30 h-[calc(100vh-400px)] min-h-[600px] flex items-center justify-center">
                    <CardContent className="text-center">
                      <motion.div
                        animate={{ scale: [1, 1.05, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        <Mail className="w-20 h-20 text-orange-300 mx-auto mb-4" />
                      </motion.div>
                      <h3 className="text-xl font-semibold text-slate-600 mb-2">Select an Email</h3>
                      <p className="text-slate-500">Choose an email from the list to view its content</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>

              <TabsContent value="templates" className="m-0">
                <Card className="glass glow-orange shadow-xl border-orange-200/30 h-[calc(100vh-400px)] min-h-[600px]">
                  <CardHeader className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-t-lg">
                    <CardTitle className="gradient-text flex items-center text-xl">
                      <Sparkles className="w-5 h-5 mr-2" />
                      AI Email Templates
                    </CardTitle>
                    <CardDescription>Pre-built, AI-optimized templates for common email scenarios</CardDescription>
                  </CardHeader>
                  <CardContent className="p-6">
                    <ScrollArea className="h-[calc(100%-120px)]">
                      <div className="space-y-6">
                        {templates.map((template, index) => (
                          <motion.div
                            key={template.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: 0.7 + index * 0.1 }}
                            className="p-6 rounded-xl bg-gradient-to-r from-white/80 to-purple-50/50 border border-orange-100 shadow-lg hover:shadow-xl transition-all duration-200 group"
                          >
                            <div className="flex items-start justify-between mb-4">
                              <div>
                                <h4 className="font-semibold text-slate-800 group-hover:text-orange-600 transition-colors text-lg">
                                  {template.name}
                                </h4>
                                <p className="text-sm text-slate-600 mt-1">{template.subject}</p>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Badge className="bg-orange-100 text-orange-700 border-orange-200">{template.type}</Badge>
                                <Button variant="ghost" size="sm" className="hover:bg-orange-50">
                                  <Eye className="w-4 h-4" />
                                </Button>
                              </div>
                            </div>
                            <p className="text-sm text-slate-600 mb-4 leading-relaxed">
                              {template.content.slice(0, 200)}...
                            </p>
                            <div className="flex items-center space-x-3">
                              <Button size="sm" className="gradient-button text-white btn-hover-lift">
                                <Download className="w-4 h-4 mr-2" />
                                Use Template
                              </Button>
                              <Button variant="outline" size="sm" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
                                <Settings className="w-4 h-4 mr-2" />
                                Customize
                              </Button>
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </ScrollArea>

                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 1 }}
                      className="mt-6 p-6 rounded-xl bg-gradient-to-r from-orange-50 to-yellow-50 border border-orange-200 shadow-lg"
                    >
                      <div className="flex items-center mb-4">
                        <motion.div
                          animate={{
                            rotate: [0, 10, -10, 0],
                            scale: [1, 1.1, 1]
                          }}
                          transition={{
                            duration: 3,
                            repeat: Infinity
                          }}
                        >
                          <ImageWithFallback
                            src={robotImage}
                            alt="AI Assistant"
                            className="w-12 h-12 rounded-full mr-4 shadow-lg robot-bounce"
                          />
                        </motion.div>
                        <div>
                          <h4 className="font-semibold text-orange-800 text-lg">AI Email Assistant</h4>
                          <p className="text-sm text-orange-600">Need a custom email? Let AI craft the perfect message!</p>
                        </div>
                      </div>
                      <Button className="gradient-button text-white btn-hover-lift">
                        <Zap className="w-4 h-4 mr-2" />
                        Generate Custom Email
                      </Button>
                    </motion.div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </motion.div>
        </div>

        {/* AI Performance Insights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 }}
          className="mt-8"
        >
          <Card className="glass glow-orange shadow-xl border-orange-200/30 bg-gradient-to-r from-orange-50/50 to-yellow-50/50">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-4 md:space-y-0">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center shadow-lg">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">Email Performance Insights</h3>
                    <p className="text-sm text-slate-600">AI automation has increased your response rate by 67%!</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="border-orange-200 hover:bg-orange-50 btn-hover-lift">
                    <Archive className="w-4 h-4 mr-2" />
                    Export Emails
                  </Button>
                  <Button className="gradient-button glow-orange text-white btn-hover-lift">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    View Analytics
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default EmailCenter;