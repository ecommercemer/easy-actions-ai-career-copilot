import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ScrollArea } from './ui/scroll-area';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import {
  HelpCircle,
  X,
  Send,
  MessageCircle,
  PlayCircle,
  FileText,
  Upload,
  Target,
  Mail,
  Settings,
  Sparkles,
  Languages,
  Video,
  ChevronRight,
  Minimize2,
  Maximize2,
  Volume2,
  VolumeX,
  RotateCcw,
  Download,
  Share,
  Heart,
  ThumbsUp,
  Clock,
  Globe,
  Mic,
  MicOff,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Eye,
  ArrowRight,
  CheckCircle,
  FileUp,
  Search,
  Zap
} from 'lucide-react';

interface ChatMessage {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
  language?: string;
}

interface Tutorial {
  id: string;
  title: string;
  description: string;
  duration: string;
  thumbnail: string;
  category: 'getting-started' | 'documents' | 'applications' | 'advanced';
  videoUrl: string;
}

const FloatingHelp: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [activeTab, setActiveTab] = useState('chat');
  const [selectedHelpTopic, setSelectedHelpTopic] = useState<string | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      text: 'Hello! I\'m Jobby, your AI career co-pilot! 🚀 I can help you in any language with resume uploads, job applications, cover letters, and navigating the entire Easy Actions platform. What would you like to know?',
      isBot: true,
      timestamp: new Date(),
      language: 'en'
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [selectedTutorial, setSelectedTutorial] = useState<Tutorial | null>(null);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [currentTutorialStep, setCurrentTutorialStep] = useState(0);
  const [isPlayingVisualTutorial, setIsPlayingVisualTutorial] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const recognitionRef = useRef<any>(null);
  const modalRef = useRef<HTMLDivElement>(null);

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'de', name: 'Deutsch', flag: '🇩🇪' },
    { code: 'es', name: 'Español', flag: '🇪🇸' },
    { code: 'fr', name: 'Français', flag: '🇫🇷' },
    { code: 'it', name: 'Italiano', flag: '🇮🇹' },
    { code: 'pt', name: 'Português', flag: '🇵🇹' },
    { code: 'zh', name: '中文', flag: '🇨🇳' },
    { code: 'ja', name: '日本語', flag: '🇯🇵' },
    { code: 'ko', name: '한국어', flag: '🇰🇷' },
    { code: 'ar', name: 'العربية', flag: '🇸🇦' }
  ];

  const tutorials: Tutorial[] = [
    {
      id: '1',
      title: 'Getting Started with Easy Actions',
      description: 'Complete overview of the platform and how to set up your account',
      duration: '4:30',
      thumbnail: '🚀',
      category: 'getting-started',
      videoUrl: '/tutorials/getting-started.mp4'
    },
    {
      id: '2',
      title: 'How to Upload Your Resume',
      description: 'Step-by-step guide to uploading and optimizing your resume with AI',
      duration: '3:45',
      thumbnail: '📄',
      category: 'documents',
      videoUrl: '/tutorials/resume-upload.mp4'
    },
    {
      id: '3',
      title: 'AI Cover Letter Generation',
      description: 'Learn how AI automatically creates personalized cover letters for each job',
      duration: '5:20',
      thumbnail: '✉️',
      category: 'applications',
      videoUrl: '/tutorials/cover-letter-generation.mp4'
    },
    {
      id: '4',
      title: 'Complete Application Process',
      description: 'From resume upload to automatic job applications - the full workflow',
      duration: '7:15',
      thumbnail: '🎯',
      category: 'applications',
      videoUrl: '/tutorials/complete-workflow.mp4'
    },
    {
      id: '5',
      title: 'AI Job Matching & Filtering',
      description: 'Understanding how AI finds and filters the perfect job matches',
      duration: '4:50',
      thumbnail: '🤖',
      category: 'applications',
      videoUrl: '/tutorials/job-matching.mp4'
    },
    {
      id: '6',
      title: 'Managing Email Responses',
      description: 'How to handle interview invitations and employer communications',
      duration: '3:30',
      thumbnail: '📧',
      category: 'applications',
      videoUrl: '/tutorials/email-management.mp4'
    },
    {
      id: '7',
      title: 'Advanced AI Settings',
      description: 'Customize AI behavior, filters, and automation preferences',
      duration: '6:10',
      thumbnail: '⚙️',
      category: 'advanced',
      videoUrl: '/tutorials/ai-settings.mp4'
    },
    {
      id: '8',
      title: 'Multi-Platform Job Search',
      description: 'How Easy Actions works across LinkedIn, Xing, StepStone, and Indeed',
      duration: '5:45',
      thumbnail: '🌐',
      category: 'advanced',
      videoUrl: '/tutorials/multi-platform.mp4'
    }
  ];

  // Visual Tutorial Steps
  const visualTutorialSteps = [
    {
      id: 1,
      title: "Welcome to Easy Actions",
      description: "Your AI career co-pilot for automated job applications",
      image: "🏠",
      content: "Easy Actions automates your entire job search process with AI-powered resume optimization, job matching, and application submission across LinkedIn, Xing, StepStone, and Indeed.",
      duration: 3000
    },
    {
      id: 2,
      title: "Step 1: Upload Your Resume",
      description: "Start by uploading your resume for AI analysis",
      image: "📄",
      content: "Click 'Upload Resume & Start AI' on the dashboard. Our AI will analyze your skills, experience, and optimize your resume for better job matching.",
      duration: 4000
    },
    {
      id: 3,
      title: "Step 2: AI Analysis",
      description: "Our AI analyzes your resume and skills",
      image: "🤖",
      content: "The AI examines your background, identifies key skills, and creates a profile optimized for job matching across multiple platforms.",
      duration: 3500
    },
    {
      id: 4,
      title: "Step 3: Job Matching",
      description: "AI finds relevant job opportunities",
      image: "🎯",
      content: "Our intelligent system searches LinkedIn, Xing, StepStone, and Indeed to find jobs that match your profile and preferences.",
      duration: 4000
    },
    {
      id: 5,
      title: "Step 4: Cover Letter Generation",
      description: "AI creates personalized cover letters",
      image: "✉️",
      content: "For each job, AI generates a custom cover letter that highlights relevant experience and increases your response rate by up to 40%.",
      duration: 4500
    },
    {
      id: 6,
      title: "Step 5: Automatic Applications",
      description: "AI submits applications on your behalf",
      image: "⚡",
      content: "The system automatically fills out application forms and submits your applications to matched job opportunities.",
      duration: 3500
    },
    {
      id: 7,
      title: "Step 6: Email Management",
      description: "Track and manage employer responses",
      image: "📧",
      content: "Monitor interview invitations, employer communications, and track your application progress in one centralized dashboard.",
      duration: 4000
    },
    {
      id: 8,
      title: "Success!",
      description: "Your automated job search is now active",
      image: "🎉",
      content: "Congratulations! Easy Actions is now working 24/7 to find and apply to relevant job opportunities. Check your dashboard to monitor progress.",
      duration: 3000
    }
  ];

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const getAIResponse = (userMessage: string, language: string): string => {
    const responses = {
      en: {
        greeting: "Hello! I'm Jobby, your AI career co-pilot! 🚀 I can help you with resume uploads, job applications, cover letters, and navigating the entire Easy Actions platform. What would you like to know?",
        upload: "To upload your resume: 1) Click 'Upload Resume & Start AI' on the dashboard 2) Our AI analyzes your skills and experience 3) We optimize it for better job matching 4) Start getting applications sent automatically! Want to see a video tutorial?",
        coverLetter: "Our AI automatically generates personalized cover letters for each job application! It analyzes the job description, your resume, and creates compelling, targeted cover letters that increase your response rate by up to 40%. Check out our tutorial on cover letter generation!",
        applications: "Easy Actions automates your entire job search: 1) AI finds matching jobs across LinkedIn, Xing, StepStone & Indeed 2) Creates custom cover letters 3) Fills application forms 4) Sends applications 5) Manages follow-ups. You can track everything in the Job Tracker!",
        workflow: "Here's the complete workflow: Upload Resume → AI Analysis → Job Matching → Cover Letter Generation → Automatic Applications → Email Management → Interview Scheduling. Watch our 'Complete Application Process' tutorial for a full walkthrough!",
        platforms: "Easy Actions works across 4 major platforms: LinkedIn (professional networking), Xing (German market), StepStone (European jobs), and Indeed (global opportunities). Our AI applies to jobs on all platforms automatically!",
        help: "I can help you with: ✅ Resume upload & optimization ✅ Understanding AI job matching ✅ Cover letter generation ✅ Application tracking ✅ Email management ✅ Platform integrations ✅ Settings & automation. What interests you most?",
        settings: "In Settings, customize: 🤖 AI behavior & timing ⚙️ Job preferences & filters 📧 Notification settings 🔐 Privacy & security 📊 Performance analytics. Want help with any specific setting?",
        tutorial: "I have 8 comprehensive video tutorials covering: Getting Started, Resume Upload, Cover Letter Generation, Complete Workflow, Job Matching, Email Management, AI Settings, and Multi-Platform Search. Which one would you like to watch?",
        default: "I'm here to help with Easy Actions! Ask me about: resume uploads, job applications, cover letters, AI automation, platform integrations, email management, or any feature. You can also watch our video tutorials for step-by-step guides!"
      },
      de: {
        greeting: "Hallo! Ich bin Jobby, Ihr KI-Karriere-Copilot! 🚀 Ich kann Ihnen bei Lebenslauf-Uploads, Bewerbungen, Anschreiben und der Navigation durch die gesamte Easy Actions-Plattform helfen. Was möchten Sie wissen?",
        upload: "Lebenslauf hochladen: 1) Klicken Sie auf 'Lebenslauf hochladen & KI starten' 2) Unsere KI analysiert Ihre Fähigkeiten 3) Wir optimieren für besseres Job-Matching 4) Automatische Bewerbungen starten! Tutorial ansehen?",
        coverLetter: "Unsere KI erstellt automatisch personalisierte Anschreiben für jede Bewerbung! Sie analysiert die Stellenbeschreibung, Ihren Lebenslauf und erstellt überzeugende, zielgerichtete Anschreiben, die Ihre Antwortrate um bis zu 40% erhöhen.",
        applications: "Easy Actions automatisiert Ihre gesamte Jobsuche: 1) KI findet passende Jobs auf LinkedIn, Xing, StepStone & Indeed 2) Erstellt individuelle Anschreiben 3) Füllt Bewerbungsformulare aus 4) Sendet Bewerbungen 5) Verwaltet Follow-ups.",
        workflow: "Der komplette Workflow: Lebenslauf hochladen → KI-Analyse → Job-Matching → Anschreiben-Generierung → Automatische Bewerbungen → E-Mail-Management → Terminplanung. Tutorial 'Kompletter Bewerbungsprozess' ansehen!",
        platforms: "Easy Actions funktioniert auf 4 Hauptplattformen: LinkedIn (professionelles Networking), Xing (deutscher Markt), StepStone (europäische Jobs) und Indeed (globale Möglichkeiten).",
        help: "Ich kann helfen bei: ✅ Lebenslauf-Upload & Optimierung ✅ KI-Job-Matching verstehen ✅ Anschreiben-Generierung ✅ Bewerbungs-Tracking ✅ E-Mail-Management ✅ Plattform-Integrationen ✅ Einstellungen & Automatisierung.",
        settings: "In den Einstellungen anpassen: 🤖 KI-Verhalten & Timing ⚙️ Job-Präferenzen & Filter 📧 Benachrichtigungseinstellungen 🔐 Datenschutz & Sicherheit 📊 Leistungsanalysen.",
        tutorial: "Ich habe 8 umfassende Video-Tutorials: Erste Schritte, Lebenslauf-Upload, Anschreiben-Generierung, Kompletter Workflow, Job-Matching, E-Mail-Management, KI-Einstellungen und Multi-Plattform-Suche.",
        default: "Ich bin hier, um bei Easy Actions zu helfen! Fragen Sie nach: Lebenslauf-Uploads, Bewerbungen, Anschreiben, KI-Automatisierung, Plattform-Integrationen, E-Mail-Management oder jeder Funktion!"
      },
      es: {
        greeting: "¡Hola! Soy Jobby, tu copiloto de carrera con IA! 🚀 Puedo ayudarte con subidas de CV, solicitudes de empleo, cartas de presentación y navegar por toda la plataforma Easy Actions. ¿Qué te gustaría saber?",
        upload: "Para subir tu CV: 1) Haz clic en 'Subir CV e Iniciar IA' en el panel 2) Nuestra IA analiza tus habilidades 3) Lo optimizamos para mejor coincidencia 4) ¡Comienzan las aplicaciones automáticas! ¿Ver tutorial?",
        coverLetter: "¡Nuestra IA genera automáticamente cartas de presentación personalizadas para cada solicitud! Analiza la descripción del trabajo, tu CV y crea cartas convincentes que aumentan tu tasa de respuesta hasta un 40%.",
        applications: "Easy Actions automatiza toda tu búsqueda: 1) IA encuentra trabajos en LinkedIn, Xing, StepStone e Indeed 2) Crea cartas personalizadas 3) Llena formularios 4) Envía aplicaciones 5) Gestiona seguimientos.",
        workflow: "Flujo completo: Subir CV → Análisis IA → Coincidencia de Trabajos → Generación de Carta → Aplicaciones Automáticas → Gestión de Email → Programación de Entrevistas. ¡Ve nuestro tutorial 'Proceso Completo'!",
        platforms: "Easy Actions funciona en 4 plataformas principales: LinkedIn (networking profesional), Xing (mercado alemán), StepStone (trabajos europeos) e Indeed (oportunidades globales).",
        help: "Puedo ayudar con: ✅ Subida y optimización de CV ✅ Entender coincidencia IA ✅ Generación de cartas ✅ Seguimiento de aplicaciones ✅ Gestión de email ✅ Integraciones de plataforma ✅ Configuraciones y automatización.",
        settings: "En Configuraciones, personaliza: 🤖 Comportamiento y timing de IA ⚙️ Preferencias y filtros de trabajo 📧 Configuraciones de notificación 🔐 Privacidad y seguridad 📊 Análisis de rendimiento.",
        tutorial: "Tengo 8 tutoriales completos: Primeros Pasos, Subida de CV, Generación de Cartas, Flujo Completo, Coincidencia de Trabajos, Gestión de Email, Configuraciones IA y Búsqueda Multi-Plataforma.",
        default: "¡Estoy aquí para ayudar con Easy Actions! Pregúntame sobre: subidas de CV, solicitudes, cartas de presentación, automatización IA, integraciones de plataforma, gestión de email o cualquier función!"
      },
      fr: {
        greeting: "Bonjour ! Je suis Jobby, votre copilote de carrière IA ! 🚀 Je peux vous aider avec les téléchargements de CV, les candidatures, les lettres de motivation et naviguer sur toute la plateforme Easy Actions. Que voulez-vous savoir ?",
        upload: "Pour télécharger votre CV : 1) Cliquez sur 'Télécharger CV et Démarrer IA' 2) Notre IA analyse vos compétences 3) Nous l'optimisons pour un meilleur matching 4) Les candidatures automatiques commencent ! Voir le tutoriel ?",
        coverLetter: "Notre IA génère automatiquement des lettres de motivation personnalisées pour chaque candidature ! Elle analyse la description du poste, votre CV et crée des lettres convaincantes qui augmentent votre taux de réponse jusqu'à 40%.",
        applications: "Easy Actions automatise toute votre recherche : 1) L'IA trouve des emplois sur LinkedIn, Xing, StepStone et Indeed 2) Crée des lettres personnalisées 3) Remplit les formulaires 4) Envoie les candidatures 5) Gère les suivis.",
        workflow: "Flux complet : Télécharger CV → Analyse IA → Matching d'Emplois → Génération de Lettre → Candidatures Automatiques → Gestion Email → Planification d'Entretiens. Regardez notre tutoriel 'Processus Complet' !",
        platforms: "Easy Actions fonctionne sur 4 plateformes principales : LinkedIn (réseau professionnel), Xing (marché allemand), StepStone (emplois européens) et Indeed (opportunités mondiales).",
        help: "Je peux aider avec : ✅ Téléchargement et optimisation CV ✅ Comprendre le matching IA ✅ Génération de lettres ✅ Suivi des candidatures ✅ Gestion email ✅ Intégrations plateforme ✅ Paramètres et automatisation.",
        settings: "Dans Paramètres, personnalisez : 🤖 Comportement et timing IA ⚙️ Préférences et filtres d'emploi 📧 Paramètres de notification 🔐 Confidentialité et sécurité 📊 Analyses de performance.",
        tutorial: "J'ai 8 tutoriels complets : Démarrage, Téléchargement CV, Génération de Lettres, Flux Complet, Matching d'Emplois, Gestion Email, Paramètres IA et Recherche Multi-Plateforme.",
        default: "Je suis là pour aider avec Easy Actions ! Demandez-moi sur : téléchargements CV, candidatures, lettres de motivation, automatisation IA, intégrations plateforme, gestion email ou toute fonction !"
      }
    };

    const langResponses = responses[language as keyof typeof responses] || responses.en;
    const message = userMessage.toLowerCase();

    if (message.includes('hello') || message.includes('hi') || message.includes('hola') || message.includes('bonjour') || message.includes('hallo') || message.includes('start') || message.includes('begin')) {
      return langResponses.greeting;
    } else if (message.includes('upload') || message.includes('resume') || message.includes('cv') || message.includes('lebenslauf') || message.includes('currículum')) {
      return langResponses.upload;
    } else if (message.includes('cover letter') || message.includes('anschreiben') || message.includes('carta') || message.includes('lettre') || message.includes('letter')) {
      return langResponses.coverLetter;
    } else if (message.includes('application') || message.includes('job') || message.includes('bewerbung') || message.includes('trabajo') || message.includes('emploi') || message.includes('apply')) {
      return langResponses.applications;
    } else if (message.includes('workflow') || message.includes('process') || message.includes('step') || message.includes('how') || message.includes('complete')) {
      return langResponses.workflow;
    } else if (message.includes('platform') || message.includes('linkedin') || message.includes('xing') || message.includes('stepstone') || message.includes('indeed')) {
      return langResponses.platforms;
    } else if (message.includes('help') || message.includes('hilfe') || message.includes('ayuda') || message.includes('aide') || message.includes('support')) {
      return langResponses.help;
    } else if (message.includes('setting') || message.includes('einstellung') || message.includes('configuración') || message.includes('paramètre') || message.includes('config')) {
      return langResponses.settings;
    } else if (message.includes('tutorial') || message.includes('video') || message.includes('guide') || message.includes('learn') || message.includes('watch')) {
      return langResponses.tutorial;
    } else {
      return langResponses.default;
    }
  };

  // Speech Recognition Setup
  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = false;
      recognitionRef.current.lang = selectedLanguage === 'en' ? 'en-US' : 
                                   selectedLanguage === 'de' ? 'de-DE' :
                                   selectedLanguage === 'es' ? 'es-ES' :
                                   selectedLanguage === 'fr' ? 'fr-FR' :
                                   selectedLanguage === 'it' ? 'it-IT' :
                                   selectedLanguage === 'pt' ? 'pt-PT' :
                                   selectedLanguage === 'zh' ? 'zh-CN' :
                                   selectedLanguage === 'ja' ? 'ja-JP' :
                                   selectedLanguage === 'ko' ? 'ko-KR' :
                                   selectedLanguage === 'ar' ? 'ar-SA' : 'en-US';

      recognitionRef.current.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsListening(false);
      };

      recognitionRef.current.onerror = () => {
        setIsListening(false);
      };

      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, [selectedLanguage]);

  // Speech Recognition Handler
  const handleVoiceInput = () => {
    if (!recognitionRef.current) return;

    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      recognitionRef.current.start();
      setIsListening(true);
    }
  };

  // Visual Tutorial Handler
  const startVisualTutorial = () => {
    setCurrentTutorialStep(0);
    setIsPlayingVisualTutorial(true);
    setActiveTab('visual-tutorial');
  };

  // Auto-advance visual tutorial
  useEffect(() => {
    if (isPlayingVisualTutorial && currentTutorialStep < visualTutorialSteps.length - 1) {
      const timer = setTimeout(() => {
        setCurrentTutorialStep(prev => prev + 1);
      }, visualTutorialSteps[currentTutorialStep].duration);

      return () => clearTimeout(timer);
    } else if (currentTutorialStep === visualTutorialSteps.length - 1 && isPlayingVisualTutorial) {
      // End of tutorial
      setTimeout(() => {
        setIsPlayingVisualTutorial(false);
        setActiveTab('chat');
      }, visualTutorialSteps[currentTutorialStep].duration);
    }
  }, [currentTutorialStep, isPlayingVisualTutorial]);

  // Tooltip timeout
  useEffect(() => {
    if (!isOpen) {
      const timer = setTimeout(() => {
        setShowTooltip(true);
      }, 2000);

      const hideTimer = setTimeout(() => {
        setShowTooltip(false);
      }, 5000);

      return () => {
        clearTimeout(timer);
        clearTimeout(hideTimer);
      };
    } else {
      setShowTooltip(false);
    }
  }, [isOpen]);

  // Handle click outside modal to close
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (modalRef.current && !modalRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscapeKey);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, [isOpen]);

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: inputText,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate AI response delay
    setTimeout(() => {
      const aiResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: getAIResponse(inputText, selectedLanguage),
        isBot: true,
        timestamp: new Date(),
        language: selectedLanguage
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleTutorialSelect = (tutorial: Tutorial) => {
    setSelectedTutorial(tutorial);
    setActiveTab('video');
  };

  const handleVideoControl = (action: 'play' | 'pause' | 'mute' | 'restart') => {
    if (!videoRef.current) return;

    switch (action) {
      case 'play':
        videoRef.current.play();
        setIsVideoPlaying(true);
        break;
      case 'pause':
        videoRef.current.pause();
        setIsVideoPlaying(false);
        break;
      case 'mute':
        videoRef.current.muted = !videoRef.current.muted;
        setIsMuted(!isMuted);
        break;
      case 'restart':
        videoRef.current.currentTime = 0;
        videoRef.current.play();
        setIsVideoPlaying(true);
        break;
    }
  };

  if (!isOpen) {
    return (
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-50"
      >
        {/* Tooltip */}
        <AnimatePresence>
          {showTooltip && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="absolute -top-12 md:-top-16 -left-6 md:-left-8 bg-black/80 text-white text-xs md:text-sm px-2 md:px-3 py-1.5 md:py-2 rounded-lg backdrop-blur-sm border border-white/20"
            >
              <div className="text-center">
                <p className="font-medium">AI Guide</p>
                <p className="text-xs opacity-75">Click for help!</p>
              </div>
              {/* Arrow */}
              <div className="absolute top-full left-1/2 transform -translate-x-1/2">
                <div className="w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-black/80" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          onClick={() => setIsOpen(true)}
          onMouseEnter={() => setShowTooltip(true)}
          onMouseLeave={() => setShowTooltip(false)}
          className="relative w-12 h-12 md:w-16 md:h-16 bg-gradient-to-r from-orange-500 to-yellow-500 rounded-full shadow-2xl hover:shadow-3xl transition-all duration-300 group overflow-hidden"
          whileHover={{ scale: 1.1, rotate: 10 }}
          whileTap={{ scale: 0.95 }}
        >
          {/* Pulsing ring */}
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-orange-400 to-yellow-400 opacity-30 animate-ping" />
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-orange-500 to-yellow-500 opacity-50 animate-pulse" />
          
          {/* Robot Image as main content */}
          <div className="relative z-10 flex items-center justify-center w-full h-full p-1.5 md:p-2">
            <motion.div
              animate={{ 
                y: [0, -2, 0],
                rotate: [0, 5, -5, 0]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="w-full h-full"
            >
              <ImageWithFallback
                src={robotImage}
                alt="Jobby - AI Assistant"
                className="w-full h-full rounded-full object-cover shadow-lg"
              />
            </motion.div>
          </div>

          {/* Floating help icon indicator */}
          <div className="absolute -top-1 -right-1 w-4 h-4 md:w-5 md:h-5 bg-white rounded-full flex items-center justify-center shadow-lg">
            <HelpCircle className="w-2 h-2 md:w-3 md:h-3 text-orange-500" />
          </div>
        </motion.button>
      </motion.div>
    );
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-0 md:p-4"
        >
          <motion.div
            ref={modalRef}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ 
              scale: isMinimized ? 0.3 : 1, 
              opacity: 1,
              y: isMinimized ? 300 : 0,
              x: isMinimized ? 300 : 0
            }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className={`
              bg-white rounded-none md:rounded-2xl shadow-2xl border border-orange-200/30 overflow-hidden flex flex-col
              ${isMinimized 
                ? 'w-16 h-16 cursor-pointer fixed bottom-4 right-4' 
                : 'w-full h-full md:w-[90vw] md:h-[85vh] md:max-w-6xl md:max-h-[800px]'
              }
              transition-all duration-300
            `}
            onClick={isMinimized ? () => setIsMinimized(false) : undefined}
          >
            {!isMinimized && (
              <>
                {/* Header */}
                <div className="bg-gradient-to-r from-orange-500 to-yellow-500 p-3 md:p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 md:w-10 md:h-10 rounded-full overflow-hidden shadow-lg">
                      <ImageWithFallback
                        src={robotImage}
                        alt="Jobby"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div>
                      <h3 className="text-white font-semibold text-base md:text-lg">Jobby - AI Career Co-pilot</h3>
                      <p className="text-white/80 text-xs md:text-sm">Easy Actions Help Center</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {/* Language Selector */}
                    <select 
                      value={selectedLanguage}
                      onChange={(e) => setSelectedLanguage(e.target.value)}
                      className="bg-white/20 text-white text-xs md:text-sm rounded-lg px-2 py-1 border border-white/30 focus:outline-none focus:ring-2 focus:ring-white/50"
                    >
                      {languages.map(lang => (
                        <option key={lang.code} value={lang.code} className="text-gray-900">
                          {lang.flag} {lang.name}
                        </option>
                      ))}
                    </select>
                    
                    {/* Minimize Button */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsMinimized(true)}
                      className="text-white hover:bg-white/20 p-1 md:p-2"
                    >
                      <Minimize2 className="w-4 h-4" />
                    </Button>
                    
                    {/* Close Button */}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsOpen(false)}
                      className="text-white hover:bg-white/20 p-1 md:p-2"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {/* Main Content Area - Using flex-1 to fill remaining space */}
                <div className="flex-1 overflow-hidden">
                  <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
                    {/* Tab Navigation */}
                    <TabsList className="grid w-full grid-cols-4 gap-0 rounded-none bg-orange-50 border-b border-orange-200">
                      <TabsTrigger value="chat" className="text-xs md:text-sm data-[state=active]:bg-white">
                        <MessageCircle className="w-3 h-3 md:w-4 md:h-4 mr-1" />
                        Chat
                      </TabsTrigger>
                      <TabsTrigger value="tutorials" className="text-xs md:text-sm data-[state=active]:bg-white">
                        <Video className="w-3 h-3 md:w-4 md:h-4 mr-1" />
                        Tutorials
                      </TabsTrigger>
                      <TabsTrigger value="visual-tutorial" className="text-xs md:text-sm data-[state=active]:bg-white">
                        <Eye className="w-3 h-3 md:w-4 md:h-4 mr-1" />
                        Visual
                      </TabsTrigger>
                      <TabsTrigger value="video" className="text-xs md:text-sm data-[state=active]:bg-white">
                        <PlayCircle className="w-3 h-3 md:w-4 md:h-4 mr-1" />
                        Video
                      </TabsTrigger>
                    </TabsList>

                    {/* Tab Content - Using flex-1 to fill remaining space */}
                    <div className="flex-1 overflow-hidden">
                      {/* Chat Tab */}
                      <TabsContent value="chat" className="h-full flex flex-col m-0 p-0">
                        <div className="flex-1 overflow-hidden flex flex-col">
                          {/* Messages Area */}
                          <ScrollArea className="flex-1 p-3 md:p-4">
                            <div className="space-y-4">
                              {messages.map((message) => (
                                <div key={message.id} className={`flex ${message.isBot ? 'justify-start' : 'justify-end'}`}>
                                  <div className={`
                                    max-w-[80%] p-3 rounded-2xl shadow-sm
                                    ${message.isBot 
                                      ? 'bg-orange-50 border border-orange-200 text-gray-800' 
                                      : 'bg-gradient-to-r from-orange-500 to-yellow-500 text-white'
                                    }
                                  `}>
                                    <p className="text-sm leading-relaxed">{message.text}</p>
                                  </div>
                                </div>
                              ))}
                              
                              {/* Typing Indicator */}
                              {isTyping && (
                                <div className="flex justify-start">
                                  <div className="bg-orange-50 border border-orange-200 p-3 rounded-2xl">
                                    <div className="flex space-x-1">
                                      <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse"></div>
                                      <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                                      <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                                    </div>
                                  </div>
                                </div>
                              )}
                              <div ref={chatEndRef} />
                            </div>
                          </ScrollArea>

                          {/* Input Area */}
                          <div className="border-t border-orange-200 p-3 md:p-4 bg-white">
                            <div className="flex gap-2">
                              <Input
                                value={inputText}
                                onChange={(e) => setInputText(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                                placeholder="Ask Jobby anything about Easy Actions..."
                                className="flex-1 rounded-full border-orange-200 focus:border-orange-400 focus:ring-orange-400"
                              />
                              
                              {/* Voice Input Button */}
                              <Button
                                onClick={handleVoiceInput}
                                variant={isListening ? "default" : "outline"}
                                size="sm"
                                className={`rounded-full ${isListening ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse' : 'border-orange-200 hover:bg-orange-50'}`}
                              >
                                {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                              </Button>
                              
                              {/* Send Button */}
                              <Button
                                onClick={handleSendMessage}
                                disabled={!inputText.trim() || isTyping}
                                className="rounded-full bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white"
                                size="sm"
                              >
                                <Send className="w-4 h-4" />
                              </Button>
                            </div>
                            
                            {/* Quick Actions */}
                            <div className="flex flex-wrap gap-2 mt-3">
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={startVisualTutorial}
                                className="text-xs border-orange-200 hover:bg-orange-50"
                              >
                                Start Visual Tutorial
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={() => setInputText("How do I upload my resume?")}
                                className="text-xs border-orange-200 hover:bg-orange-50"
                              >
                                Upload Resume
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={() => setInputText("Show me job matching")}
                                className="text-xs border-orange-200 hover:bg-orange-50"
                              >
                                Job Matching
                              </Button>
                            </div>
                          </div>
                        </div>
                      </TabsContent>

                      {/* Tutorials Tab */}
                      <TabsContent value="tutorials" className="h-full m-0 p-0">
                        <ScrollArea className="h-full p-3 md:p-4">
                          <div className="grid gap-4">
                            {tutorials.map((tutorial) => (
                              <Card key={tutorial.id} className="hover:shadow-lg transition-all duration-300 border-orange-200 hover:border-orange-400 cursor-pointer" onClick={() => handleTutorialSelect(tutorial)}>
                                <CardContent className="p-4">
                                  <div className="flex items-start gap-4">
                                    <div className="text-3xl">{tutorial.thumbnail}</div>
                                    <div className="flex-1">
                                      <h4 className="font-semibold text-gray-900 mb-2">{tutorial.title}</h4>
                                      <p className="text-sm text-gray-600 mb-3">{tutorial.description}</p>
                                      <div className="flex items-center justify-between">
                                        <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                                          <Clock className="w-3 h-3 mr-1" />
                                          {tutorial.duration}
                                        </Badge>
                                        <Button variant="ghost" size="sm" className="text-orange-600 hover:bg-orange-50">
                                          <PlayCircle className="w-4 h-4 mr-1" />
                                          Watch
                                        </Button>
                                      </div>
                                    </div>
                                  </div>
                                </CardContent>
                              </Card>
                            ))}
                          </div>
                        </ScrollArea>
                      </TabsContent>

                      {/* Visual Tutorial Tab */}
                      <TabsContent value="visual-tutorial" className="h-full m-0 p-0">
                        <div className="h-full flex flex-col items-center justify-center p-6 bg-gradient-to-br from-orange-50 to-yellow-50">
                          {isPlayingVisualTutorial ? (
                            <motion.div
                              key={currentTutorialStep}
                              initial={{ opacity: 0, scale: 0.9 }}
                              animate={{ opacity: 1, scale: 1 }}
                              exit={{ opacity: 0, scale: 0.9 }}
                              className="text-center max-w-2xl"
                            >
                              <div className="text-6xl mb-6">{visualTutorialSteps[currentTutorialStep].image}</div>
                              <h2 className="text-2xl font-bold text-gray-900 mb-4">{visualTutorialSteps[currentTutorialStep].title}</h2>
                              <p className="text-lg text-gray-600 mb-6">{visualTutorialSteps[currentTutorialStep].description}</p>
                              <div className="bg-white p-6 rounded-lg shadow-lg border border-orange-200">
                                <p className="text-gray-700">{visualTutorialSteps[currentTutorialStep].content}</p>
                              </div>
                              
                              {/* Progress indicator */}
                              <div className="mt-8">
                                <div className="flex justify-center space-x-2">
                                  {visualTutorialSteps.map((_, index) => (
                                    <div
                                      key={index}
                                      className={`w-2 h-2 rounded-full ${index === currentTutorialStep ? 'bg-orange-500' : 'bg-orange-200'}`}
                                    />
                                  ))}
                                </div>
                                <p className="text-sm text-gray-500 mt-2">
                                  Step {currentTutorialStep + 1} of {visualTutorialSteps.length}
                                </p>
                              </div>
                            </motion.div>
                          ) : (
                            <div className="text-center">
                              <div className="text-6xl mb-6">🎯</div>
                              <h2 className="text-2xl font-bold text-gray-900 mb-4">Interactive Tutorial</h2>
                              <p className="text-lg text-gray-600 mb-8">Learn how Easy Actions works step-by-step</p>
                              <Button 
                                onClick={startVisualTutorial}
                                className="bg-gradient-to-r from-orange-500 to-yellow-500 text-white px-8 py-3 text-lg rounded-full hover:from-orange-600 hover:to-yellow-600"
                              >
                                <Play className="w-5 h-5 mr-2" />
                                Start Interactive Tour
                              </Button>
                            </div>
                          )}
                        </div>
                      </TabsContent>

                      {/* Video Tab */}
                      <TabsContent value="video" className="h-full m-0 p-0">
                        <div className="h-full flex flex-col">
                          {selectedTutorial ? (
                            <>
                              {/* Video Player */}
                              <div className="flex-1 bg-black flex items-center justify-center">
                                <div className="text-white text-center p-8">
                                  <div className="text-4xl mb-4">{selectedTutorial.thumbnail}</div>
                                  <h3 className="text-xl font-semibold mb-2">{selectedTutorial.title}</h3>
                                  <p className="text-gray-300 mb-4">{selectedTutorial.description}</p>
                                  <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 border border-white/20">
                                    <p className="text-sm">Video player placeholder</p>
                                    <p className="text-xs text-gray-400 mt-2">Duration: {selectedTutorial.duration}</p>
                                  </div>
                                </div>
                              </div>
                              
                              {/* Video Controls */}
                              <div className="bg-gray-900 text-white p-4 flex items-center justify-between">
                                <div className="flex items-center gap-4">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleVideoControl(isVideoPlaying ? 'pause' : 'play')}
                                    className="text-white hover:bg-white/20"
                                  >
                                    {isVideoPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                                  </Button>
                                  
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleVideoControl('restart')}
                                    className="text-white hover:bg-white/20"
                                  >
                                    <RotateCcw className="w-4 h-4" />
                                  </Button>
                                  
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleVideoControl('mute')}
                                    className="text-white hover:bg-white/20"
                                  >
                                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                                  </Button>
                                </div>
                                
                                <div className="flex items-center gap-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => setSelectedTutorial(null)}
                                    className="text-white hover:bg-white/20"
                                  >
                                    Back to Tutorials
                                  </Button>
                                </div>
                              </div>
                            </>
                          ) : (
                            <div className="h-full flex items-center justify-center">
                              <div className="text-center">
                                <Video className="w-16 h-16 mx-auto text-orange-400 mb-4" />
                                <h3 className="text-xl font-semibold text-gray-900 mb-2">Select a Tutorial</h3>
                                <p className="text-gray-600">Choose a video tutorial from the Tutorials tab to get started</p>
                              </div>
                            </div>
                          )}
                        </div>
                      </TabsContent>
                    </div>
                  </Tabs>
                </div>
              </>
            )}

            {/* Minimized State */}
            {isMinimized && (
              <div className="w-full h-full flex items-center justify-center bg-gradient-to-r from-orange-500 to-yellow-500 rounded-full">
                <ImageWithFallback
                  src={robotImage}
                  alt="Jobby"
                  className="w-10 h-10 rounded-full object-cover"
                />
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default FloatingHelp;