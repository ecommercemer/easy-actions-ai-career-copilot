import React from 'react';
import { motion } from 'motion/react';

interface JobyMascotProps {
  size?: 'small' | 'medium' | 'large';
  animation?: 'wave' | 'catch' | 'peek' | 'celebrate' | 'fly';
  message?: string;
  className?: string;
}

export default function JobyMascot({ 
  size = 'medium', 
  animation = 'wave', 
  message, 
  className = '' 
}: JobyMascotProps) {
  const sizeClasses = {
    small: 'w-12 h-12',
    medium: 'w-24 h-24', 
    large: 'w-48 h-48'
  };

  const animationVariants = {
    wave: {
      rotate: [0, 15, -15, 0],
      transition: { duration: 2, repeat: Infinity, ease: "easeInOut" }
    },
    catch: {
      y: [0, -10, 0],
      rotate: [0, 5, -5, 0],
      transition: { duration: 3, repeat: Infinity, ease: "easeInOut" }
    },
    peek: {
      x: [-20, 0],
      opacity: [0, 1],
      transition: { duration: 0.8, ease: "easeOut" }
    },
    celebrate: {
      y: [0, -20, 0],
      rotate: [0, 360],
      scale: [1, 1.2, 1],
      transition: { duration: 1.5, repeat: 2, ease: "easeInOut" }
    },
    fly: {
      x: [0, 100, 200],
      y: [0, -20, -10],
      rotate: [0, 15, 0],
      transition: { duration: 2, ease: "easeInOut" }
    }
  };

  return (
    <div className={`relative ${className}`}>
      <motion.div 
        className={`${sizeClasses[size]} rounded-full bg-gradient-to-br from-blue-400 to-blue-600 border-4 border-white shadow-lg flex items-center justify-center`}
        animate={animationVariants[animation]}
      >
        {/* Robot face */}
        <div className="text-white">
          {/* Eyes */}
          <div className="flex space-x-2 mb-1">
            <div className="w-2 h-2 bg-white rounded-full"></div>
            <div className="w-2 h-2 bg-white rounded-full"></div>
          </div>
          {/* Mouth */}
          <div className="w-4 h-1 bg-white rounded-full"></div>
        </div>
        
        {/* Antenna */}
        <div className="absolute -top-2 left-1/2 transform -translate-x-1/2 w-1 h-3 bg-gray-300 rounded-full"></div>
        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2 w-2 h-2 bg-yellow-400 rounded-full"></div>
      </motion.div>
      
      {/* Speech bubble */}
      {message && (
        <motion.div 
          className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-white rounded-lg px-3 py-2 shadow-lg border max-w-xs"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5 }}
        >
          <p className="text-sm text-gray-800">{message}</p>
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-white"></div>
        </motion.div>
      )}
    </div>
  );
}