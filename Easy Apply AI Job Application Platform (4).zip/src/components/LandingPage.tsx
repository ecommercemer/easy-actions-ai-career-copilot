import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'motion/react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import EasyActionsLogo from './EasyActionsLogo';
import PlatformIcons from './PlatformIcons';
import FloatingHelp from './FloatingHelp';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import {
  Upload,
  Search,
  Send,
  CheckCircle,
  Zap,
  Shield,
  Clock,
  TrendingUp,
  Users,
  Star,
  ArrowRight,
  Download,
  Smartphone,
  Chrome,
  Menu,
  X,
  ExternalLink,
  DollarSign,
  PaperClip,
  Sparkles,
  Target
} from 'lucide-react';

const LandingPage: React.FC = () => {
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { scrollY } = useScroll();
  const backgroundY = useTransform(scrollY, [0, 1000], [0, -200]);

  // Platform data with animated icons
  const platforms = [
    { 
      name: 'LinkedIn', 
      url: 'https://linkedin.com', 
      color: '#0077b5',
      icon: '💼',
      description: 'Professional Network'
    },
    { 
      name: 'Xing', 
      url: 'https://xing.com', 
      color: '#006567',
      icon: '🌐',
      description: 'Business Network'
    },
    { 
      name: 'StepStone', 
      url: 'https://stepstone.com', 
      color: '#ff6b35',
      icon: '🪜',
      description: 'Job Portal'
    },
    { 
      name: 'Indeed', 
      url: 'https://indeed.com', 
      color: '#2557a7',
      icon: '🔍',
      description: 'Job Search Engine'
    }
  ];

  // 4-step process data
  const steps = [
    {
      icon: Upload,
      title: "Smart Document Upload",
      description: "Upload resume, cover letter & certificates. AI analyzes and optimizes everything.",
      color: "from-[#ea580c] to-[#f97316]",
    },
    {
      icon: Target,
      title: "Job Matching",
      description: "AI finds perfect job matches based on your profile, skills, and preferences.",
      color: "from-[#f97316] to-[#fbbf24]",
    },
    {
      icon: Sparkles,
      title: "Auto Application",
      description: "Personalized cover letters created and applications sent automatically.",
      color: "from-[#fbbf24] to-[#fde047]",
    },
    {
      icon: Zap,
      title: "Help with Artificial Intelligence",
      description: "24/7 AI assistant provides guidance, answers questions, and optimizes your job search strategy.",
      color: "from-[#fde047] to-[#ea580c]",
    }
  ];

  // Pricing data - simplified and in one drift
  const pricingTiers = [
    {
      name: "Free",
      price: "€0",
      period: "/month",
      applications: "5 applications",
      features: ["Basic AI analysis", "Standard templates", "Email support"],
      popular: false,
      color: "from-[#fed7aa] to-[#fdba74]"
    },
    {
      name: "Pro",
      price: "€29",
      period: "/month", 
      applications: "Unlimited applications",
      features: ["Advanced AI optimization", "Custom cover letters", "Priority support", "Analytics dashboard"],
      popular: true,
      color: "from-[#f97316] to-[#fbbf24]"
    },
    {
      name: "Enterprise",
      price: "€99",
      period: "/month",
      applications: "Multi-client management",
      features: ["White-label solution", "API access", "Dedicated support", "Custom integrations"],
      popular: false,
      color: "from-[#ea580c] to-[#f97316]"
    }
  ];

  const stats = [
    { label: "Applications Sent", value: "50K+", icon: Send },
    { label: "Success Rate", value: "89%", icon: TrendingUp },
    { label: "Happy Users", value: "5,000+", icon: Users },
    { label: "Average Rating", value: "4.9", icon: Star }
  ];

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      {/* Enhanced background with orange gradients */}
      <motion.div
        className="fixed inset-0 -z-10"
        style={{ y: backgroundY }}
      >
        <div className="absolute inset-0 bg-gradient-to-br from-[#fff7ed] via-[#fed7aa] to-[#fb923c]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(234,88,12,0.15),transparent_60%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(251,191,36,0.15),transparent_60%)]" />
      </motion.div>

      {/* Compact Header */}
      <header className="relative z-50 px-4 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <motion.div 
            className="flex items-center space-x-3"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
          >
            <EasyActionsLogo size="md" showText={true} />
          </motion.div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <a href="#features" className="text-slate-700 hover:text-[#ea580c] transition-colors btn-hover-lift">Features</a>
            <a href="#platforms" className="text-slate-700 hover:text-[#ea580c] transition-colors btn-hover-lift">Platforms</a>
            <Button
              onClick={() => navigate('/pricing')}
              variant="outline"
              className="border-[#ea580c] text-[#ea580c] hover:bg-[#ea580c] hover:text-white btn-hover-lift"
            >
              <DollarSign className="w-4 h-4 mr-2" />
              Pricing
            </Button>
            <Button
              onClick={() => navigate('/auth')}
              className="gradient-button text-white px-6 glow-orange btn-hover-lift"
            >
              Get Started
            </Button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg bg-white/80 backdrop-blur-sm btn-hover-lift"
          >
            {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden mt-4 p-4 rounded-xl glass backdrop-blur-lg"
          >
            <nav className="flex flex-col space-y-4">
              <a href="#features" className="text-slate-700 hover:text-[#ea580c] transition-colors">Features</a>
              <a href="#platforms" className="text-slate-700 hover:text-[#ea580c] transition-colors">Platforms</a>
              <Button
                onClick={() => navigate('/pricing')}
                variant="outline"
                className="border-[#ea580c] text-[#ea580c] hover:bg-[#ea580c] hover:text-white"
              >
                Pricing
              </Button>
              <Button
                onClick={() => navigate('/auth')}
                className="gradient-button text-white"
              >
                Get Started
              </Button>
            </nav>
          </motion.div>
        )}
      </header>

      {/* Compact Hero Section */}
      <section className="relative px-4 py-12 md:py-20">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-12"
          >
            {/* Animated Robot */}
            <motion.div
              className="mb-8"
              animate={{
                y: [0, -10, 0],
                rotate: [0, 2, -2, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <ImageWithFallback
                src={robotImage}
                alt="AI Assistant Robot"
                className="w-24 h-24 md:w-32 md:h-32 mx-auto rounded-full shadow-2xl border-4 border-white/50 robot-bounce glow-orange"
              />
            </motion.div>

            <h1 className="text-4xl md:text-6xl font-bold mb-6 drop-shadow-lg">
              <span className="gradient-text glow-orange drop-shadow-md">Land Your Dream Job</span>
              <br />
              <span className="gradient-text text-slate-800 drop-shadow-md">in 3 Seconds</span>
            </h1>

            <p className="text-xl md:text-2xl text-slate-700 mb-8 max-w-4xl mx-auto font-medium">
              Our AI uploads your resume, finds perfect matches, and applies to hundreds of jobs automatically. 
              <span className="font-bold text-[#ea580c]"> Let automation work for you!</span>
            </p>

            <motion.div
              className="flex flex-col sm:flex-row gap-4 justify-center mb-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.8 }}
            >
              <Button
                onClick={() => navigate('/auth')}
                className="gradient-button text-white px-8 py-4 text-lg font-semibold glow-orange btn-hover-lift"
                size="lg"
              >
                <Upload className="w-5 h-5 mr-2" />
                Start Free - Upload Resume
              </Button>
              
              <Button
                variant="outline"
                size="lg"
                onClick={() => navigate('/pricing')}
                className="px-8 py-4 text-lg border-2 border-[#ea580c] text-[#ea580c] hover:bg-[#ea580c] hover:text-white bg-white/80 backdrop-blur-sm btn-hover-lift"
              >
                <Download className="w-5 h-5 mr-2" />
                Download Extension
              </Button>
            </motion.div>

            {/* Compact Stats */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8, duration: 0.8 }}
              className="grid grid-cols-2 md:grid-cols-4 gap-6"
            >
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div key={index} className="text-center">
                    <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br from-[#ea580c] to-[#fbbf24] flex items-center justify-center shadow-lg">
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-2xl font-bold gradient-text">{stat.value}</div>
                    <div className="text-sm text-slate-600">{stat.label}</div>
                  </div>
                );
              })}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Platform Integration with Animated Icons */}
      <section id="platforms" className="px-4 py-16 bg-white/40 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-12"
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6 drop-shadow-lg">
              <span className="gradient-text glow-orange">Apply Everywhere</span>
              <br />
              <span className="text-slate-800 drop-shadow-md">Automatically</span>
            </h2>
            <p className="text-lg md:text-xl text-slate-600 max-w-3xl mx-auto font-medium">
              Connect with top job platforms. Our AI sends applications with one click.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <PlatformIcons size="xl" showLabels={true} className="mb-8" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5, duration: 0.8 }}
          >
            <Badge variant="secondary" className="bg-orange-100 text-orange-800 px-6 py-3 text-lg font-semibold shadow-lg">
              <CheckCircle className="w-6 h-6 mr-3 text-orange-600" />
              Seamlessly integrated with all platforms
            </Badge>
          </motion.div>
        </div>
      </section>

      {/* 4-Step Process */}
      <section id="features" className="px-4 py-16">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-5xl font-bold mb-6 drop-shadow-lg">
              <span className="gradient-text glow-orange">How It Works</span>
            </h2>
            <p className="text-lg md:text-xl text-slate-600 max-w-3xl mx-auto font-medium">
              Our 4-step automated process makes job hunting effortless
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 md:gap-6">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.2, duration: 0.8 }}
                  whileHover={{ y: -5, scale: 1.02 }}
                  className="relative"
                >
                  <Card className="h-full glass glow-orange shadow-lg hover:shadow-xl transition-all duration-300">
                    <CardHeader className="text-center pb-3 pt-4 px-3">
                      <div className={`w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-br ${step.color} flex items-center justify-center shadow-lg`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="absolute top-3 right-3 w-6 h-6 bg-gradient-to-r from-[#ea580c] to-[#fbbf24] text-white rounded-full flex items-center justify-center font-bold text-sm">
                        {index + 1}
                      </div>
                      <CardTitle className="text-base gradient-text leading-tight">{step.title}</CardTitle>
                    </CardHeader>
                    <CardContent className="px-3 pb-4">
                      <CardDescription className="text-slate-600 text-center leading-snug text-sm">
                        {step.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="glass p-8 rounded-3xl glow-orange shadow-2xl"
          >
            <ImageWithFallback
              src={robotImage}
              alt="AI Assistant Robot"
              className="w-20 h-20 mx-auto rounded-full shadow-lg mb-6 robot-bounce"
            />
            <h2 className="text-3xl md:text-4xl font-bold gradient-text glow-orange drop-shadow-lg mb-4">
              Ready to Transform Your Career?
            </h2>
            <p className="text-xl text-slate-600 mb-8 max-w-2xl mx-auto font-medium">
              Join thousands who've automated their job search and landed dream positions
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                onClick={() => navigate('/auth')}
                className="gradient-button glow-orange text-white px-8 py-4 text-lg font-semibold btn-hover-lift"
                size="lg"
              >
                <Zap className="w-5 h-5 mr-2" />
                Start Free Trial
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="px-8 py-4 text-lg border-2 border-[#ea580c] hover:bg-[#ea580c] hover:text-white bg-white/80 backdrop-blur-sm btn-hover-lift"
              >
                <Smartphone className="w-5 h-5 mr-2" />
                Download App
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Compact Footer */}
      <footer className="px-4 py-8 bg-white/50 backdrop-blur-sm border-t border-[#ea580c]/30">
        <div className="max-w-6xl mx-auto text-center">
          <EasyActionsLogo size="md" showText={true} className="justify-center mb-4" />
          
          <p className="text-slate-600 mb-4">
            © 2024 Easy Actions. All rights reserved. Made with ❤️ for ambitious professionals.
          </p>
          <div className="flex justify-center space-x-6">
            <a href="#" className="text-slate-500 hover:text-[#ea580c] transition-colors btn-hover-lift">Privacy</a>
            <a href="#" className="text-slate-500 hover:text-[#ea580c] transition-colors btn-hover-lift">Terms</a>
            <a href="#" className="text-slate-500 hover:text-[#ea580c] transition-colors btn-hover-lift">Contact</a>
          </div>
        </div>
      </footer>

      {/* Enhanced Floating Help Component */}
      <FloatingHelp />
    </div>
  );
};

export default LandingPage;