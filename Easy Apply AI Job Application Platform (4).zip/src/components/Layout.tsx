import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Home, Search, Calendar, User, FileText, Mail, Settings as SettingsIcon, Menu, X, LogOut, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import FloatingHelp from './FloatingHelp';
import EasyActionsLogo from './EasyActionsLogo';
import { useAuth } from './AuthContext';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Navigation items for desktop sidebar
  const navItems = [
    { id: 'dashboard', label: 'Home', icon: Home, path: '/dashboard' },
    { id: 'tracker', label: 'Job Tracker', icon: Calendar, path: '/tracker' },
    { id: 'documents', label: 'Documents', icon: FileText, path: '/documents' },
    { id: 'email', label: 'Email Center', icon: Mail, path: '/email' },
    { id: 'settings', label: 'Settings', icon: SettingsIcon, path: '/settings' },
  ];

  // Mobile navigation items for bottom tab bar
  const mobileNavItems = [
    { id: 'dashboard', label: 'Home', icon: Home, path: '/dashboard' },
    { id: 'tracker', label: 'Jobs', icon: Search, path: '/tracker' },
    { id: 'documents', label: 'Docs', icon: FileText, path: '/documents' },
    { id: 'settings', label: 'Profile', icon: User, path: '/settings' },
  ];

  const isActive = (path: string) => location.pathname === path;

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#fff7ed] via-[#fed7aa] to-[#fb923c] relative">
      {/* Desktop Sidebar - Sliding Panel */}
      <AnimatePresence>
        {sidebarOpen && (
          <>
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/20 backdrop-blur-sm md:hidden"
              onClick={() => setSidebarOpen(false)}
            />
            
            {/* Sidebar */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 z-50 h-full w-80 bg-white/95 backdrop-blur-xl border-r border-orange-200/30 shadow-2xl"
            >
              <div className="flex h-full flex-col">
                {/* Header */}
                <div className="flex h-16 items-center justify-between px-6 border-b border-orange-200/30">
                  <div className="flex items-center space-x-3">
                    <ImageWithFallback
                      src={robotImage}
                      alt="AI Assistant Robot"
                      className="w-10 h-10 rounded-xl shadow-lg robot-bounce"
                    />
                    <div>
                      <span className="text-lg font-bold gradient-text">Easy Actions</span>
                      <p className="text-xs text-[#ea580c]">AI Co-pilot</p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setSidebarOpen(false)}
                    className="text-orange-600 hover:bg-orange-100"
                  >
                    <X className="w-5 h-5" />
                  </Button>
                </div>

                {/* User Profile Section */}
                <div className="p-6 border-b border-orange-200/30">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#ea580c] to-[#fbbf24] flex items-center justify-center shadow-lg">
                      <User className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-slate-800">{user?.name || 'User'}</h3>
                      <p className="text-sm text-slate-600">{user?.email}</p>
                      <span className="inline-block px-2 py-1 text-xs bg-orange-100 text-orange-600 rounded-full mt-1">
                        {user?.plan || 'Free'} Plan
                      </span>
                    </div>
                  </div>
                </div>

                {/* Navigation */}
                <nav className="flex-1 px-4 py-6 space-y-2">
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    const active = isActive(item.path);
                    return (
                      <motion.button
                        key={item.id}
                        onClick={() => {
                          navigate(item.path);
                          setSidebarOpen(false);
                        }}
                        className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                          active 
                            ? 'bg-gradient-to-r from-[#ea580c] to-[#f97316] text-white shadow-lg glow-orange' 
                            : 'text-slate-700 hover:bg-orange-50 hover:text-orange-600'
                        }`}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="font-medium">{item.label}</span>
                      </motion.button>
                    );
                  })}
                </nav>

                {/* Logout Button */}
                <div className="p-6 border-t border-orange-200/30">
                  <Button
                    onClick={handleLogout}
                    variant="outline"
                    className="w-full border-orange-200 text-orange-600 hover:bg-orange-50"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="min-h-screen">
        {/* Top Header */}
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-orange-200/30">
          <div className="flex h-16 items-center justify-between px-4">
            {/* Left side */}
            <div className="flex items-center space-x-4">
              {/* Hamburger Menu */}
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleSidebar}
                className="text-orange-600 hover:bg-orange-100 btn-hover-lift"
              >
                <Menu className="w-5 h-5" />
              </Button>

              {/* Logo with Easy Actions branding */}
              <EasyActionsLogo size="md" showText={true} className="hidden sm:flex" />
              
              {/* Mobile logo - simplified */}
              <div className="flex items-center space-x-2 sm:hidden">
                <ImageWithFallback
                  src={robotImage}
                  alt="AI Assistant Robot"
                  className="w-8 h-8 rounded-lg shadow-sm robot-hover"
                />
                <span className="font-bold gradient-text text-sm">Easy Actions</span>
              </div>
            </div>

            {/* Right side - Profile and Settings */}
            <div className="flex items-center space-x-2">
              {/* Quick Settings */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/settings')}
                className="text-orange-600 hover:bg-orange-100 btn-hover-lift"
              >
                <SettingsIcon className="w-5 h-5" />
              </Button>

              {/* Profile */}
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/settings')}
                className="flex items-center space-x-2 text-orange-600 hover:bg-orange-100 btn-hover-lift"
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#ea580c] to-[#fbbf24] flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <span className="hidden md:block font-medium">{user?.name || 'User'}</span>
              </Button>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="pb-20 md:pb-0">
          {/* Back/Home Button - Always Visible at top of content */}
          <div className="p-4">
            <Button
              variant="ghost"
              onClick={() => navigate(location.pathname === '/dashboard' ? '/' : '/dashboard')}
              className="mb-4 hover:bg-orange-50 text-slate-700 hover:text-orange-600 transition-colors btn-hover-lift"
              size="sm"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              {location.pathname === '/dashboard' ? 'Back to Home' : 'Back to Dashboard'}
            </Button>
          </div>
          {children}
        </main>
      </div>

      {/* Mobile Bottom Tab Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-xl border-t border-orange-200/30">
        <div className="grid grid-cols-4 h-16">
          {mobileNavItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.path);
            return (
              <motion.button
                key={item.id}
                onClick={() => navigate(item.path)}
                className={`flex flex-col items-center justify-center space-y-1 transition-colors ${
                  active 
                    ? 'text-orange-600' 
                    : 'text-slate-500 hover:text-orange-600'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Icon className={`w-5 h-5 ${active ? 'text-orange-600' : ''}`} />
                <span className={`text-xs ${active ? 'text-orange-600 font-medium' : ''}`}>
                  {item.label}
                </span>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Floating Help with Robot */}
      <FloatingHelp />
    </div>
  );
};

export default Layout;