import React from 'react';

interface PlatformIconProps {
  platform: 'linkedin' | 'xing' | 'stepstone' | 'indeed';
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showLabel?: boolean;
}

const platformData = {
  linkedin: {
    name: 'LinkedIn',
    color: '#0A66C2',
    bgColor: '#ffffff',
    url: 'https://www.linkedin.com'
  },
  xing: {
    name: 'Xing',
    color: '#026466',
    bgColor: '#ffffff',
    url: 'https://www.xing.com'
  },
  stepstone: {
    name: 'StepStone',
    color: '#FF6B35',
    bgColor: '#ffffff',
    url: 'https://www.stepstone.com'
  },
  indeed: {
    name: 'Indeed',
    color: '#2557A7',
    bgColor: '#ffffff',
    url: 'https://www.indeed.com'
  }
};

function PlatformIcon({ platform, className = '', size = 'md', showLabel = true }: PlatformIconProps) {
  const sizeClasses = {
    sm: 'w-12 h-12',
    md: 'w-16 h-16',
    lg: 'w-20 h-20',
    xl: 'w-24 h-24'
  };

  const iconSizeClasses = {
    sm: 'w-6 h-6',
    md: 'w-8 h-8',
    lg: 'w-10 h-10',
    xl: 'w-12 h-12'
  };

  const data = platformData[platform];

  const renderIcon = () => {
    switch (platform) {
      case 'linkedin':
        return (
          <svg viewBox="0 0 24 24" className={iconSizeClasses[size]} fill={data.color}>
            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
          </svg>
        );
      
      case 'xing':
        return (
          <svg viewBox="0 0 24 24" className={iconSizeClasses[size]} fill={data.color}>
            <path d="M18.188 0c-.517 0-.741.325-.927.66 0 0-7.455 13.224-7.702 13.657.284.52 4.56 8.345 4.56 8.345.188.335.411.66.927.66h3.905c.104 0 .174-.057.174-.156 0-.064-.022-.114-.068-.172L14.473 14.69 22.395.896c.047-.058.068-.108.068-.172 0-.099-.069-.156-.174-.156H18.188zm-13.42 9.53l-3.136 5.717c-.047.058-.068.108-.068.172 0 .099.068.156.174.156h3.905c.517 0 .741-.325.927-.66 0 0 3.208-5.853 3.208-5.853L8.21 7.33c-.188-.335-.411-.66-.927-.66H3.378c-.104 0-.174.057-.174.156 0 .064.022.114.068.172l1.496 2.862z"/>
          </svg>
        );
      
      case 'stepstone':
        return (
          <svg viewBox="0 0 24 24" className={iconSizeClasses[size]} fill={data.color}>
            <path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 11 5.16-1.26 9-5.45 9-11V7l-10-5z"/>
            <path d="M9 12l2 2 4-4" stroke="white" strokeWidth="1.5" fill="none"/>
            <circle cx="12" cy="12" r="8" fill="none" stroke={data.color} strokeWidth="2"/>
            <text x="12" y="16" textAnchor="middle" className="text-xs font-bold" fill="white">S</text>
          </svg>
        );
      
      case 'indeed':
        return (
          <svg viewBox="0 0 24 24" className={iconSizeClasses[size]} fill={data.color}>
            <path d="M11.566 21.563v-8.762c0-1.095.633-1.826 1.648-1.826.912 0 1.463.638 1.463 1.754v8.834h3.427V11.844c0-2.742-1.34-4.611-4.016-4.611-1.658 0-2.87.876-3.302 2.174h-.146V7.563H7.427v14zm.365-19.25c1.243 0 2.174.912 2.174 2.174s-.931 2.174-2.174 2.174c-1.242 0-2.173-.912-2.173-2.174s.931-2.174 2.173-2.174z"/>
            <circle cx="12" cy="12" r="10" fill="none" stroke={data.color} strokeWidth="1.5"/>
          </svg>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className={`flex flex-col items-center gap-2 ${className}`}>
      {/* Icon container as anchor tag with no interfering wrappers */}
      <a
        href={data.url}
        target="_blank"
        rel="noopener noreferrer"
        className={`
          ${sizeClasses[size]} 
          bg-white 
          rounded-2xl 
          shadow-lg 
          border-2 
          border-transparent 
          hover:border-[#ea580c] 
          flex 
          items-center 
          justify-center 
          relative 
          overflow-hidden 
          group 
          cursor-pointer 
          transition-all 
          duration-300 
          hover:scale-110 
          hover:shadow-xl
          hover:!no-underline
        `}
        style={{ 
          boxShadow: `0 4px 20px rgba(0,0,0,0.1), inset 0 1px 0 rgba(255,255,255,0.6)` 
        }}
        title={`Visit ${data.name} - Click to open in new tab`}
      >
        {/* Background with platform color on hover */}
        <div 
          className="absolute inset-0 opacity-0 group-hover:opacity-10 transition-opacity duration-300 pointer-events-none"
          style={{ backgroundColor: data.color }}
        />
        
        {/* Platform icon */}
        <div className="relative z-10 flex items-center justify-center pointer-events-none">
          {renderIcon()}
        </div>
        
        {/* Subtle inner glow */}
        <div 
          className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-20 transition-opacity duration-300 pointer-events-none"
          style={{ 
            background: `radial-gradient(circle at center, ${data.color}20, transparent 70%)` 
          }}
        />
      </a>
      
      {showLabel && (
        <a
          href={data.url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs font-semibold text-gray-700 tracking-wide cursor-pointer hover:text-[#ea580c] transition-colors duration-200 hover:!no-underline"
          title={`Visit ${data.name} - Click to open in new tab`}
        >
          {data.name}
        </a>
      )}
    </div>
  );
}

interface PlatformIconsGridProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showLabels?: boolean;
}

export default function PlatformIcons({ 
  className = '', 
  size = 'md', 
  showLabels = true 
}: PlatformIconsGridProps) {
  const platforms: ('linkedin' | 'xing' | 'stepstone' | 'indeed')[] = [
    'linkedin', 
    'xing', 
    'stepstone', 
    'indeed'
  ];

  return (
    <div className={`grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 ${className}`}>
      {platforms.map((platform) => (
        <div key={platform} className="flex justify-center">
          <PlatformIcon 
            platform={platform} 
            size={size} 
            showLabel={showLabels} 
          />
        </div>
      ))}
    </div>
  );
}

export { PlatformIcon };