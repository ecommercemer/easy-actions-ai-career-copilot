import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import {
  CheckCircle,
  ArrowLeft,
  Zap,
  Crown,
  Building,
  Star,
  Sparkles,
  Target,
  TrendingUp,
  Shield,
  Headphones,
  Globe,
  Users,
  BarChart,
  DollarSign,
  Gift,
  Copy,
  Share2
} from 'lucide-react';

const PricingPage: React.FC = () => {
  const navigate = useNavigate();

  const pricingTiers = [
    {
      name: "Free Starter",
      price: "€0",
      period: "/month",
      description: "Perfect for trying out our AI-powered job search",
      applications: "5 applications per month",
      features: [
        "Basic AI resume analysis",
        "Standard cover letter templates", 
        "Email support",
        "Job matching on 2 platforms",
        "Basic application tracking"
      ],
      popular: false,
      color: "from-[#fed7aa] to-[#fdba74]",
      icon: Target,
      bgGradient: "from-orange-50 to-amber-50",
      buttonVariant: "outline" as const,
      buttonClass: "border-2 border-[#ea580c] text-[#ea580c] hover:bg-[#ea580c] hover:text-white"
    },
    {
      name: "Pro Accelerator", 
      price: "€29",
      period: "/month",
      description: "Unlimited applications with advanced AI optimization",
      applications: "Unlimited applications",
      features: [
        "Advanced AI resume & cover letter optimization",
        "Personalized cover letters for each job",
        "Priority customer support",
        "All 4 job platforms (LinkedIn, Xing, StepStone, Indeed)",
        "Advanced analytics dashboard",
        "Interview preparation tips",
        "Salary negotiation insights",
        "Auto follow-up emails"
      ],
      popular: true,
      color: "from-[#f97316] to-[#fbbf24]",
      icon: Zap,
      bgGradient: "from-orange-100 to-yellow-100",
      buttonVariant: "default" as const,
      buttonClass: "gradient-button glow-orange text-white shadow-xl"
    },
    {
      name: "Enterprise Suite",
      price: "€99", 
      period: "/month",
      description: "Complete solution for agencies and career consultants",
      applications: "Multi-client management dashboard",
      features: [
        "White-label solution with your branding",
        "Dedicated API access for integrations",
        "Dedicated account manager",
        "Custom AI model training",
        "Bulk client management",
        "Advanced reporting & analytics",
        "Custom integrations available",
        "24/7 phone support",
        "Team collaboration tools"
      ],
      popular: false,
      color: "from-[#ea580c] to-[#dc2626]",
      icon: Crown,
      bgGradient: "from-orange-200 to-red-100", 
      buttonVariant: "outline" as const,
      buttonClass: "border-2 border-[#ea580c] text-[#ea580c] hover:bg-[#ea580c] hover:text-white"
    }
  ];

  const benefits = [
    {
      icon: TrendingUp,
      title: "89% Success Rate",
      description: "Our AI-optimized applications have an 89% higher response rate than traditional methods."
    },
    {
      icon: Shield,
      title: "Secure & Private",
      description: "Your data is encrypted and never shared. We follow strict GDPR compliance."
    },
    {
      icon: Sparkles,
      title: "Continuous Learning",
      description: "Our AI learns from every application to improve your success rate over time."
    },
    {
      icon: Globe,
      title: "Global Reach",
      description: "Apply to jobs across Europe with localized cover letters and formatting."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#fff7ed] via-[#fed7aa] to-[#fb923c] relative overflow-x-hidden">
      {/* Enhanced animated background */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(234,88,12,0.1),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(251,191,36,0.1),transparent_50%)]" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(249,115,22,0.05),transparent_70%)]" />
        
        {/* Floating particles */}
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-orange-300/20 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [0, -100, 0],
                opacity: [0, 1, 0],
                scale: [0, 1, 0],
              }}
              transition={{
                duration: Math.random() * 4 + 3,
                repeat: Infinity,
                delay: Math.random() * 3,
              }}
            />
          ))}
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-orange-200/30">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              onClick={() => navigate('/')}
              className="text-orange-600 hover:bg-orange-100 btn-hover-lift"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>
          
          <div className="flex items-center space-x-3">
            <ImageWithFallback
              src={robotImage}
              alt="AI Assistant Robot"
              className="w-10 h-10 rounded-xl shadow-lg robot-bounce"
            />
            <div>
              <span className="font-bold gradient-text">Easy Actions</span>
              <p className="text-xs text-[#ea580c]">Pricing Plans</p>
            </div>
          </div>

          <Button
            onClick={() => navigate('/auth')}
            className="gradient-button glow-orange text-white btn-hover-lift"
          >
            Get Started
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="px-4 py-16 text-center">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-12"
          >
            <motion.div
              animate={{
                y: [0, -10, 0],
                rotate: [0, 2, -2, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="mb-6"
            >
              <ImageWithFallback
                src={robotImage}
                alt="AI Assistant Robot"
                className="w-20 h-20 mx-auto rounded-full shadow-2xl border-4 border-white/80 glow-orange"
              />
            </motion.div>

            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              <span className="gradient-text">Choose Your AI</span>
              <br />
              <span className="text-slate-800">Career Plan</span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto">
              From free trials to enterprise solutions - find the perfect plan to 
              <span className="font-semibold text-[#ea580c]"> accelerate your career</span>
            </p>
          </motion.div>
        </div>
      </section>

      {/* Pricing Cards - All in One Drift */}
      <section className="px-4 pb-16">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {pricingTiers.map((tier, index) => {
              const Icon = tier.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.2, duration: 0.8 }}
                  whileHover={{ y: -10, scale: 1.02 }}
                  className={`relative ${tier.popular ? 'md:-mt-8' : ''}`}
                >
                  {tier.popular && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: 0.5, type: "spring", stiffness: 200 }}
                      className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-10"
                    >
                      <Badge className="bg-gradient-to-r from-[#ea580c] to-[#fbbf24] text-white px-6 py-2 text-sm font-semibold shadow-xl">
                        <Star className="w-4 h-4 mr-1" />
                        Most Popular
                      </Badge>
                    </motion.div>
                  )}
                  
                  <Card className={`h-full glass glow-orange shadow-2xl transition-all duration-300 ${
                    tier.popular 
                      ? 'border-2 border-[#fbbf24] shadow-[0_0_40px_rgba(251,191,36,0.3)] bg-gradient-to-b from-white/95 to-orange-50/95' 
                      : 'border border-orange-200/40 bg-white/90'
                  } backdrop-blur-xl hover:shadow-3xl`}>
                    <CardHeader className="text-center pb-4">
                      <div className={`w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br ${tier.color} flex items-center justify-center shadow-xl`}>
                        <Icon className="w-10 h-10 text-white" />
                      </div>
                      
                      <CardTitle className="text-2xl gradient-text mb-2">{tier.name}</CardTitle>
                      
                      <div className="flex items-baseline justify-center mb-3">
                        <span className="text-5xl font-bold gradient-text">{tier.price}</span>
                        <span className="text-slate-600 ml-2 text-lg">{tier.period}</span>
                      </div>
                      
                      <CardDescription className="text-slate-600 leading-relaxed mb-4">
                        {tier.description}
                      </CardDescription>
                      
                      <div className={`px-4 py-3 rounded-xl bg-gradient-to-r ${tier.bgGradient} border border-orange-200/30`}>
                        <p className="font-semibold text-orange-800 text-sm">{tier.applications}</p>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-6">
                      <ul className="space-y-4">
                        {tier.features.map((feature, idx) => (
                          <motion.li 
                            key={idx}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: index * 0.2 + idx * 0.1 }}
                            className="flex items-start text-sm"
                          >
                            <CheckCircle className="w-5 h-5 text-[#ea580c] mr-3 flex-shrink-0 mt-0.5" />
                            <span className="text-slate-700">{feature}</span>
                          </motion.li>
                        ))}
                      </ul>
                      
                      <motion.div
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Button
                          onClick={() => navigate('/auth')}
                          variant={tier.buttonVariant}
                          className={`w-full text-lg py-6 font-semibold btn-hover-lift ${tier.buttonClass}`}
                          size="lg"
                        >
                          {tier.popular ? (
                            <>
                              <Zap className="w-5 h-5 mr-2" />
                              Start Free Trial
                            </>
                          ) : tier.name.includes('Enterprise') ? (
                            <>
                              <Building className="w-5 h-5 mr-2" />
                              Contact Sales
                            </>
                          ) : (
                            <>
                              <Target className="w-5 h-5 mr-2" />
                              Get Started Free
                            </>
                          )}
                        </Button>
                      </motion.div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="px-4 py-16 bg-white/40 backdrop-blur-sm border-y border-orange-200/30">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
              Why Choose Easy Actions?
            </h2>
            <p className="text-lg text-slate-600 max-w-3xl mx-auto">
              Join thousands of professionals who've transformed their career with our AI-powered platform
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.8 }}
                  whileHover={{ y: -10 }}
                >
                  <Card className="h-full glass glow-orange shadow-xl hover:shadow-2xl transition-all duration-300 border-orange-200/30">
                    <CardContent className="p-6 text-center">
                      <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-[#ea580c] to-[#fbbf24] flex items-center justify-center shadow-lg">
                        <Icon className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-lg font-semibold gradient-text mb-2">{benefit.title}</h3>
                      <p className="text-sm text-slate-600 leading-relaxed">{benefit.description}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Referral Program Section */}
      <section className="px-4 py-16">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-12"
          >
            <h2 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
              Share & Save Program
            </h2>
            <p className="text-lg text-slate-600 max-w-3xl mx-auto">
              Introduce Easy Actions to your network and earn rewards for every successful referral
            </p>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Referral Benefits */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
            >
              <Card className="h-full glass glow-orange shadow-xl border-orange-200/30 bg-gradient-to-br from-white/95 to-green-50/95">
                <CardHeader className="text-center pb-6">
                  <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-green-500 to-emerald-500 flex items-center justify-center shadow-xl">
                    <Gift className="w-10 h-10 text-white" />
                  </div>
                  <CardTitle className="text-2xl gradient-text mb-2">Referral Rewards</CardTitle>
                  <CardDescription className="text-slate-600 leading-relaxed">
                    Help your friends advance their careers while earning exclusive benefits
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-start space-x-4 p-4 bg-white/60 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-r from-green-500 to-emerald-500 flex items-center justify-center flex-shrink-0">
                        <DollarSign className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-slate-800 mb-1">€10 Credit for You</h4>
                        <p className="text-sm text-slate-600">Receive €10 account credit for each friend who signs up for a paid plan</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-4 p-4 bg-white/60 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
                        <Users className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-slate-800 mb-1">20% Discount for Friends</h4>
                        <p className="text-sm text-slate-600">Your referrals get 20% off their first 3 months on any paid plan</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start space-x-4 p-4 bg-white/60 rounded-lg">
                      <div className="w-8 h-8 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
                        <Star className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-slate-800 mb-1">VIP Status Upgrade</h4>
                        <p className="text-sm text-slate-600">Refer 5+ friends and unlock VIP support & exclusive AI features</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-yellow-50 to-orange-50 p-4 rounded-lg border border-yellow-200/50">
                    <div className="flex items-center space-x-2 mb-2">
                      <Gift className="w-5 h-5 text-orange-600" />
                      <h4 className="font-semibold text-orange-800">Limited Time Bonus</h4>
                    </div>
                    <p className="text-sm text-orange-700">
                      First 100 referrers get an additional €5 bonus per successful referral!
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Referral Code & Share */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <Card className="h-full glass glow-orange shadow-xl border-orange-200/30 bg-gradient-to-br from-white/95 to-blue-50/95">
                <CardHeader className="text-center pb-6">
                  <div className="w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center shadow-xl">
                    <Share2 className="w-10 h-10 text-white" />
                  </div>
                  <CardTitle className="text-2xl gradient-text mb-2">Share Your Code</CardTitle>
                  <CardDescription className="text-slate-600 leading-relaxed">
                    Get started with your personal referral code and tracking dashboard
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-6">
                  {/* Sample Referral Code */}
                  <div className="bg-white/80 p-6 rounded-xl border border-blue-200/30">
                    <h4 className="font-semibold text-slate-800 mb-3 text-center">Your Referral Code</h4>
                    <div className="bg-gradient-to-r from-blue-100 to-purple-100 p-4 rounded-lg border border-blue-200">
                      <div className="flex items-center justify-between">
                        <code className="text-2xl font-mono font-bold text-blue-800">EASY2024</code>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-blue-300 text-blue-700 hover:bg-blue-100"
                          onClick={() => navigator.clipboard.writeText('EASY2024')}
                        >
                          <Copy className="w-4 h-4 mr-2" />
                          Copy
                        </Button>
                      </div>
                    </div>
                    <p className="text-sm text-slate-600 mt-3 text-center">
                      Share this code with friends for instant 20% discount
                    </p>
                  </div>
                  
                  {/* Quick Share Options */}
                  <div className="space-y-4">
                    <h4 className="font-semibold text-slate-800 text-center">Quick Share Options</h4>
                    <div className="grid grid-cols-2 gap-3">
                      <Button
                        variant="outline"
                        className="border-blue-200 text-blue-700 hover:bg-blue-50 btn-hover-lift"
                        onClick={() => window.open('mailto:?subject=Transform your career with Easy Actions&body=I found this amazing AI job application platform! Get 20% off with code EASY2024: https://easyactions.app', '_blank')}
                      >
                        📧 Email
                      </Button>
                      <Button
                        variant="outline"
                        className="border-green-200 text-green-700 hover:bg-green-50 btn-hover-lift"
                        onClick={() => window.open('https://wa.me/?text=Transform your career with Easy Actions AI! Get 20% off with code EASY2024: https://easyactions.app', '_blank')}
                      >
                        💬 WhatsApp
                      </Button>
                      <Button
                        variant="outline"
                        className="border-blue-200 text-blue-700 hover:bg-blue-50 btn-hover-lift"
                        onClick={() => window.open('https://linkedin.com/sharing/share-offsite/?url=https://easyactions.app', '_blank')}
                      >
                        💼 LinkedIn
                      </Button>
                      <Button
                        variant="outline"
                        className="border-purple-200 text-purple-700 hover:bg-purple-50 btn-hover-lift"
                        onClick={() => window.open('https://twitter.com/intent/tweet?text=Just found an amazing AI job search platform! Get 20% off with code EASY2024&url=https://easyactions.app', '_blank')}
                      >
                        🐦 Twitter
                      </Button>
                    </div>
                  </div>
                  
                  {/* Referral Stats Preview */}
                  <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-lg border border-purple-200/50">
                    <h4 className="font-semibold text-purple-800 mb-3 text-center">Your Referral Stats</h4>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold text-purple-700">0</div>
                        <div className="text-xs text-purple-600">Invited</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-purple-700">0</div>
                        <div className="text-xs text-purple-600">Joined</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-purple-700">€0</div>
                        <div className="text-xs text-purple-600">Earned</div>
                      </div>
                    </div>
                    <p className="text-xs text-purple-600 text-center mt-3">
                      Sign up to track your referrals and earnings
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* FAQ or CTA Section */}
      <section className="px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="glass p-8 md:p-12 rounded-3xl glow-orange shadow-2xl border border-orange-200/30"
          >
            <ImageWithFallback
              src={robotImage}
              alt="AI Assistant Robot"
              className="w-24 h-24 mx-auto rounded-full shadow-lg mb-8 robot-bounce"
            />
            
            <h2 className="text-3xl md:text-4xl font-bold gradient-text mb-4">
              Ready to Transform Your Career?
            </h2>
            <p className="text-xl text-slate-600 mb-8 max-w-3xl mx-auto">
              Start your free trial today. No credit card required. Cancel anytime.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <Button
                onClick={() => navigate('/auth')}
                className="flex-1 gradient-button glow-orange text-white px-8 py-4 text-lg font-semibold btn-hover-lift shadow-xl"
                size="lg"
              >
                <Zap className="w-5 h-5 mr-2" />
                Start Free Trial
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="flex-1 px-8 py-4 text-lg border-2 border-[#ea580c] text-[#ea580c] hover:bg-[#ea580c] hover:text-white bg-white/90 btn-hover-lift"
              >
                <Headphones className="w-5 h-5 mr-2" />
                Contact Sales
              </Button>
            </div>
            
            <p className="text-sm text-slate-500 mt-6">
              ✨ Join 5,000+ professionals already using Easy Actions
            </p>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-4 py-8 bg-white/60 backdrop-blur-sm border-t border-orange-200/30">
        <div className="max-w-6xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-6">
            <ImageWithFallback
              src={robotImage}
              alt="AI Assistant Robot"
              className="w-12 h-12 rounded-xl shadow-lg robot-hover"
            />
            <div>
              <h3 className="text-xl font-bold gradient-text">Easy Actions</h3>
              <p className="text-sm text-[#ea580c]">Your AI Career Co-pilot</p>
            </div>
          </div>
          
          <p className="text-slate-600 mb-4">
            © 2024 Easy Actions. All rights reserved. Made with ❤️ for ambitious professionals.
          </p>
          
          <div className="flex justify-center space-x-8 mb-6">
            <a href="#" className="text-slate-500 hover:text-[#ea580c] transition-colors btn-hover-lift">Privacy Policy</a>
            <a href="#" className="text-slate-500 hover:text-[#ea580c] transition-colors btn-hover-lift">Terms of Service</a>
            <a href="#" className="text-slate-500 hover:text-[#ea580c] transition-colors btn-hover-lift">Contact Support</a>
          </div>
          
          <div className="flex justify-center space-x-4">
            {[
              { icon: '💼', name: 'LinkedIn', url: 'https://linkedin.com' },
              { icon: '🌐', name: 'Xing', url: 'https://xing.com' },
              { icon: '🪜', name: 'StepStone', url: 'https://stepstone.com' },
              { icon: '🔍', name: 'Indeed', url: 'https://indeed.com' }
            ].map((platform) => (
              <a
                key={platform.name}
                href={platform.url}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-white/80 shadow-lg flex items-center justify-center hover:shadow-xl transition-all duration-200 platform-icon"
              >
                <span className="text-lg">{platform.icon}</span>
              </a>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
};

export default PricingPage;