import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Separator } from './ui/separator';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ImageWithFallback } from './figma/ImageWithFallback';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import EasyActionsLogo from './EasyActionsLogo';
import { useAuth } from './AuthContext';
import {
  User,
  Bell,
  Shield,
  Zap,
  Trash2,
  Download,
  Upload,
  Settings as SettingsIcon,
  Save,
  Eye,
  EyeOff,
  Lock,
  Smartphone,
  Globe,
  Clock,
  Target,
  Mail,
  MessageSquare,
  Sparkles,
  Key,
  AlertTriangle,
  CheckCircle,
  RefreshCw,
  Link,
  Calendar,
  MapPin,
  Phone,
  Linkedin,
  ExternalLink
} from 'lucide-react';

export default function Settings() {
  const { user, logout } = useAuth();
  const [activeTab, setActiveTab] = useState('profile');
  const [notifications, setNotifications] = useState({
    emailResponses: true,
    applicationUpdates: true,
    weeklyDigest: false,
    interviewReminders: true,
    rejectionNotifications: false
  });

  const [automation, setAutomation] = useState({
    autoThankYou: true,
    autoFollowUp: false,
    autoFeedbackRequest: true,
    smartApplications: true,
    weekendApplications: false
  });

  const [profile, setProfile] = useState({
    name: user?.name || 'John Doe',
    email: user?.email || 'john.doe@email.com',
    phone: '+49 123 456 7890',
    location: 'Berlin, Germany',
    linkedin: 'https://linkedin.com/in/johndoe',
    portfolio: 'https://johndoe.dev'
  });

  const [emailCommitment, setEmailCommitment] = useState({
    useEasyActionsEmail: true,
    createCustomEmail: false,
    agreeToTerms: false
  });

  const [showPassword, setShowPassword] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    // Mock save functionality
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log('Settings saved:', { profile, notifications, automation });
    setIsSaving(false);
  };

  const handleExportData = () => {
    // Mock export functionality
    console.log('Exporting user data...');
  };

  const handleDeleteAccount = () => {
    // Mock delete functionality
    if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      console.log('Account deletion requested...');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 p-4 md:p-6 pt-0">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Enhanced Header with Logo and Robot */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-8 space-y-4 lg:space-y-0"
        >
          <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
            <EasyActionsLogo size="lg" showText={true} className="hidden sm:flex" />
            
            {/* Mobile: Logo stacked */}
            <div className="flex flex-col sm:hidden space-y-2">
              <EasyActionsLogo size="md" showText={true} />
            </div>
            
            <div className="flex-1 min-w-0">
              <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold gradient-text drop-shadow-sm leading-tight">
                <span className="block sm:inline">Settings &</span>
                <span className="block sm:inline"> </span>
                <span className="block sm:inline">Preferences ⚙️</span>
              </h1>
              <p className="text-slate-600 mt-2 text-sm sm:text-base leading-relaxed">
                Customize your AI-powered job search experience
              </p>
            </div>
          </div>
          
          {/* AI Assistant Robot */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="relative self-center lg:self-auto"
          >
            <motion.div
              animate={{
                y: [0, -10, 0],
                rotate: [0, 3, -3, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="relative"
            >
              <ImageWithFallback
                src={robotImage}
                alt="AI Assistant Robot"
                className="w-16 h-16 md:w-20 md:h-20 rounded-full shadow-lg border-2 border-white/80 robot-bounce"
              />
              
              {/* Speech bubble */}
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5 }}
                className="absolute -top-16 -left-28 md:-left-40 bg-white rounded-2xl p-3 shadow-lg border border-orange-200/30 max-w-56"
              >
                <p className="text-xs font-medium text-slate-700">
                  Let's optimize your settings for the best job search experience! 🚀
                </p>
                <div className="absolute bottom-0 left-12 w-3 h-3 bg-white transform rotate-45 translate-y-1/2 border-r border-b border-orange-200/30" />
              </motion.div>
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Enhanced Settings Interface */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <Card className="glass glow-orange shadow-xl border-orange-200/30 bg-white/95 backdrop-blur-xl">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              {/* Enhanced Tab Navigation */}
              <CardHeader className="pb-0 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-t-lg">
                <TabsList className="grid grid-cols-2 md:grid-cols-4 w-full bg-white/60 p-1 h-auto">
                  <TabsTrigger value="profile" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-yellow-500 data-[state=active]:text-white py-3 px-2 text-xs sm:text-sm">
                    <User className="w-4 h-4 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Profile</span>
                  </TabsTrigger>
                  <TabsTrigger value="notifications" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-yellow-500 data-[state=active]:text-white py-3 px-2 text-xs sm:text-sm">
                    <Bell className="w-4 h-4 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Notifications</span>
                  </TabsTrigger>
                  <TabsTrigger value="automation" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-yellow-500 data-[state=active]:text-white py-3 px-2 text-xs sm:text-sm">
                    <Zap className="w-4 h-4 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">AI</span>
                  </TabsTrigger>
                  <TabsTrigger value="security" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-500 data-[state=active]:to-yellow-500 data-[state=active]:text-white py-3 px-2 text-xs sm:text-sm">
                    <Shield className="w-4 h-4 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Security</span>
                  </TabsTrigger>
                </TabsList>
              </CardHeader>

              <CardContent className="p-6 md:p-8">
                {/* Profile Tab */}
                <TabsContent value="profile" className="mt-0 space-y-6">
                  <div className="text-center mb-6">
                    <h2 className="text-2xl font-bold gradient-text mb-2">Profile Information</h2>
                    <p className="text-slate-600">Keep your profile updated for better job matching</p>
                  </div>

                  {/* Profile Picture Section */}
                  <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200/30">
                    <CardContent className="p-6">
                      <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
                        <div className="relative">
                          <div className="w-24 h-24 rounded-full bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center shadow-lg">
                            <User className="w-12 h-12 text-white" />
                          </div>
                          <Button
                            size="sm"
                            className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 p-0 bg-blue-500 hover:bg-blue-600"
                          >
                            <Upload className="w-4 h-4" />
                          </Button>
                        </div>
                        <div className="text-center md:text-left">
                          <h3 className="font-semibold text-slate-800">{profile.name}</h3>
                          <p className="text-sm text-slate-600 mb-2">{profile.email}</p>
                          <Button variant="outline" size="sm" className="border-blue-200 hover:bg-blue-50">
                            <Upload className="w-4 h-4 mr-2" />
                            Upload Photo
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Personal Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card className="bg-gradient-to-br from-white/80 to-orange-50/50 border border-orange-200/30">
                      <CardContent className="p-6 space-y-4">
                        <div className="flex items-center mb-4">
                          <User className="w-5 h-5 text-orange-600 mr-2" />
                          <h3 className="font-semibold text-slate-800">Personal Details</h3>
                        </div>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="name" className="text-sm font-medium text-slate-700">Full Name</Label>
                            <Input
                              id="name"
                              value={profile.name}
                              onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                              className="mt-1 bg-white/80 border-orange-200 focus:border-orange-400"
                            />
                          </div>
                          <div>
                            <Label htmlFor="email" className="text-sm font-medium text-slate-700">Email Address</Label>
                            <Input
                              id="email"
                              type="email"
                              value={profile.email}
                              onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                              className="mt-1 bg-white/80 border-orange-200 focus:border-orange-400"
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="bg-gradient-to-br from-white/80 to-blue-50/50 border border-blue-200/30">
                      <CardContent className="p-6 space-y-4">
                        <div className="flex items-center mb-4">
                          <MapPin className="w-5 h-5 text-blue-600 mr-2" />
                          <h3 className="font-semibold text-slate-800">Contact Information</h3>
                        </div>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="phone" className="text-sm font-medium text-slate-700">Phone Number</Label>
                            <Input
                              id="phone"
                              value={profile.phone}
                              onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                              className="mt-1 bg-white/80 border-blue-200 focus:border-blue-400"
                            />
                          </div>
                          <div>
                            <Label htmlFor="location" className="text-sm font-medium text-slate-700">Location</Label>
                            <Input
                              id="location"
                              value={profile.location}
                              onChange={(e) => setProfile({ ...profile, location: e.target.value })}
                              className="mt-1 bg-white/80 border-blue-200 focus:border-blue-400"
                            />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Professional Links */}
                  <Card className="bg-gradient-to-br from-white/80 to-purple-50/50 border border-purple-200/30">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-6">
                        <Link className="w-5 h-5 text-purple-600 mr-2" />
                        <h3 className="font-semibold text-slate-800">Professional Links</h3>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="linkedin" className="text-sm font-medium text-slate-700">LinkedIn Profile</Label>
                          <div className="relative mt-1">
                            <Linkedin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <Input
                              id="linkedin"
                              value={profile.linkedin}
                              onChange={(e) => setProfile({ ...profile, linkedin: e.target.value })}
                              className="pl-10 bg-white/80 border-purple-200 focus:border-purple-400"
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="portfolio" className="text-sm font-medium text-slate-700">Portfolio Website</Label>
                          <div className="relative mt-1">
                            <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                            <Input
                              id="portfolio"
                              value={profile.portfolio}
                              onChange={(e) => setProfile({ ...profile, portfolio: e.target.value })}
                              className="pl-10 bg-white/80 border-purple-200 focus:border-purple-400"
                            />
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Email Management Commitment Letter */}
                  <Card className="bg-gradient-to-br from-white/80 to-green-50/50 border border-green-200/30">
                    <CardContent className="p-6">
                      <div className="flex items-center mb-6">
                        <Mail className="w-5 h-5 text-green-600 mr-2" />
                        <h3 className="font-semibold text-slate-800">Email Management System</h3>
                      </div>
                      
                      <div className="space-y-6">
                        {/* Email Service Options */}
                        <div className="space-y-4">
                          <h4 className="font-medium text-slate-800 mb-3">Choose your email management preference:</h4>
                          
                          <div className="space-y-3">
                            <div className="flex items-start space-x-3 p-4 bg-white/60 rounded-lg border border-green-200/20">
                              <input
                                type="radio"
                                id="easyactions-email"
                                name="email-preference"
                                checked={emailCommitment.useEasyActionsEmail}
                                onChange={() => setEmailCommitment({ ...emailCommitment, useEasyActionsEmail: true, createCustomEmail: false })}
                                className="mt-1 text-green-600 focus:ring-green-500"
                              />
                              <div className="flex-1">
                                <Label htmlFor="easyactions-email" className="font-medium text-slate-800 cursor-pointer">
                                  Use Easy Actions Email Service
                                </Label>
                                <p className="text-sm text-slate-600 mt-1">
                                  We'll manage all job application emails for you with our secure, professional email system. 
                                  This includes automated follow-ups, interview scheduling, and employer communications.
                                </p>
                                <div className="mt-2 text-xs text-green-600 bg-green-50 p-2 rounded">
                                  ✓ Recommended for best automation results
                                </div>
                              </div>
                            </div>
                            
                            <div className="flex items-start space-x-3 p-4 bg-white/60 rounded-lg border border-green-200/20">
                              <input
                                type="radio"
                                id="custom-email"
                                name="email-preference"
                                checked={emailCommitment.createCustomEmail}
                                onChange={() => setEmailCommitment({ ...emailCommitment, useEasyActionsEmail: false, createCustomEmail: true })}
                                className="mt-1 text-green-600 focus:ring-green-500"
                              />
                              <div className="flex-1">
                                <Label htmlFor="custom-email" className="font-medium text-slate-800 cursor-pointer">
                                  Create Custom Email Management
                                </Label>
                                <p className="text-sm text-slate-600 mt-1">
                                  Set up your own email forwarding and management system. You'll be responsible for 
                                  configuring email settings and ensuring proper delivery of job-related communications.
                                </p>
                                <div className="mt-2 text-xs text-amber-600 bg-amber-50 p-2 rounded">
                                  ⚠️ Requires manual email configuration
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {/* Commitment Agreement */}
                        <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-5 rounded-lg border border-blue-200/30">
                          <h4 className="font-semibold text-blue-800 mb-3 flex items-center">
                            <Shield className="w-5 h-5 mr-2" />
                            Email Management Commitment
                          </h4>
                          
                          <div className="space-y-3 text-sm text-slate-700">
                            <p>
                              By selecting an email management option above, you acknowledge and agree to the following:
                            </p>
                            
                            <ul className="list-disc list-inside space-y-1 ml-2">
                              <li>Easy Actions will handle job application emails in accordance with our Privacy Policy</li>
                              <li>All employer communications will be processed securely and professionally</li>
                              <li>You can change your email management preference at any time in these settings</li>
                              <li>We do not share your email content with third parties without your explicit consent</li>
                              <li>Email data is encrypted and stored securely following industry best practices</li>
                            </ul>
                            
                            <div className="mt-4 pt-3 border-t border-blue-200/30">
                              <div className="flex items-start space-x-3">
                                <input
                                  type="checkbox"
                                  id="agree-terms"
                                  checked={emailCommitment.agreeToTerms}
                                  onChange={(e) => setEmailCommitment({ ...emailCommitment, agreeToTerms: e.target.checked })}
                                  className="mt-1 text-blue-600 focus:ring-blue-500"
                                />
                                <Label htmlFor="agree-terms" className="text-sm font-medium text-slate-800 cursor-pointer">
                                  I agree to the email management terms and understand how my emails will be handled
                                </Label>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        {/* Status Indicator */}
                        <div className="flex items-center justify-between p-4 bg-white/80 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <CheckCircle className={`w-5 h-5 ${emailCommitment.agreeToTerms ? 'text-green-600' : 'text-gray-400'}`} />
                            <span className="font-medium text-slate-800">
                              Email Management Status: {emailCommitment.agreeToTerms ? 'Configured' : 'Pending Setup'}
                            </span>
                          </div>
                          {emailCommitment.agreeToTerms && (
                            <Badge className="bg-green-100 text-green-800">
                              Active
                            </Badge>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Save Button */}
                  <div className="flex justify-center">
                    <Button 
                      onClick={handleSave} 
                      disabled={isSaving}
                      className="gradient-button glow-orange text-white px-8 py-3 btn-hover-lift"
                    >
                      {isSaving ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="w-4 h-4 mr-2" />
                          Save Profile
                        </>
                      )}
                    </Button>
                  </div>
                </TabsContent>

                {/* Notifications Tab */}
                <TabsContent value="notifications" className="mt-0 space-y-6">
                  <div className="text-center mb-6">
                    <h2 className="text-2xl font-bold gradient-text mb-2">Notification Preferences</h2>
                    <p className="text-slate-600">Choose how you want to be notified about your job search</p>
                  </div>

                  <div className="space-y-6">
                    {[
                      {
                        key: 'emailResponses',
                        title: 'Email Responses',
                        description: 'Get notified when employers respond to your applications',
                        icon: Mail,
                        color: 'text-green-600',
                        bgColor: 'from-green-50 to-emerald-50',
                        borderColor: 'border-green-200/30'
                      },
                      {
                        key: 'applicationUpdates',
                        title: 'Application Updates',
                        description: 'Status changes and application confirmations',
                        icon: CheckCircle,
                        color: 'text-blue-600',
                        bgColor: 'from-blue-50 to-cyan-50',
                        borderColor: 'border-blue-200/30'
                      },
                      {
                        key: 'interviewReminders',
                        title: 'Interview Reminders',
                        description: 'Reminders before scheduled interviews',
                        icon: Calendar,
                        color: 'text-purple-600',
                        bgColor: 'from-purple-50 to-indigo-50',
                        borderColor: 'border-purple-200/30'
                      },
                      {
                        key: 'weeklyDigest',
                        title: 'Weekly Digest',
                        description: 'Summary of your job search activity',
                        icon: MessageSquare,
                        color: 'text-orange-600',
                        bgColor: 'from-orange-50 to-yellow-50',
                        borderColor: 'border-orange-200/30'
                      },
                      {
                        key: 'rejectionNotifications',
                        title: 'Rejection Notifications',
                        description: 'Get notified about application rejections',
                        icon: AlertTriangle,
                        color: 'text-red-600',
                        bgColor: 'from-red-50 to-pink-50',
                        borderColor: 'border-red-200/30'
                      }
                    ].map((setting, index) => {
                      const Icon = setting.icon;
                      return (
                        <motion.div
                          key={setting.key}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <Card className={`bg-gradient-to-r ${setting.bgColor} ${setting.borderColor} border`}>
                            <CardContent className="p-6">
                              <div className="flex items-center justify-between">
                                <div className="flex items-start space-x-4">
                                  <div className={`w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center ${setting.color}`}>
                                    <Icon className="w-6 h-6" />
                                  </div>
                                  <div>
                                    <h3 className="font-semibold text-slate-800 mb-1">{setting.title}</h3>
                                    <p className="text-sm text-slate-600">{setting.description}</p>
                                  </div>
                                </div>
                                <Switch
                                  checked={notifications[setting.key as keyof typeof notifications]}
                                  onCheckedChange={(checked) => 
                                    setNotifications({ ...notifications, [setting.key]: checked })
                                  }
                                />
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      );
                    })}
                  </div>
                </TabsContent>

                {/* Automation Tab */}
                <TabsContent value="automation" className="mt-0 space-y-6">
                  <div className="text-center mb-6">
                    <h2 className="text-2xl font-bold gradient-text mb-2">AI Automation Settings</h2>
                    <p className="text-slate-600">Configure how AI assists with your job applications</p>
                  </div>

                  <div className="space-y-6">
                    {[
                      {
                        key: 'smartApplications',
                        title: 'Smart Application Timing',
                        description: 'AI optimizes when to send applications for best response rates',
                        icon: Target,
                        color: 'text-blue-600',
                        bgColor: 'from-blue-50 to-cyan-50',
                        borderColor: 'border-blue-200/30',
                        premium: true
                      },
                      {
                        key: 'autoThankYou',
                        title: 'Auto Thank You Emails',
                        description: 'Automatically send thank you emails after interview confirmations',
                        icon: Mail,
                        color: 'text-green-600',
                        bgColor: 'from-green-50 to-emerald-50',
                        borderColor: 'border-green-200/30'
                      },
                      {
                        key: 'autoFollowUp',
                        title: 'Auto Follow-up Messages',
                        description: 'Send follow-up messages if no response after 2 weeks',
                        icon: Clock,
                        color: 'text-purple-600',
                        bgColor: 'from-purple-50 to-indigo-50',
                        borderColor: 'border-purple-200/30'
                      },
                      {
                        key: 'autoFeedbackRequest',
                        title: 'Request Feedback After Rejection',
                        description: 'Automatically ask for feedback to improve future applications',
                        icon: MessageSquare,
                        color: 'text-orange-600',
                        bgColor: 'from-orange-50 to-yellow-50',
                        borderColor: 'border-orange-200/30'
                      },
                      {
                        key: 'weekendApplications',
                        title: 'Weekend Applications',
                        description: 'Allow AI to send applications on weekends',
                        icon: Calendar,
                        color: 'text-indigo-600',
                        bgColor: 'from-indigo-50 to-purple-50',
                        borderColor: 'border-indigo-200/30'
                      }
                    ].map((setting, index) => {
                      const Icon = setting.icon;
                      return (
                        <motion.div
                          key={setting.key}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: index * 0.1 }}
                        >
                          <Card className={`bg-gradient-to-r ${setting.bgColor} ${setting.borderColor} border`}>
                            <CardContent className="p-6">
                              <div className="flex items-center justify-between">
                                <div className="flex items-start space-x-4">
                                  <div className={`w-12 h-12 rounded-full bg-white shadow-lg flex items-center justify-center ${setting.color}`}>
                                    <Icon className="w-6 h-6" />
                                  </div>
                                  <div>
                                    <div className="flex items-center space-x-2 mb-1">
                                      <h3 className="font-semibold text-slate-800">{setting.title}</h3>
                                      {setting.premium && (
                                        <Badge className="bg-gradient-to-r from-orange-500 to-yellow-500 text-white text-xs">
                                          <Sparkles className="w-3 h-3 mr-1" />
                                          AI Pro
                                        </Badge>
                                      )}
                                    </div>
                                    <p className="text-sm text-slate-600">{setting.description}</p>
                                  </div>
                                </div>
                                <Switch
                                  checked={automation[setting.key as keyof typeof automation]}
                                  onCheckedChange={(checked) => 
                                    setAutomation({ ...automation, [setting.key]: checked })
                                  }
                                />
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      );
                    })}
                  </div>
                </TabsContent>

                {/* Security Tab */}
                <TabsContent value="security" className="mt-0 space-y-6">
                  <div className="text-center mb-6">
                    <h2 className="text-2xl font-bold gradient-text mb-2">Privacy & Security</h2>
                    <p className="text-slate-600">Manage your account security and data privacy</p>
                  </div>

                  <div className="space-y-6">
                    {/* Account Security */}
                    <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border border-blue-200/30">
                      <CardContent className="p-6">
                        <div className="flex items-center mb-6">
                          <Lock className="w-5 h-5 text-blue-600 mr-2" />
                          <h3 className="font-semibold text-slate-800">Account Security</h3>
                        </div>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between p-4 bg-white/60 rounded-lg">
                            <div>
                              <h4 className="font-medium text-slate-800">Password</h4>
                              <p className="text-sm text-slate-600">Last changed 3 months ago</p>
                            </div>
                            <Button variant="outline" className="border-blue-200 hover:bg-blue-50">
                              <Key className="w-4 h-4 mr-2" />
                              Change Password
                            </Button>
                          </div>
                          <div className="flex items-center justify-between p-4 bg-white/60 rounded-lg">
                            <div>
                              <h4 className="font-medium text-slate-800">Two-Factor Authentication</h4>
                              <p className="text-sm text-slate-600">Add an extra layer of security</p>
                            </div>
                            <Button variant="outline" className="border-blue-200 hover:bg-blue-50">
                              <Smartphone className="w-4 h-4 mr-2" />
                              Enable 2FA
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Data Management */}
                    <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200/30">
                      <CardContent className="p-6">
                        <div className="flex items-center mb-6">
                          <Shield className="w-5 h-5 text-green-600 mr-2" />
                          <h3 className="font-semibold text-slate-800">Data Management</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <Button 
                            variant="outline" 
                            onClick={handleExportData}
                            className="border-green-200 hover:bg-green-50 btn-hover-lift"
                          >
                            <Download className="w-4 h-4 mr-2" />
                            Export My Data
                          </Button>
                          <Button variant="outline" className="border-green-200 hover:bg-green-50 btn-hover-lift">
                            <Upload className="w-4 h-4 mr-2" />
                            Import Data
                          </Button>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Danger Zone */}
                    <Card className="bg-gradient-to-r from-red-50 to-pink-50 border border-red-200/30">
                      <CardContent className="p-6">
                        <div className="flex items-center mb-6">
                          <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
                          <h3 className="font-semibold text-red-600">Danger Zone</h3>
                        </div>
                        <div className="space-y-4">
                          <div className="p-4 bg-white/60 rounded-lg border border-red-200">
                            <h4 className="font-medium text-red-600 mb-2">Delete Account</h4>
                            <p className="text-sm text-slate-600 mb-4">
                              Permanently delete your account and all associated data. This action cannot be undone.
                            </p>
                            <Button 
                              variant="destructive" 
                              onClick={handleDeleteAccount}
                              className="bg-red-500 hover:bg-red-600"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete Account
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              </CardContent>
            </Tabs>
          </Card>
        </motion.div>

        {/* AI Insights Footer */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 }}
          className="mt-8"
        >
          <Card className="glass glow-orange shadow-xl border-orange-200/30 bg-gradient-to-r from-orange-50/50 to-yellow-50/50">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-4 md:space-y-0">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-orange-500 to-yellow-500 flex items-center justify-center shadow-lg">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-slate-800">AI Optimization Tips</h3>
                    <p className="text-sm text-slate-600">Your settings are optimized for 23% better response rates!</p>
                  </div>
                </div>
                <Button className="gradient-button glow-orange text-white btn-hover-lift">
                  <Target className="w-4 h-4 mr-2" />
                  View AI Recommendations
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}