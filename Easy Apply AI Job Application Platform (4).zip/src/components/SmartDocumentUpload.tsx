import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { ImageWithFallback } from './figma/ImageWithFallback';
import robotImage from 'figma:asset/442d4249646936c378039add8eb917c7d4dc4d08.png';
import EasyActionsLogo from './EasyActionsLogo';
import {
  Upload,
  FileText,
  CheckCircle,
  Zap,
  Target,
  Send,
  AlertCircle,
  Play,
  Settings,
  RefreshCw,
  Mail,
  Bell,
  Sparkles,
  ArrowRight,
  X,
  Download,
  Eye,
  Copy,
  ExternalLink
} from 'lucide-react';

interface UploadedFile {
  id: string;
  name: string;
  type: 'resume' | 'cover-letter' | 'certificate';
  size: string;
  status: 'uploaded' | 'analyzing' | 'processed';
  extractedSkills?: string[];
}

interface FoundJob {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  platform: string;
  match: number;
  status: 'found' | 'generating' | 'ready' | 'sent';
  coverLetter?: string;
}

const SmartDocumentUpload: React.FC = () => {
  const navigate = useNavigate();
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [analyzing, setAnalyzing] = useState(false);
  const [foundJobs, setFoundJobs] = useState<FoundJob[]>([]);
  const [currentStep, setCurrentStep] = useState<'upload' | 'analyzing' | 'matching' | 'generating' | 'ready'>('upload');
  const [showCoverLetter, setShowCoverLetter] = useState<string | null>(null);

  // Mock analysis progress
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [matchingProgress, setMatchingProgress] = useState(0);
  const [generatingProgress, setGeneratingProgress] = useState(0);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  const handleFiles = (files: FileList) => {
    const newFiles: UploadedFile[] = Array.from(files).map((file, index) => ({
      id: `file-${Date.now()}-${index}`,
      name: file.name,
      type: file.name.toLowerCase().includes('cv') || file.name.toLowerCase().includes('resume') ? 'resume' : 'cover-letter',
      size: `${(file.size / 1024 / 1024).toFixed(2)} MB`,
      status: 'uploaded'
    }));

    setUploadedFiles(prev => [...prev, ...newFiles]);
    startAnalysis(newFiles);
  };

  const startAnalysis = async (files: UploadedFile[]) => {
    setCurrentStep('analyzing');
    setAnalyzing(true);

    // Update file status to analyzing
    setUploadedFiles(prev => prev.map(file => 
      files.find(f => f.id === file.id) ? { ...file, status: 'analyzing' } : file
    ));

    // Simulate analysis progress
    for (let i = 0; i <= 100; i += 20) {
      setAnalysisProgress(i);
      await new Promise(resolve => setTimeout(resolve, 800));
    }

    // Mark files as processed with extracted skills
    setUploadedFiles(prev => prev.map(file => 
      files.find(f => f.id === file.id) ? { 
        ...file, 
        status: 'processed',
        extractedSkills: ['React', 'TypeScript', 'Node.js', 'Python', 'AWS', 'Docker']
      } : file
    ));

    // Start job matching
    setCurrentStep('matching');
    await startJobMatching();
  };

  const startJobMatching = async () => {
    for (let i = 0; i <= 100; i += 25) {
      setMatchingProgress(i);
      await new Promise(resolve => setTimeout(resolve, 600));
    }

    // Mock found jobs
    const mockJobs: FoundJob[] = [
      {
        id: '1',
        title: 'Senior React Developer',
        company: 'TechCorp',
        location: 'Munich',
        salary: '€70,000-€85,000',
        platform: 'LinkedIn',
        match: 95,
        status: 'found'
      },
      {
        id: '2',
        title: 'Full Stack Engineer',
        company: 'StartupXYZ',
        location: 'Berlin',
        salary: '€60,000-€75,000',
        platform: 'StepStone',
        match: 92,
        status: 'found'
      },
      {
        id: '3',
        title: 'Frontend Developer',
        company: 'WebSolutions',
        location: 'Frankfurt',
        salary: '€65,000-€80,000',
        platform: 'Indeed',
        match: 88,
        status: 'found'
      }
    ];

    setFoundJobs(mockJobs);
    setCurrentStep('generating');
    await generateCoverLetters(mockJobs);
  };

  const generateCoverLetters = async (jobs: FoundJob[]) => {
    for (let i = 0; i < jobs.length; i++) {
      setFoundJobs(prev => prev.map(job => 
        job.id === jobs[i].id ? { ...job, status: 'generating' } : job
      ));

      // Simulate cover letter generation progress
      for (let progress = 0; progress <= 100; progress += 33) {
        setGeneratingProgress(progress);
        await new Promise(resolve => setTimeout(resolve, 400));
      }

      // Mock generated cover letter
      const coverLetter = `Dear Hiring Manager,

I am writing to express my strong interest in the ${jobs[i].title} position at ${jobs[i].company}. With my extensive experience in React, TypeScript, and modern web development, I believe I would be an excellent fit for your team.

My background includes:
• 5+ years of React development experience
• Strong expertise in TypeScript and modern JavaScript
• Experience with Node.js, AWS, and Docker
• Proven track record of delivering high-quality web applications

I am particularly excited about the opportunity to contribute to ${jobs[i].company}'s innovative projects and would welcome the chance to discuss how my skills align with your needs.

Best regards,
Demo User`;

      setFoundJobs(prev => prev.map(job => 
        job.id === jobs[i].id ? { 
          ...job, 
          status: 'ready',
          coverLetter 
        } : job
      ));
    }

    setCurrentStep('ready');
  };

  const sendApplication = async (jobId: string) => {
    setFoundJobs(prev => prev.map(job => 
      job.id === jobId ? { ...job, status: 'sent' } : job
    ));

    // Simulate sending
    await new Promise(resolve => setTimeout(resolve, 1000));
  };

  const sendAllApplications = async () => {
    for (const job of foundJobs.filter(j => j.status === 'ready')) {
      await sendApplication(job.id);
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  };

  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'linkedin': return '💼';
      case 'stepstone': return '🪜';
      case 'indeed': return '🔍';
      case 'xing': return '🌐';
      default: return '🌍';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'found': return 'bg-blue-100 text-blue-700';
      case 'generating': return 'bg-yellow-100 text-yellow-700';
      case 'ready': return 'bg-green-100 text-green-700';
      case 'sent': return 'bg-purple-100 text-purple-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-yellow-50 p-4 md:p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="flex items-center justify-between"
        >
          <div className="flex items-center space-x-4">
            <EasyActionsLogo size="lg" showText={true} />
            <div>
              <h1 className="text-3xl font-bold gradient-text drop-shadow-sm">
                Smart Document Upload ⚡
              </h1>
              <p className="text-slate-600 mt-1 font-medium">
                Upload, analyze, match, and apply automatically with AI
              </p>
            </div>
          </div>
          
          <Button
            onClick={() => navigate('/dashboard')}
            variant="outline"
            className="border-orange-200 hover:bg-orange-50 btn-hover-lift"
          >
            <ArrowRight className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </motion.div>

        {/* Progress Steps */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
        >
          <Card className="glass glow-orange shadow-xl border-orange-200/30">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                {[
                  { step: 'upload', label: 'Upload', icon: Upload },
                  { step: 'analyzing', label: 'AI Analysis', icon: Sparkles },
                  { step: 'matching', label: 'Job Matching', icon: Target },
                  { step: 'generating', label: 'Cover Letters', icon: FileText },
                  { step: 'ready', label: 'Ready to Send', icon: Send }
                ].map((item, index) => {
                  const Icon = item.icon;
                  const isActive = item.step === currentStep;
                  const isCompleted = ['upload', 'analyzing', 'matching', 'generating'].indexOf(item.step) < ['upload', 'analyzing', 'matching', 'generating'].indexOf(currentStep);
                  
                  return (
                    <div key={item.step} className="flex items-center">
                      <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
                        isActive ? 'bg-gradient-to-r from-[#ea580c] to-[#f97316] text-white shadow-lg' :
                        isCompleted ? 'bg-green-500 text-white' :
                        'bg-gray-200 text-gray-500'
                      }`}>
                        {isCompleted ? <CheckCircle className="w-6 h-6" /> : <Icon className="w-6 h-6" />}
                      </div>
                      <span className={`ml-2 font-medium ${isActive ? 'text-orange-600' : isCompleted ? 'text-green-600' : 'text-gray-500'}`}>
                        {item.label}
                      </span>
                      {index < 4 && (
                        <div className={`mx-4 h-1 w-16 rounded ${
                          isCompleted ? 'bg-green-500' : 'bg-gray-200'
                        }`} />
                      )}
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Upload Section */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="glass glow-orange shadow-xl border-orange-200/30">
              <CardHeader>
                <CardTitle className="gradient-text flex items-center">
                  <Upload className="w-5 h-5 mr-2" />
                  Document Upload
                </CardTitle>
                <CardDescription>
                  Upload your resume, cover letter, and certificates
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Drag & Drop Area */}
                <div
                  className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all duration-300 ${
                    dragActive 
                      ? 'border-orange-400 bg-orange-50' 
                      : 'border-orange-200 hover:border-orange-300 hover:bg-orange-25'
                  }`}
                  onDragEnter={handleDrag}
                  onDragLeave={handleDrag}
                  onDragOver={handleDrag}
                  onDrop={handleDrop}
                >
                  <input
                    type="file"
                    multiple
                    accept=".pdf,.doc,.docx"
                    onChange={handleChange}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  />
                  
                  <div className="space-y-4">
                    <div className="w-16 h-16 mx-auto bg-gradient-to-r from-[#ea580c] to-[#f97316] rounded-full flex items-center justify-center">
                      <Upload className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <p className="text-lg font-semibold text-slate-700">
                        Drop files here or click to browse
                      </p>
                      <p className="text-sm text-slate-500">
                        Supports PDF, DOC, DOCX files up to 10MB
                      </p>
                    </div>
                  </div>
                </div>

                {/* Uploaded Files */}
                {uploadedFiles.length > 0 && (
                  <div className="mt-6 space-y-3">
                    <h4 className="font-semibold text-slate-700">Uploaded Files</h4>
                    {uploadedFiles.map((file) => (
                      <motion.div
                        key={file.id}
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="flex items-center justify-between p-3 rounded-lg bg-white/60 border border-orange-100"
                      >
                        <div className="flex items-center space-x-3">
                          <FileText className="w-5 h-5 text-orange-600" />
                          <div>
                            <p className="font-medium text-slate-700">{file.name}</p>
                            <p className="text-xs text-slate-500">{file.size} • {file.type}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {file.status === 'analyzing' && (
                            <div className="w-4 h-4 border-2 border-orange-300 border-t-orange-600 rounded-full animate-spin" />
                          )}
                          <Badge className={
                            file.status === 'uploaded' ? 'bg-blue-100 text-blue-700' :
                            file.status === 'analyzing' ? 'bg-yellow-100 text-yellow-700' :
                            'bg-green-100 text-green-700'
                          }>
                            {file.status === 'uploaded' ? 'Uploaded' :
                             file.status === 'analyzing' ? 'Analyzing' : 'Processed'}
                          </Badge>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}

                {/* Analysis Progress */}
                {currentStep === 'analyzing' && (
                  <div className="mt-6 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-slate-700">AI Analysis Progress</span>
                      <span className="text-sm text-slate-500">{analysisProgress}%</span>
                    </div>
                    <Progress value={analysisProgress} className="h-2 bg-orange-100" />
                    <p className="text-xs text-slate-500">Extracting skills, experience, and preferences...</p>
                  </div>
                )}

                {/* Extracted Skills */}
                {uploadedFiles.some(f => f.extractedSkills) && (
                  <div className="mt-6">
                    <h4 className="font-semibold text-slate-700 mb-3">Extracted Skills</h4>
                    <div className="flex flex-wrap gap-2">
                      {uploadedFiles[0]?.extractedSkills?.map((skill) => (
                        <Badge key={skill} className="bg-orange-100 text-orange-700">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Job Matching & Results */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Card className="glass glow-orange shadow-xl border-orange-200/30">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="gradient-text flex items-center">
                      <Target className="w-5 h-5 mr-2" />
                      Job Matches
                    </CardTitle>
                    <CardDescription>
                      AI-found jobs with personalized cover letters
                    </CardDescription>
                  </div>
                  {foundJobs.length > 0 && foundJobs.every(j => j.status === 'ready') && (
                    <Button
                      onClick={sendAllApplications}
                      className="gradient-button glow-orange text-white btn-hover-lift"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      Send All
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                
                {/* Matching Progress */}
                {currentStep === 'matching' && (
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-slate-700">Finding Jobs</span>
                      <span className="text-sm text-slate-500">{matchingProgress}%</span>
                    </div>
                    <Progress value={matchingProgress} className="h-2 bg-orange-100" />
                    <p className="text-xs text-slate-500">Searching across LinkedIn, StepStone, Indeed, and Xing...</p>
                  </div>
                )}

                {/* Generation Progress */}
                {currentStep === 'generating' && (
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-slate-700">Generating Cover Letters</span>
                      <span className="text-sm text-slate-500">{generatingProgress}%</span>
                    </div>
                    <Progress value={generatingProgress} className="h-2 bg-orange-100" />
                    <p className="text-xs text-slate-500">Creating personalized cover letters for each position...</p>
                  </div>
                )}

                {/* Found Jobs */}
                {foundJobs.length > 0 && (
                  <div className="space-y-4">
                    {foundJobs.map((job, index) => (
                      <motion.div
                        key={job.id}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="p-4 rounded-xl bg-white/60 border border-orange-100 hover:bg-white/80 transition-all duration-200"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-3 flex-1">
                            <div className="text-2xl">{getPlatformIcon(job.platform)}</div>
                            <div className="flex-1">
                              <h4 className="font-semibold text-slate-800">{job.title}</h4>
                              <p className="text-sm text-slate-600">{job.company} • {job.location}</p>
                              <p className="text-xs text-slate-500">{job.salary}</p>
                              <div className="flex items-center space-x-2 mt-2">
                                <Badge className="bg-green-100 text-green-700">
                                  {job.match}% match
                                </Badge>
                                <Badge className={getStatusColor(job.status)}>
                                  {job.status === 'found' ? 'Found' :
                                   job.status === 'generating' ? 'Generating' :
                                   job.status === 'ready' ? 'Ready' : 'Sent'}
                                </Badge>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-2">
                            {job.status === 'generating' && (
                              <div className="w-5 h-5 border-2 border-orange-300 border-t-orange-600 rounded-full animate-spin" />
                            )}
                            {job.status === 'ready' && (
                              <>
                                <Button
                                  onClick={() => setShowCoverLetter(job.id)}
                                  variant="outline"
                                  size="sm"
                                  className="border-orange-200 hover:bg-orange-50"
                                >
                                  <Eye className="w-4 h-4 mr-1" />
                                  View
                                </Button>
                                <Button
                                  onClick={() => sendApplication(job.id)}
                                  className="gradient-button glow-orange text-white"
                                  size="sm"
                                >
                                  <Send className="w-4 h-4 mr-1" />
                                  Send
                                </Button>
                              </>
                            )}
                            {job.status === 'sent' && (
                              <CheckCircle className="w-5 h-5 text-green-500" />
                            )}
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}

                {foundJobs.length === 0 && currentStep === 'upload' && (
                  <div className="text-center py-8">
                    <ImageWithFallback
                      src={robotImage}
                      alt="AI Assistant Robot"
                      className="w-16 h-16 mx-auto rounded-full shadow-lg mb-4 robot-bounce"
                    />
                    <p className="text-slate-600">Upload your documents to start finding jobs!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Cover Letter Modal */}
        {showCoverLetter && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowCoverLetter(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <h3 className="text-xl font-bold text-slate-800">Generated Cover Letter</h3>
                  <Button
                    onClick={() => setShowCoverLetter(null)}
                    variant="ghost"
                    size="sm"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="p-6 overflow-y-auto max-h-96">
                <pre className="whitespace-pre-wrap font-sans text-slate-700 leading-relaxed">
                  {foundJobs.find(j => j.id === showCoverLetter)?.coverLetter}
                </pre>
              </div>
              
              <div className="p-6 border-t border-gray-200 flex space-x-3">
                <Button
                  onClick={() => navigator.clipboard.writeText(foundJobs.find(j => j.id === showCoverLetter)?.coverLetter || '')}
                  variant="outline"
                  className="flex-1"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
                <Button
                  onClick={() => {
                    sendApplication(showCoverLetter);
                    setShowCoverLetter(null);
                  }}
                  className="gradient-button glow-orange text-white flex-1"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Send Application
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default SmartDocumentUpload;